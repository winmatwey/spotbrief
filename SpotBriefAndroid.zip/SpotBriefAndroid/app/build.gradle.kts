plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "ru.matwey.spotbrief"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.matwey.spotbrief"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.2")

    // Хранение настроек — аналог @AppStorage/UserDefaults из SettingsStore.swift
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Позволяет менять язык интерфейса ИЗ ПРИЛОЖЕНИЯ независимо от системной
    // локали устройства — аналог AppLanguage/L10n из Localization.swift.
    implementation("androidx.appcompat:appcompat:1.7.0")

    // JSON-сериализация — аналог Codable/JSONEncoder для NewsItem/CustomSource
    // (Persistence.swift, CustomSourcesStore.swift).
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    // Утренние уведомления со сводкой дня — аналог UNUserNotificationCenter
    // + UNCalendarNotificationTrigger (MorningNotificationScheduler.swift).
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Виджет на главном экране/экране блокировки — аналог WidgetKit-расширения
    // (WidgetSharedDigest.swift + WidgetExtension-Reference/). В отличие от
    // iOS-версии (которая только ГОТОВИТ данные — сам виджет не заведён,
    // см. комментарий в WidgetSharedDigest.swift о том, что .swiftpm не
    // поддерживает второй таргет), на Android виджет РЕАЛЬНО работает: не
    // нужен отдельный таргет и App Group, виджет живёт в том же процессе.
    implementation("androidx.glance:glance-appwidget:1.1.1")
    implementation("androidx.glance:glance-material3:1.1.1")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
