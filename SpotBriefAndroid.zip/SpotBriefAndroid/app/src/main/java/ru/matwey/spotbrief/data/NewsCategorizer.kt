package ru.matwey.spotbrief.data

import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.model.NewsItem

/**
 * Эвристический классификатор новостей по ключевым словам в заголовке и
 * описании. Работает полностью офлайн, без обращений к внешним AI-сервисам.
 * См. подробности в оригинальном NewsCategorizer.swift.
 */
object NewsCategorizer {

    fun categorize(item: NewsItem): NewsCategory {
        val title = item.title.lowercase()
        val body = item.rawDescription.lowercase()

        var bestCategory = NewsCategory.SOCIETY
        var bestScore = 0.0

        for (category in NewsCategory.entries) {
            if (category.keywords.isEmpty()) continue
            var score = 0.0
            for (keyword in category.keywords) {
                // Фразы из нескольких слов — куда более редкий и однозначный
                // сигнал темы, чем одно общее слово, поэтому весят больше.
                val keywordWeight = if (keyword.contains(" ")) 2.5 else 1.0

                val titleHits = wholeWordOccurrences(keyword, title)
                val bodyHits = wholeWordOccurrences(keyword, body)

                // Совпадение в заголовке весит вдвое больше, чем в описании.
                score += titleHits * keywordWeight * 2.0
                score += bodyHits * keywordWeight
            }
            if (score > bestScore) {
                bestScore = score
                bestCategory = category
            }
        }

        return bestCategory
    }

    fun categorizeAll(items: List<NewsItem>): List<NewsItem> = items.map { item ->
        item.copy(category = categorize(item))
    }

    /**
     * Считает вхождения ключевого слова/фразы как ЦЕЛОГО слова, а не
     * подстроки — без этой проверки, например, ключ "банк" ложно
     * засчитывался бы и внутри "банкет", "банка" или фамилии "Банкетов".
     * Границей слова считается любой небуквенный символ.
     */
    private fun wholeWordOccurrences(keyword: String, haystack: String): Int {
        if (keyword.isEmpty()) return 0
        var count = 0
        var searchFrom = 0
        while (true) {
            val index = haystack.indexOf(keyword, searchFrom)
            if (index == -1) break
            val beforeOk = index == 0 || !haystack[index - 1].isLetter()
            val afterIndex = index + keyword.length
            val afterOk = afterIndex >= haystack.length || !haystack[afterIndex].isLetter()
            if (beforeOk && afterOk) count++
            searchFrom = index + keyword.length
        }
        return count
    }
}
