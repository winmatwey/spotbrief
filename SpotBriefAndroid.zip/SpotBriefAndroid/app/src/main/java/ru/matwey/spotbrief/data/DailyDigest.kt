package ru.matwey.spotbrief.data

import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.model.NewsItem

/**
 * Сводка "по одной главной новости из каждой группы" — используется на
 * главном экране и как текст утреннего уведомления. См. DailyDigest.swift.
 */
data class DailyDigest(val entries: List<Entry>) {
    data class Entry(val category: NewsCategory, val item: NewsItem) {
        val id: String get() = item.stableId
    }

    val isEmpty: Boolean get() = entries.isEmpty()

    /** Компактный текст для тела уведомления — "Группа: заголовок" по строке. */
    fun notificationBody(language: AppLanguage, maxEntries: Int = 6): String =
        entries.take(maxEntries)
            .joinToString("\n") { "${it.category.localizedName(language)}: ${it.item.title}" }

    companion object {
        /** Берёт самую свежую новость из каждой непустой категории. */
        fun build(items: List<NewsItem>): DailyDigest {
            val latestByCategory = mutableMapOf<NewsCategory, NewsItem>()
            for (item in items) {
                val existing = latestByCategory[item.category]
                if (existing == null) {
                    latestByCategory[item.category] = item
                    continue
                }
                if ((item.pubDateMillis ?: Long.MIN_VALUE) > (existing.pubDateMillis ?: Long.MIN_VALUE)) {
                    latestByCategory[item.category] = item
                }
            }
            val entries = NewsCategory.entries.mapNotNull { category ->
                latestByCategory[category]?.let { Entry(category, it) }
            }
            return DailyDigest(entries)
        }
    }
}
