@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.matwey.spotbrief.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.matwey.spotbrief.data.DailyDigest
import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.model.NewsItem
import ru.matwey.spotbrief.ui.LocalAppContainer
import ru.matwey.spotbrief.ui.colorFor
import ru.matwey.spotbrief.ui.iconFor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FeedScreen(onOpenItem: (NewsItem) -> Unit, onOpenCategory: (NewsCategory) -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val service = app.service
    val scope = rememberCoroutineScope()

    val items by service.items.collectAsState()
    val isLoading by service.isLoading.collectAsState()
    val lastUpdated by service.lastUpdatedMillis.collectAsState()
    val errors by service.errors.collectAsState()
    val sources by service.sources.collectAsState()

    LaunchedEffect(Unit) {
        if (items.isEmpty()) service.refreshAll()
    }

    val digestEntries = remember(items) { DailyDigest.build(items).entries }
    val featured = items.firstOrNull()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(settings.t("app.name")) },
                actions = {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp).padding(end = 12.dp))
                    } else {
                        IconButton(onClick = { scope.launch { service.refreshAll() } }) {
                            Icon(Icons.Filled.Refresh, contentDescription = null)
                        }
                    }
                }
            )
        }
    ) { padding ->
        PullToRefreshBox(
            isRefreshing = isLoading,
            onRefresh = { scope.launch { service.refreshAll() } },
            modifier = Modifier.padding(padding).fillMaxSize()
        ) {
            if (!isLoading && items.isEmpty()) {
                EmptyFeedState(sourcesCount = sources.size)
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    featured?.let { item ->
                        item {
                            SectionHeader(settings.t("content.mainNow"))
                            FeaturedStoryCard(item = item, onClick = { onOpenItem(item) })
                        }
                    }

                    if (digestEntries.isNotEmpty()) {
                        item { SectionHeader(settings.t("content.digest")) }
                        items(digestEntries, key = { it.id }) { entry ->
                            DigestRow(entry = entry, onClick = { onOpenItem(entry.item) })
                        }
                    }

                    if (errors.isNotEmpty()) {
                        item { SectionHeader(settings.t("content.sourcesUnavailable")) }
                        items(errors) { error ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.WifiOff, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.padding(start = 4.dp))
                                Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }

                    item {
                        SectionHeader(
                            lastUpdated?.let { settings.tf("content.updatedAt", timeFormat(it)) }
                                ?: settings.t("content.categories")
                        )
                    }
                    items(NewsCategory.entries) { category ->
                        CategoryRow(
                            category = category,
                            count = service.countIn(category),
                            onClick = { onOpenCategory(category) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
private fun EmptyFeedState(sourcesCount: Int) {
    val app = LocalAppContainer.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Newspaper, contentDescription = null, modifier = Modifier.size(48.dp))
            Spacer(Modifier.padding(top = 12.dp))
            Text(app.settings.t("content.noData.title"), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.padding(top = 4.dp))
            Text(
                app.settings.tf("content.noData.description", sourcesCount),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun FeaturedStoryCard(item: NewsItem, onClick: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFFF9800), Color(0xFFE53935))))
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(iconFor(item.category), contentDescription = null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(16.dp))
            Spacer(Modifier.padding(start = 4.dp))
            Text(
                item.category.localizedName(settings.effectiveLanguage),
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.85f),
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.weight(1f))
            Text(item.allSourceNames.joinToString(", "), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f), maxLines = 1)
        }
        Spacer(Modifier.padding(top = 8.dp))
        Text(item.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 3)
        Spacer(Modifier.padding(top = 8.dp))
        val summary = item.summary.ifEmpty { settings.t("summary.unavailable") }
        Text(
            summary, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.9f),
            maxLines = 2, fontStyle = if (item.summary.isEmpty()) FontStyle.Italic else FontStyle.Normal
        )
        Spacer(Modifier.padding(top = 8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color.White.copy(alpha = 0.75f), modifier = Modifier.size(12.dp))
            Spacer(Modifier.padding(start = 4.dp))
            Text(settings.tf("content.readingTime", item.readingTimeMinutes), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f))
        }
    }
}

@Composable
private fun DigestRow(entry: DailyDigest.Entry, onClick: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    Column(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(iconFor(entry.category), contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.padding(start = 4.dp))
            Text(entry.category.localizedName(settings.effectiveLanguage), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(entry.item.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 2)
        Text(entry.item.allSourceNames.joinToString(", "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun CategoryRow(category: NewsCategory, count: Int, onClick: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(32.dp).clip(CircleShape).background(colorFor(category)),
            contentAlignment = Alignment.Center
        ) {
            Icon(iconFor(category), contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.padding(start = 12.dp))
        Column {
            Text(category.localizedName(settings.effectiveLanguage), style = MaterialTheme.typography.titleSmall)
            Text(settings.tf("content.newsCount", count), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun timeFormat(millis: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(millis))
