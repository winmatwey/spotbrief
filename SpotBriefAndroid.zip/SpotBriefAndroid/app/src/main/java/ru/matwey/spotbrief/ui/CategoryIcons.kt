package ru.matwey.spotbrief.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.TheaterComedy
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Color
import ru.matwey.spotbrief.model.NewsCategory

fun iconFor(category: NewsCategory): ImageVector = when (category.iconKey) {
    "account_balance" -> Icons.Filled.AccountBalance
    "sports_soccer" -> Icons.Filled.SportsSoccer
    "trending_up" -> Icons.Filled.TrendingUp
    "memory" -> Icons.Filled.Memory
    "science" -> Icons.Filled.Science
    "theater_comedy" -> Icons.Filled.TheaterComedy
    "warning" -> Icons.Filled.Warning
    "groups" -> Icons.Filled.Groups
    else -> Icons.Filled.Newspaper
}

/**
 * Цвет-акцент категории. Раньше это были восемь случайно взятых ярких
 * веб-цветов (чистый зелёный рядом с чистым жёлтым рядом с чистым розовым),
 * которые визуально "спорили" друг с другом на экране статистики и в
 * значках категорий. Теперь все восемь — из одного согласованного набора:
 * одинаковая насыщенность и светлота (одного порядка), но разный тон —
 * так они читаются как единая палитра приложения, а не как случайный набор.
 * Все на тёмном фоне (значок всегда белый/светлая иконка поверх) дают
 * схожий, комфортный контраст.
 */
fun colorFor(category: NewsCategory): Color = when (category) {
    NewsCategory.POLITICS -> Color(0xFF3B5BA9)     // синий
    NewsCategory.SPORTS -> Color(0xFF2E9E6B)       // приглушённый зелёный
    NewsCategory.ECONOMY -> Color(0xFFC98A2C)      // тёплый янтарный
    NewsCategory.TECHNOLOGY -> Color(0xFF3B82C4)   // голубой
    NewsCategory.SCIENCE -> Color(0xFF7C5CBF)      // фиолетовый
    NewsCategory.CULTURE -> Color(0xFFB3557C)      // приглушённая роза
    NewsCategory.INCIDENTS -> Color(0xFFC94A4A)    // приглушённый красный
    NewsCategory.SOCIETY -> Color(0xFF8A7B6C)      // тёплый серо-бежевый
}
