package ru.matwey.spotbrief.data

import ru.matwey.spotbrief.model.NewsItem

/**
 * Отфильтровывает типовой "мусорный" контент, который RSS-ленты новостных
 * сайтов часто подмешивают вперемешку с настоящими новостями: гороскопы,
 * тесты/квизы, регулярные сводки погоды. См. подробное объяснение в
 * оригинальном NewsJunkFilter.swift.
 *
 * Проверяем в основном ЗАГОЛОВОК, а не весь текст — так меньше риск
 * случайно отфильтровать настоящую новость, которая просто упоминает,
 * например, слово "тест" где-то в середине описания.
 */
object NewsJunkFilter {

    private val titlePatterns = listOf(
        // Гороскопы
        "гороскоп", "horoscope", "horoskop",
        // Регулярные сводки погоды
        "прогноз погоды на", "погода на сегодня", "погода на завтра",
        "погода на неделю", "weather forecast for",
        // Тесты/квизы-развлечения
        "тест: ", "квиз: ", "quiz: ", "тест на ", "тест дня",
        // "Какой сегодня праздник" — регулярные заготовки без событийного повода
        "отмечают в россии и мире", "какой сегодня праздник",
        "какие праздники отмечают", "праздники дня:",
        "unofficial holidays", "national day of", "fun holidays today"
    )

    fun isJunk(item: NewsItem): Boolean {
        val title = item.title.lowercase()
        return titlePatterns.any { title.contains(it) }
    }

    fun filter(items: List<NewsItem>): List<NewsItem> = items.filterNot(::isJunk)
}
