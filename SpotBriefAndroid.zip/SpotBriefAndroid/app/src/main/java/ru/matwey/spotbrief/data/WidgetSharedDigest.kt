package ru.matwey.spotbrief.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Компактная, кодируемая версия DailyDigest — то, что реально нужно
 * виджету на главном экране: заголовок и группа, без полного текста
 * новости и служебных полей NewsItem. Аналог WidgetSharedDigest.swift.
 *
 * ВАЖНО, чем это проще, чем в iOS-версии: там виджет — отдельный процесс
 * (WidgetKit extension), и для обмена данными нужна App Group (общий
 * UserDefaults suite) — причём сам .swiftpm-формат проекта не поддерживал
 * добавление такого второго таргета вообще (см. комментарий в оригинале).
 * На Android виджет (Glance AppWidget) живёт в ТОМ ЖЕ процессе приложения,
 * поэтому достаточно обычных SharedPreferences — никакого второго таргета
 * заводить не нужно, виджет уже полностью работает.
 */
@Serializable
data class WidgetDigestEntry(val category: String, val title: String, val sourceName: String)

@Serializable
data class WidgetDigestPayload(val generatedAtMillis: Long, val entries: List<WidgetDigestEntry>)

object WidgetSharedDigest {
    private const val PREFS_NAME = "spotbrief_widget"
    private const val KEY_PAYLOAD = "digest_payload"

    fun save(context: Context, digest: DailyDigest, language: AppLanguage) {
        val entries = digest.entries.map {
            WidgetDigestEntry(
                category = it.category.localizedName(language),
                title = it.item.title,
                sourceName = it.item.sourceName
            )
        }
        val payload = WidgetDigestPayload(System.currentTimeMillis(), entries)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PAYLOAD, Json.encodeToString(payload)).apply()
    }

    fun load(context: Context): WidgetDigestPayload? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_PAYLOAD, null) ?: return null
        return try {
            Json.decodeFromString<WidgetDigestPayload>(raw)
        } catch (e: Exception) {
            null
        }
    }
}
