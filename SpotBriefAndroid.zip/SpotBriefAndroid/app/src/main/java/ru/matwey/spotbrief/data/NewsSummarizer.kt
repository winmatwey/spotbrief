package ru.matwey.spotbrief.data

import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.model.NewsItem
import java.text.BreakIterator
import java.util.Locale

/**
 * Простой экстрактивный суммаризатор: работает офлайн, без сторонних API.
 * Для короткого RSS-описания просто возвращает его очищенным. Для длинного
 * текста выбирает наиболее "важные" и при этом непохожие друг на друга
 * предложения (упрощённый TextRank + MMR). Прямой перенос NewsSummarizer.swift;
 * разбивка на предложения — через java.text.BreakIterator вместо NLTokenizer
 * (тот же принцип: не резать текст по каждой точке, а понимать границы
 * предложений с учётом сокращений и десятичных чисел).
 */
object NewsSummarizer {

    private val stopWords: Set<String> = setOf(
        "и", "в", "во", "не", "что", "он", "на", "я", "с", "со", "как", "а", "то",
        "все", "она", "так", "его", "но", "да", "ты", "к", "у", "же", "вы", "за",
        "бы", "по", "только", "ее", "мне", "было", "вот", "от", "меня", "еще",
        "нет", "о", "из", "ему", "теперь", "когда", "даже", "ну", "вдруг", "ли",
        "если", "уже", "или", "ни", "быть", "был", "него", "до", "вас", "нибудь",
        "опять", "уж", "вам", "сказал", "для", "этого", "этой", "этот", "эти",
        "тем", "которые", "которая", "который", "также", "после", "может", "будет",
        "чем", "при", "об", "их", "им", "своей", "своего", "свои", "чтобы"
    )

    /**
     * Жёсткий потолок длины итоговой сводки в символах — страховка на
     * случай нетипичной вёрстки, из-за которой разбивка на предложения
     * может не сработать как надо.
     */
    private const val MAX_SUMMARY_LENGTH = 1200

    /**
     * Минимум предложений, который должно содержать краткое содержание,
     * когда в источнике вообще есть, из чего его набрать (см. подробности
     * в NewsAggregatorService.expandShortSummaries).
     */
    const val MIN_SENTENCES = 5

    /** Сжимает текст до нескольких (по умолчанию 6) информативных предложений. */
    fun summarize(title: String, text: String, maxSentences: Int = 6): String {
        val source = text.ifEmpty { title }
        var sentences = dedupedSentences(splitIntoSentences(source))

        // Заголовок уже показан отдельно в интерфейсе — не дублируем его в сводке.
        sentences = sentences.filterNot { isNearDuplicate(it, title) }

        if (sentences.isEmpty()) {
            // Если после фильтрации совпадений с заголовком ничего не осталось
            // (например, описания не было вовсе и source — это сам заголовок),
            // отдаём пустую строку вместо дословной копии заголовка — интерфейс
            // покажет заглушку "нет описания".
            val fallback = capLength(source)
            return if (isNearDuplicate(fallback, title)) "" else fallback
        }

        if (sentences.size <= maxSentences) {
            return capLength(sentences.joinToString(" "))
        }

        val scored = scoreSentences(sentences)
        val selected = selectDiverseSentences(scored, maxSentences)
            .sortedBy { it.index }
            .map { it.sentence }

        return capLength(selected.joinToString(" "))
    }

    /** Сжимает описание новости из RSS. */
    fun summarize(item: NewsItem, maxSentences: Int = 8): String =
        summarize(item.title, item.rawDescription, maxSentences)

    /** Ключевые слова новости — для чипов-тегов в интерфейсе. */
    fun keywords(item: NewsItem, limit: Int = 4): List<String> {
        val words = tokenize(item.title) + tokenize(item.rawDescription)
        val frequency = mutableMapOf<String, Int>()
        val firstSeenOrder = mutableListOf<String>()
        for (word in words) {
            if (word !in frequency) firstSeenOrder.add(word)
            frequency[word] = (frequency[word] ?: 0) + 1
        }
        return firstSeenOrder
            .sortedByDescending { frequency[it] ?: 0 }
            .take(limit)
            .map { it.replaceFirstChar { c -> c.titlecase(Locale.getDefault()) } }
    }

    /** Формирует сводный дайджест по категории: список заголовков с краткими описаниями. */
    fun digest(category: NewsCategory, items: List<NewsItem>, language: AppLanguage, limit: Int = 5): String {
        val selected = items
            .filter { it.category == category }
            .sortedByDescending { it.pubDateMillis ?: Long.MIN_VALUE }
            .take(limit)

        if (selected.isEmpty()) {
            return L10n.tf("digest.empty", language, category.localizedName(language))
        }

        return selected.mapIndexed { index, item ->
            if (item.summary.isEmpty()) "${index + 1}. ${item.title}"
            else "${index + 1}. ${item.title} — ${item.summary}"
        }.joinToString("\n")
    }

    /** Число предложений в уже готовом тексте. */
    fun sentenceCount(text: String): Int = splitIntoSentences(text).size

    // MARK: - Внутренняя механика

    private data class ScoredSentence(
        val sentence: String,
        val score: Double,
        val index: Int,
        val words: Set<String>
    )

    /**
     * Обрезает текст по последней границе предложения в пределах лимита,
     * а не посреди слова.
     */
    private fun capLength(text: String): String {
        if (text.length <= MAX_SUMMARY_LENGTH) return text
        val truncated = text.substring(0, MAX_SUMMARY_LENGTH)
        val lastBoundary = Regex("[.!?…]\\s").findAll(truncated).lastOrNull()
        return if (lastBoundary != null) {
            truncated.substring(0, lastBoundary.range.last + 1).trim()
        } else {
            truncated.trim() + "…"
        }
    }

    /**
     * Разбивает текст на предложения через BreakIterator вместо наивного
     * разделения по точкам — иначе текст резался бы и на сокращениях
     * ("т.д.", "г.", "т.е."), и на десятичных числах ("3.5%").
     */
    private fun splitIntoSentences(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val iterator = BreakIterator.getSentenceInstance(Locale.getDefault())
        iterator.setText(text)
        val sentences = mutableListOf<String>()
        var start = iterator.first()
        var end = iterator.next()
        while (end != BreakIterator.DONE) {
            val sentence = text.substring(start, end).trim()
            if (sentence.length > 3) sentences.add(sentence)
            start = end
            end = iterator.next()
        }
        return sentences
    }

    private fun dedupedSentences(rawSentences: List<String>): List<String> {
        val result = mutableListOf<String>()
        for (sentence in rawSentences) {
            val trimmed = sentence.trim()
            if (trimmed.isEmpty()) continue
            if (result.any { isNearDuplicate(it, trimmed) }) continue
            result.add(trimmed)
        }
        return result
    }

    /**
     * Схожесть двух фраз по пересечению значимых слов (индекс Жаккара).
     * Ловит не только точные повторы, но и переформулировки.
     */
    private fun isNearDuplicate(a: String, b: String, threshold: Double = 0.6): Boolean {
        val wordsA = tokenize(a).toSet()
        val wordsB = tokenize(b).toSet()
        if (wordsA.isEmpty() || wordsB.isEmpty()) return a.equals(b, ignoreCase = true)
        val intersection = wordsA.intersect(wordsB).size
        val union = wordsA.union(wordsB).size
        if (union == 0) return false
        return intersection.toDouble() / union.toDouble() >= threshold
    }

    private fun scoreSentences(sentences: List<String>): List<ScoredSentence> {
        val wordFrequency = mutableMapOf<String, Int>()
        val allWords = sentences.flatMap { tokenize(it) }
        for (word in allWords) {
            wordFrequency[word] = (wordFrequency[word] ?: 0) + 1
        }

        return sentences.mapIndexed { index, sentence ->
            val words = tokenize(sentence)
            val rawScore = words.sumOf { (wordFrequency[it] ?: 0).toDouble() }
            val normalized = if (words.isEmpty()) 0.0 else rawScore / words.size
            // Небольшой бонус первому предложению — обычно оно самое информативное.
            val positionBonus = if (index == 0) 1.5 else 1.0
            ScoredSentence(sentence, normalized * positionBonus, index, words.toSet())
        }
    }

    /**
     * Жадный отбор по принципу MMR (Maximal Marginal Relevance): на каждом
     * шаге берём предложение с лучшим балансом "важно" и "не похоже на уже
     * выбранное".
     */
    private fun selectDiverseSentences(scored: List<ScoredSentence>, limit: Int): List<ScoredSentence> {
        val remaining = scored.toMutableList()
        val picked = mutableListOf<ScoredSentence>()
        val lambda = 0.55

        while (picked.size < limit && remaining.isNotEmpty()) {
            var bestIndex = 0
            var bestValue = Double.NEGATIVE_INFINITY
            for (i in remaining.indices) {
                val candidate = remaining[i]
                val maxOverlap = picked.maxOfOrNull { jaccard(candidate.words, it.words) } ?: 0.0
                val value = lambda * candidate.score - (1 - lambda) * maxOverlap * candidate.score
                if (value > bestValue) {
                    bestValue = value
                    bestIndex = i
                }
            }
            picked.add(remaining.removeAt(bestIndex))
        }
        return picked
    }

    private fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val intersection = a.intersect(b).size
        val union = a.union(b).size
        return if (union == 0) 0.0 else intersection.toDouble() / union.toDouble()
    }

    private fun tokenize(text: String): List<String> =
        text.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length > 2 && it !in stopWords }
}
