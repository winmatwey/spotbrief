package ru.matwey.spotbrief

import android.app.Application
import ru.matwey.spotbrief.data.BookmarksStore
import ru.matwey.spotbrief.data.CustomSourcesStore
import ru.matwey.spotbrief.data.NewsAggregatorService
import ru.matwey.spotbrief.data.NewsCache
import ru.matwey.spotbrief.data.ReadStore
import ru.matwey.spotbrief.data.SettingsStore
import ru.matwey.spotbrief.speech.SpeechReader

/**
 * Держит единственные на всё приложение экземпляры хранилищ и сервиса —
 * аналог `@StateObject`-полей в SpotBriefApp.swift, которые прокидывались
 * через `.environmentObject(...)`. В Compose роль environmentObject играет
 * CompositionLocal (см. ui/AppState.kt) — сюда он читает эти же объекты.
 */
class SpotBriefApplication : Application() {
    lateinit var settings: SettingsStore
        private set
    lateinit var bookmarks: BookmarksStore
        private set
    lateinit var readStore: ReadStore
        private set
    lateinit var customSources: CustomSourcesStore
        private set
    lateinit var newsCache: NewsCache
        private set
    lateinit var service: NewsAggregatorService
        private set
    lateinit var speechReader: SpeechReader
        private set

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore(this)
        bookmarks = BookmarksStore(this)
        readStore = ReadStore(this)
        customSources = CustomSourcesStore(this)
        newsCache = NewsCache(this)
        service = NewsAggregatorService(this, settings, customSources, newsCache)
        speechReader = SpeechReader(this)
    }
}
