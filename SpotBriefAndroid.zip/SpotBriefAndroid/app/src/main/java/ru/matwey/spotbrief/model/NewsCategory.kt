package ru.matwey.spotbrief.model

import kotlinx.serialization.Serializable
import ru.matwey.spotbrief.data.AppLanguage
import ru.matwey.spotbrief.data.L10n

/**
 * Категории новостей. `rawValue` в Swift-версии был русским названием и
 * служил стабильным ключом для JSON-кэша — здесь ту же роль играет `id`,
 * он же используется как значение при (де)сериализации, чтобы формат кэша
 * не зависел от текущего языка интерфейса.
 */
@Serializable
enum class NewsCategory(val id: String) {
    POLITICS("Политика"),
    SPORTS("Спорт"),
    ECONOMY("Экономика"),
    TECHNOLOGY("Технологии"),
    SCIENCE("Наука"),
    CULTURE("Культура"),
    INCIDENTS("Происшествия"),
    SOCIETY("Общество");

    /** Локализованное имя категории для интерфейса. */
    fun localizedName(language: AppLanguage): String = when (this) {
        POLITICS -> L10n.t("category.politics", language)
        SPORTS -> L10n.t("category.sports", language)
        ECONOMY -> L10n.t("category.economy", language)
        TECHNOLOGY -> L10n.t("category.technology", language)
        SCIENCE -> L10n.t("category.science", language)
        CULTURE -> L10n.t("category.culture", language)
        INCIDENTS -> L10n.t("category.incidents", language)
        SOCIETY -> L10n.t("category.society", language)
    }

    /**
     * Имя иконки Material Symbols — аналог SF Symbol systemName из Swift-версии.
     * Сопоставление со конкретным `ImageVector` живёт в UI-слое (см.
     * `ui/CategoryIcons.kt`), а не здесь — так же, как в Swift-версии
     * `Image(systemName:)` разрешал строку в конкретную иконку только
     * непосредственно во View.
     */
    val iconKey: String
        get() = when (this) {
            POLITICS -> "account_balance"
            SPORTS -> "sports_soccer"
            ECONOMY -> "trending_up"
            TECHNOLOGY -> "memory"
            SCIENCE -> "science"
            CULTURE -> "theater_comedy"
            INCIDENTS -> "warning"
            SOCIETY -> "groups"
        }

    /**
     * Ключевые слова для эвристической классификации новости по заголовку
     * и описанию. Однословные ключи проверяются как ЦЕЛОЕ слово (см.
     * NewsCategorizer), а не как подстрока — иначе, например, "банк" ложно
     * срабатывал бы внутри "банкет". Фразы из нескольких слов весят больше
     * (см. вес в NewsCategorizer.categorize). Списки включают русские,
     * английские и немецкие термины, так как источники в приложении на
     * трёх языках.
     */
    val keywords: List<String>
        get() = when (this) {
            POLITICS -> listOf(
                "президент", "путин", "госдума", "министр", "выборы", "закон",
                "кремль", "правительство", "сенат", "парламент", "оон", "нато",
                "санкции", "дипломат", "переговоры", "губернатор", "депутат", "указ",
                "referendum", "референдум", "чиновник", "кабмин", "мид", "минобороны",
                "государственная дума", "совет безопасности", "совет федерации",
                "лига наций", "лига арабских государств", "белый дом", "евросоюз",
                "president", "kremlin", "parliament", "sanctions", "diplomat", "nato",
                "election", "elections", "congress", "senate", "governor", "white house",
                "foreign ministry", "state department", "european union", "prime minister",
                "bundestag", "bundeskanzler", "kanzler", "bundesregierung", "wahl", "minister"
            )
            SPORTS -> listOf(
                "футбол", "хоккей", "баскетбол", "теннис", "волейбол", "матч",
                "чемпионат", "олимпиада", "сборная", "спортсмен", "гол", "тренер",
                "турнир", "медаль", "фифа", "уефа", "чемпионат мира по футболу",
                "олимпийские игры", "кубок мира", "лига чемпионов", "футбольная лига",
                "чемпионат россии по футболу", "football", "soccer", "hockey",
                "basketball", "tennis", "goal", "referee", "athlete", "olympics",
                "world cup", "champions league", "premier league", "medal", "coach",
                "fußball", "bundesliga", "olympiade", "meisterschaft", "turnier"
            )
            ECONOMY -> listOf(
                "рубль", "доллар", "евро", "инфляция", "банк", "ввп", "нефть",
                "биржа", "акции", "экономика", "бюджет", "налог", "цена", "рынок",
                "инвестиции", "курс валют", "центральный банк", "мировая экономика",
                "цена на нефть", "федеральная резервная система", "economy", "inflation",
                "stock market", "gdp", "dollar", "euro", "central bank", "stock exchange",
                "oil price", "investment", "recession", "wirtschaft", "inflation",
                "aktien", "zentralbank", "rezession", "bruttoinlandsprodukt"
            )
            TECHNOLOGY -> listOf(
                "технологии", "смартфон", "нейросеть", "стартап", "гаджет", "робот",
                "процессор", "мобильное приложение", "искусственный интеллект",
                "software", "hardware", "apple", "google", "microsoft", "tesla",
                "spacex", "стартапы", "спутник", "ракета", "technology", "startup",
                "gadget", "processor", "chip", "artificial intelligence", "app store",
                "technologie", "digitalisierung", "künstliche intelligenz", "raumfahrt"
            )
            SCIENCE -> listOf(
                "учёный", "исследование", "открытие", "университет", "медицина",
                "вакцина", "генетика", "археолог", "nasa", "роскосмос", "scientist",
                "research", "study", "university", "vaccine", "genetics", "archaeology",
                "discovery", "wissenschaft", "forschung", "studie", "universität",
                "impfstoff", "genetik"
            )
            CULTURE -> listOf(
                "фильм", "кино", "музыка", "театр", "выставка", "концерт", "актёр",
                "режиссёр", "книга", "фестиваль", "музей", "премьера", "film",
                "cinema", "music", "concert", "actor", "director", "museum",
                "festival", "premiere", "kultur", "musik", "theater", "ausstellung"
            )
            INCIDENTS -> listOf(
                "пожар", "авария", "дтп", "взрыв", "погиб", "убийство", "происшествие",
                "чп", "эвакуация", "разыскивают", "задержан", "уголовное дело", "суд",
                "землетрясение", "наводнение", "fire", "explosion", "earthquake",
                "flood", "crash", "killed", "arrested", "accident", "unfall", "brand",
                "erdbeben", "explosion"
            )
            SOCIETY -> emptyList()
        }
}
