package ru.matwey.spotbrief.data

import kotlinx.serialization.Serializable
import ru.matwey.spotbrief.model.NewsSource

/**
 * Регион пользователя. Определяет, какие новостные агентства предлагаются
 * в приложении. Выбирается один раз при первом запуске и может быть
 * изменён позже в настройках.
 */
@Serializable
enum class Region(val code: String) {
    RUSSIA("russia"),
    KAZAKHSTAN("kazakhstan"),
    USA("usa"),
    UK("uk"),
    GERMANY("germany");

    val flag: String
        get() = when (this) {
            RUSSIA -> "\uD83C\uDDF7\uD83C\uDDFA"
            KAZAKHSTAN -> "\uD83C\uDDF0\uD83C\uDDFF"
            USA -> "\uD83C\uDDFA\uD83C\uDDF8"
            UK -> "\uD83C\uDDEC\uD83C\uDDE7"
            GERMANY -> "\uD83C\uDDE9\uD83C\uDDEA"
        }

    fun localizedName(language: AppLanguage): String = when (this) {
        RUSSIA -> L10n.t("region.russia", language)
        KAZAKHSTAN -> L10n.t("region.kazakhstan", language)
        USA -> L10n.t("region.usa", language)
        UK -> L10n.t("region.uk", language)
        GERMANY -> L10n.t("region.germany", language)
    }

    companion object {
        fun fromCode(code: String?): Region? = entries.firstOrNull { it.code == code }
    }
}

/**
 * Список источников для конкретного региона. Фактическую доступность
 * каждого источника с устройства пользователя проверяет
 * SourceAvailabilityChecker — см. пояснение в оригинальном Region.swift.
 */
object RegionSources {

    fun sources(for_: Region): List<NewsSource> = when (for_) {
        Region.RUSSIA -> russiaSources
        Region.KAZAKHSTAN -> kazakhstanSources
        Region.USA -> usaSources
        Region.UK -> ukSources
        Region.GERMANY -> germanySources
    }

    // Источники, отмеченные isWhitelisted = true, образуют подборку
    // "режима белых списков" — см. подробное пояснение в SettingsStore.kt.
    private val russiaSources = listOf(
        NewsSource(name = "РИА Новости", feedUrl = "https://ria.ru/export/rss2/index.xml", isWhitelisted = true),
        NewsSource(name = "ТАСС", feedUrl = "https://tass.ru/rss/v2.xml", isWhitelisted = true),
        NewsSource(name = "Lenta.ru", feedUrl = "https://lenta.ru/rss/news", isWhitelisted = true),
        NewsSource(name = "РБК", feedUrl = "https://rssexport.rbc.ru/rbcnews/news/30/full.rss", isWhitelisted = true),
        NewsSource(name = "Коммерсантъ", feedUrl = "https://www.kommersant.ru/RSS/news.xml", isWhitelisted = true),
        NewsSource(name = "Чемпионат", feedUrl = "https://www.championat.com/rss/news.xml", isWhitelisted = true),
        NewsSource(name = "Habr", feedUrl = "https://habr.com/ru/rss/all/all/", isWhitelisted = true),
        NewsSource(name = "N+1", feedUrl = "https://nplus1.ru/rss", isWhitelisted = true),
        NewsSource(name = "Meduza", feedUrl = "https://meduza.io/rss2/all"),
        NewsSource(name = "Вести.ру", feedUrl = "https://www.vesti.ru/vesti.rss", isWhitelisted = true),
        NewsSource(name = "Новые Известия", feedUrl = "https://newizv.ru/rss", isWhitelisted = true),
        NewsSource(name = "Экономика и жизнь", feedUrl = "https://www.eg-online.ru/news/news_rss.php?SID=605", isWhitelisted = true),
        NewsSource(name = "НВО (Независимое военное обозрение)", feedUrl = "https://nvo.ng.ru/rss/"),
        NewsSource(name = "Chita.ru", feedUrl = "https://www.chita.ru/rss-feeds/rss.xml"),
        NewsSource(name = "Tverlife.ru", feedUrl = "https://tverlife.ru/feed/"),
        NewsSource(name = "Province.ru", feedUrl = "https://www.province.ru/rss/"),
        NewsSource(name = "АиФ Адыгея", feedUrl = "https://adigea.aif.ru/rss/googlearticles", isWhitelisted = true),
        NewsSource(name = "Amic.ru", feedUrl = "https://feeds.feedburner.com/amic/news"),
        NewsSource(name = "Nnews.nnov.ru", feedUrl = "https://nnews.nnov.ru/rss")
    )

    private val kazakhstanSources = listOf(
        NewsSource(name = "Tengrinews (English)", feedUrl = "http://en.tengrinews.kz/news.rss"),
        NewsSource(name = "The Astana Times", feedUrl = "https://astanatimes.com/feed/atom/"),
        NewsSource(name = "Time.kz", feedUrl = "https://time.kz/rss"),
        NewsSource(name = "Lada.kz", feedUrl = "https://www.lada.kz/rss.xml"),
        NewsSource(name = "eKaraganda.kz", feedUrl = "https://ekaraganda.kz/rss.php"),
        NewsSource(name = "Ng.kz", feedUrl = "https://www.ng.kz/modules/newspaper/cache/newspaper.xml"),
        NewsSource(name = "Liter.kz", feedUrl = "https://liter.kz/feed/"),
        NewsSource(name = "Zakon.kz", feedUrl = "https://www.zakon.kz/rss/"),
        NewsSource(name = "Caravan.kz", feedUrl = "https://www.caravan.kz/rss/"),
        NewsSource(name = "Kursiv Media", feedUrl = "https://kz.kursiv.media/feed/"),
        NewsSource(name = "Informburo.kz", feedUrl = "https://informburo.kz/rss.xml"),
        NewsSource(name = "Kazpravda.kz", feedUrl = "https://kazpravda.kz/rss")
    )

    private val usaSources = listOf(
        NewsSource(name = "NBC News", feedUrl = "https://feeds.nbcnews.com/nbcnews/public/news"),
        NewsSource(name = "CBS News", feedUrl = "https://www.cbsnews.com/feeds/rss/main.rss"),
        NewsSource(name = "PBS NewsHour", feedUrl = "https://www.pbs.org/newshour/feeds/rss/headlines"),
        NewsSource(name = "UPI — U.S. News", feedUrl = "https://rss.upi.com/news/tn_us.rss"),
        NewsSource(name = "The New York Times", feedUrl = "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml"),
        NewsSource(name = "WSJ — U.S. News", feedUrl = "https://feeds.content.dowjones.io/public/rss/RSSUSnews"),
        NewsSource(name = "Los Angeles Times", feedUrl = "https://www.latimes.com/local/rss2.0.xml"),
        NewsSource(name = "New York Post", feedUrl = "https://nypost.com/feed/"),
        NewsSource(name = "The Washington Times", feedUrl = "https://www.washingtontimes.com/rss/headlines/news"),
        NewsSource(name = "Vox", feedUrl = "https://www.vox.com/rss/index.xml"),
        NewsSource(name = "Business Insider", feedUrl = "https://feeds.businessinsider.com/custom/all"),
        NewsSource(name = "POLITICO", feedUrl = "https://www.politico.com/rss/politicopicks.xml"),
        NewsSource(name = "Fox Business", feedUrl = "https://moxie.foxbusiness.com/google-publisher/latest.xml"),
        NewsSource(name = "Newsweek", feedUrl = "https://www.newsweek.com/rss"),
        NewsSource(name = "The Atlantic", feedUrl = "https://www.theatlantic.com/feed/all/"),
        NewsSource(name = "The New Yorker", feedUrl = "https://www.newyorker.com/feed/rss"),
        NewsSource(name = "NPR", feedUrl = "https://www.npr.org/rss/rss.php?id=1001"),
        NewsSource(name = "ProPublica", feedUrl = "https://www.propublica.org/feeds/propublica/main"),
        NewsSource(name = "Mother Jones", feedUrl = "https://www.motherjones.com/feed/"),
        NewsSource(name = "The Hill", feedUrl = "https://thehill.com/feed/"),
        NewsSource(name = "Salon", feedUrl = "https://www.salon.com/feed"),
        NewsSource(name = "RealClearPolitics", feedUrl = "https://www.realclearpolitics.com/index.xml"),
        NewsSource(name = "The Daily Wire", feedUrl = "https://www.dailywire.com/feeds/rss.xml"),
        NewsSource(name = "Breitbart", feedUrl = "https://feeds.feedburner.com/breitbart"),
        NewsSource(name = "Observer", feedUrl = "https://observer.com/feed/")
    )

    private val ukSources = listOf(
        NewsSource(name = "BBC News", feedUrl = "https://feeds.bbci.co.uk/news/rss.xml"),
        NewsSource(name = "BBC — UK", feedUrl = "https://feeds.bbci.co.uk/news/uk/rss.xml"),
        NewsSource(name = "BBC — World", feedUrl = "https://feeds.bbci.co.uk/news/world/rss.xml"),
        NewsSource(name = "BBC — Business", feedUrl = "https://feeds.bbci.co.uk/news/business/rss.xml"),
        NewsSource(name = "BBC — Technology", feedUrl = "https://feeds.bbci.co.uk/news/technology/rss.xml"),
        NewsSource(name = "Sky News", feedUrl = "https://feeds.skynews.com/feeds/rss/home.xml"),
        NewsSource(name = "The Guardian — UK", feedUrl = "https://www.theguardian.com/uk/rss"),
        NewsSource(name = "The Guardian — World", feedUrl = "https://www.theguardian.com/world/rss"),
        NewsSource(name = "The Telegraph", feedUrl = "https://www.telegraph.co.uk/rss.xml"),
        NewsSource(name = "The Independent", feedUrl = "https://www.independent.co.uk/news/uk/rss"),
        NewsSource(name = "Evening Standard", feedUrl = "https://www.standard.co.uk/news/rss"),
        NewsSource(name = "HuffPost UK", feedUrl = "https://www.huffingtonpost.co.uk/feeds/index.xml")
    )

    private val germanySources = listOf(
        NewsSource(name = "Der Spiegel — Politik", feedUrl = "https://www.spiegel.de/politik/index.rss"),
        NewsSource(name = "Die Zeit", feedUrl = "https://newsfeed.zeit.de/index"),
        NewsSource(name = "Die Zeit — Politik", feedUrl = "https://newsfeed.zeit.de/politik/index"),
        NewsSource(name = "tagesschau", feedUrl = "https://www.tagesschau.de/index~rss2.xml"),
        NewsSource(name = "Bundesregierung (офиц.)", feedUrl = "https://www.bundesregierung.de/SiteGlobals/Functions/RSSFeed/DE/RSSNewsfeed/RSS_Breg_aktuell/RSSNewsfeed.xml"),
        NewsSource(name = "FAZ", feedUrl = "https://www.faz.net/rss/aktuell/"),
        NewsSource(name = "Handelsblatt", feedUrl = "https://www.handelsblatt.com/contentexport/feed/schlagzeilen"),
        NewsSource(name = "Süddeutsche Zeitung", feedUrl = "https://rss.sueddeutsche.de/rss/Topthemen"),
        NewsSource(name = "Focus Online", feedUrl = "https://rss.focus.de/fol/XML/rss_folnews.xml"),
        NewsSource(name = "WELT", feedUrl = "https://www.welt.de/feeds/latest.rss"),
        NewsSource(name = "Heise Online", feedUrl = "https://www.heise.de/rss/heise-atom.xml"),
        NewsSource(name = "Netzpolitik.org", feedUrl = "https://netzpolitik.org/feed/")
    )
}
