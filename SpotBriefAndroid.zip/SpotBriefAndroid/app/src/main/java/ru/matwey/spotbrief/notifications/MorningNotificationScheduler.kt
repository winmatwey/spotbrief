package ru.matwey.spotbrief.notifications

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.launch
import ru.matwey.spotbrief.MainActivity
import ru.matwey.spotbrief.R
import ru.matwey.spotbrief.data.AppLanguage
import ru.matwey.spotbrief.data.DailyDigest
import java.util.Calendar

/**
 * Планирует ежедневное локальное уведомление со сводкой (аналог
 * MorningNotificationScheduler.swift + UNCalendarNotificationTrigger).
 *
 * Про свежесть содержимого — то же ограничение, что и в iOS-версии: у
 * приложения нет своего сервера, поэтому текст уведомления — это снимок
 * сводки на момент, когда приложение ПОСЛЕДНИЙ РАЗ обновляло ленту, а не
 * "сводка ровно на 8:00". NewsAggregatorService переставляет будильник
 * заново с актуальным текстом после каждого успешного refreshAll().
 *
 * AlarmManager, а не WorkManager: нужен показ ТОЧНО в выбранное
 * пользователем время суток (аналог UNCalendarNotificationTrigger
 * dateMatching: hour/minute, repeats: true) — WorkManager подходит для
 * периодических фоновых задач, но не гарантирует точное время показа.
 */
object MorningNotificationScheduler {
    private const val CHANNEL_ID = "spotbrief_morning_digest"
    private const val REQUEST_CODE = 1001
    private const val DEBUG_REQUEST_CODE = 1002
    private const val NOTIFICATION_ID = 2001
    private const val DEBUG_NOTIFICATION_ID = 2002
    const val EXTRA_TITLE = "extra_title"
    const val EXTRA_BODY = "extra_body"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID, "SpotBrief — сводка дня", NotificationManager.IMPORTANCE_DEFAULT
        )
        manager.createNotificationChannel(channel)
    }

    /**
     * Переставляет ежедневное уведомление на заданное время с текстом из
     * digest. Если digest пуст, уведомление снимается — рассылать пустую
     * сводку нет смысла.
     */
    fun reschedule(context: Context, digest: DailyDigest, hour: Int, minute: Int, title: String, language: AppLanguage) {
        cancel(context)
        if (digest.isEmpty) return

        val body = digest.notificationBody(language)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, MorningNotificationReceiver::class.java).apply {
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_BODY, body)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerAt = nextTriggerTime(hour, minute)
        setExactRepeating(alarmManager, triggerAt, pendingIntent)
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, MorningNotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    /**
     * Присылает тестовое уведомление через несколько секунд — аналог
     * fireTestNotification в отладочном меню (DebugMenuView).
     */
    fun fireTestNotification(context: Context, digest: DailyDigest, title: String, language: AppLanguage) {
        val body = if (digest.isEmpty) "Debug test notification — SpotBrief" else digest.notificationBody(language)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, MorningNotificationReceiver::class.java).apply {
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_BODY, body)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, DEBUG_REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 3_000, pendingIntent)
    }

    @SuppressLint("MissingPermission")
    fun showNotification(context: Context, title: String, body: String, isDebug: Boolean = false) {
        ensureChannel(context)
        val openAppIntent = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_notification)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent)
            .build()

        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(if (isDebug) DEBUG_NOTIFICATION_ID else NOTIFICATION_ID, notification)
    }

    @SuppressLint("MissingPermission")
    private fun setExactRepeating(alarmManager: AlarmManager, triggerAt: Long, pendingIntent: PendingIntent) {
        // На Android нет единого "ежедневного точного будильника" —
        // AlarmManager.setRepeating() не гарантирует точность на API 19+.
        // Поэтому MorningNotificationReceiver сам переставляет себя на
        // следующий день (+ 24 часа) после срабатывания — см. ресивер.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            // Разрешение на точные будильники не выдано — используем
            // неточный будильник как запасной вариант, чтобы уведомление
            // всё равно приходило, пусть и не строго вовремя.
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            return
        }
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
    }

    private fun nextTriggerTime(hour: Int, minute: Int): Long {
        val now = Calendar.getInstance()
        val trigger = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (trigger.before(now)) trigger.add(Calendar.DAY_OF_YEAR, 1)
        return trigger.timeInMillis
    }
}

/**
 * Показывает уведомление, когда срабатывает будильник, и сразу
 * переставляет себя на следующий день — заменяет `repeats: true` из
 * UNCalendarNotificationTrigger, у AlarmManager такого параметра нет.
 */
class MorningNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(MorningNotificationScheduler.EXTRA_TITLE) ?: "SpotBrief"
        val body = intent.getStringExtra(MorningNotificationScheduler.EXTRA_BODY) ?: return
        MorningNotificationScheduler.showNotification(context, title, body)

        // Переставляем на завтра в то же время, используя актуальный на тот
        // момент digest (записанный при последнем refreshAll()) — если
        // приложение с тех пор обновляло ленту, содержимое будет свежее.
        val app = context.applicationContext as? ru.matwey.spotbrief.SpotBriefApplication ?: return
        val settings = app.settings
        if (!settings.morningNotificationsEnabled.value) return

        // newsCache.load() — suspend-функция (чтение с диска в фоне, см.
        // Persistence.kt), а onReceive() у BroadcastReceiver не corutine и
        // не может просто вызвать suspend-функцию. goAsync() продлевает
        // жизнь ресивера на время фоновой работы — без этого система могла
        // бы убить процесс до того, как чтение с диска и showNotification
        // успеют доработать.
        val pendingResult = goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val cache = app.newsCache.load()
                val digest = DailyDigest.build(cache?.first ?: emptyList())
                MorningNotificationScheduler.reschedule(
                    context, digest,
                    settings.morningNotificationHour.value,
                    settings.morningNotificationMinute.value,
                    settings.t("notification.morningTitle"),
                    settings.effectiveLanguage
                )
            } finally {
                pendingResult.finish()
            }
        }
    }
}
