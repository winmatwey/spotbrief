@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.matwey.spotbrief.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import ru.matwey.spotbrief.data.ArticleContentFetcher
import ru.matwey.spotbrief.data.NewsSummarizer
import ru.matwey.spotbrief.data.SortOrder
import ru.matwey.spotbrief.model.NewsItem
import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.ui.LocalAppContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CategoryDetailScreen(category: NewsCategory, onOpenItem: (NewsItem) -> Unit, onBack: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val service = app.service
    val readStore = app.readStore

    val allItems by service.items.collectAsState()
    val sortOrder by settings.sortOrder.collectAsState()
    var sortMenuExpanded by remember { mutableStateOf(false) }

    val categoryItems = remember(allItems, category) { allItems.filter { it.category == category } }
    val sortedItems = remember(categoryItems, sortOrder) {
        when (sortOrder) {
            SortOrder.NEWEST -> categoryItems.sortedByDescending { it.pubDateMillis ?: Long.MIN_VALUE }
            SortOrder.SOURCE -> categoryItems.sortedBy { it.sourceName }
            SortOrder.READING_TIME -> categoryItems.sortedBy { it.readingTimeMinutes }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(category.localizedName(settings.effectiveLanguage)) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null) }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            item {
                Text(
                    settings.t("category.digest"),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                Text(
                    NewsSummarizer.digest(category, allItems, settings.effectiveLanguage),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(settings.t("category.sortPicker"), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.padding(start = 8.dp))
                    Box {
                        TextButton(onClick = { sortMenuExpanded = true }) {
                            Text(sortOrder.localizedName(settings.effectiveLanguage))
                        }
                        DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                            SortOrder.entries.forEach { order ->
                                DropdownMenuItem(
                                    text = { Text(order.localizedName(settings.effectiveLanguage)) },
                                    onClick = { settings.setSortOrder(order); sortMenuExpanded = false }
                                )
                            }
                        }
                    }
                }
                HorizontalDivider(Modifier.padding(top = 12.dp))
            }

            item {
                Text(
                    settings.tf("category.allNews", sortedItems.size),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            items(sortedItems, key = { it.stableId }) { item ->
                NewsRow(item = item, onClick = { onOpenItem(item) })
            }
        }
    }
}

@Composable
private fun NewsRow(item: NewsItem, onClick: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val readStore = app.readStore
    val bookmarks = app.bookmarks
    val readIds by readStore.readIds.collectAsState()
    val bookmarkedIds by bookmarks.bookmarks.collectAsState()
    val isRead = item.stableId in readIds
    val isBookmarked = bookmarkedIds.any { it.stableId == item.stableId }

    Column(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isRead) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    maxLines = 3
                )
                val summary = item.summary.ifEmpty { settings.t("summary.unavailable") }
                Text(
                    summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, fontStyle = if (item.summary.isEmpty()) FontStyle.Italic else FontStyle.Normal
                )
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                    Text(item.allSourceNames.joinToString(", "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                    item.pubDateMillis?.let {
                        Text(" · " + SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(it)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    }
                    Spacer(Modifier.padding(start = 6.dp))
                    Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.outline)
                    Text(settings.tf("newsRow.readingTimeShort", item.readingTimeMinutes), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                }
            }
            IconButton(onClick = { bookmarks.toggle(item) }) {
                Icon(
                    if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun NewsDetailScreen(item: NewsItem, onBack: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val bookmarks = app.bookmarks
    val readStore = app.readStore
    val speech = app.speechReader
    val context = LocalContext.current

    var fullArticleText by remember(item.stableId) { mutableStateOf<String?>(null) }
    var isLoadingFullText by remember(item.stableId) { mutableStateOf(false) }

    val bookmarkedIds by bookmarks.bookmarks.collectAsState()
    val isBookmarked = bookmarkedIds.any { it.stableId == item.stableId }
    val isSpeaking by speech.isSpeaking.collectAsState()
    val speakingId by speech.speakingItemId.collectAsState()
    val isSpeakingThisItem = isSpeaking && speakingId == item.stableId

    val displaySummary = remember(fullArticleText) {
        val text = fullArticleText
        if (text.isNullOrEmpty()) item.summary
        else NewsSummarizer.summarize(item.title, text, maxSentences = 8)
    }
    val isExpanded = fullArticleText != null && displaySummary.length > item.summary.length

    LaunchedEffect(item.stableId) {
        readStore.markRead(item)
    }

    LaunchedEffect(item.stableId) {
        val link = item.link
        if (link == null || ArticleContentFetcher.isLikelyMultiTopicContent(item.title, item.rawDescription)) return@LaunchedEffect
        isLoadingFullText = true
        fullArticleText = try {
            ArticleContentFetcher.fetchArticleText(link, item.title)
        } catch (e: Exception) {
            null
        }
        isLoadingFullText = false
    }

    androidx.compose.runtime.DisposableEffect(item.stableId) {
        onDispose {
            if (isSpeakingThisItem) speech.stop()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(item.category.localizedName(settings.effectiveLanguage)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null) } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            Text(item.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.padding(top = 8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.allSourceNames.joinToString(", "), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.weight(1f))
                item.pubDateMillis?.let {
                    Text(SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(it)), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(settings.tf("content.readingTime", item.readingTimeMinutes), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            HorizontalDivider(Modifier.padding(vertical = 16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(settings.t("detail.summary"), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = {
                    speech.toggle(item.stableId, "${item.title}. $displaySummary", settings.effectiveLanguage.speechLanguageCode)
                }) {
                    Icon(if (isSpeakingThisItem) Icons.Filled.StopCircle else Icons.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.padding(start = 4.dp))
                    Text(if (isSpeakingThisItem) settings.t("detail.stop") else settings.t("detail.listen"))
                }
            }
            Spacer(Modifier.padding(top = 8.dp))
            val shown = displaySummary.ifEmpty { settings.t("summary.unavailable") }
            Text(shown, style = MaterialTheme.typography.bodyLarge, fontStyle = if (displaySummary.isEmpty()) FontStyle.Italic else FontStyle.Normal)

            if (isLoadingFullText) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp))
                    Spacer(Modifier.padding(start = 6.dp))
                    Text(settings.t("detail.loadingFull"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else if (isExpanded) {
                Text(settings.t("detail.expandedFromArticle"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
            }

            val tags = remember(item.stableId) { NewsSummarizer.keywords(item) }
            if (tags.isNotEmpty()) {
                Row(modifier = Modifier.padding(top = 12.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tags.forEach { tag ->
                        Text(
                            tag, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            if (!isExpanded && item.rawDescription.isNotEmpty() && item.rawDescription != item.summary) {
                Spacer(Modifier.padding(top = 16.dp))
                Text(settings.t("detail.fullDescription"), style = MaterialTheme.typography.titleMedium)
                Text(item.rawDescription, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(Modifier.padding(top = 16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { bookmarks.toggle(item) }) {
                    Icon(if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.padding(start = 4.dp))
                    Text(if (isBookmarked) settings.t("detail.bookmarked") else settings.t("detail.bookmark"))
                }
                item.link?.let { link ->
                    OutlinedButton(onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, link)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, null))
                    }) {
                        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.padding(start = 4.dp))
                        Text(settings.t("detail.share"))
                    }
                }
            }

            item.link?.let { link ->
                Spacer(Modifier.padding(top = 12.dp))
                TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, link.toUri())) }) {
                    Icon(Icons.Filled.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.padding(start = 4.dp))
                    Text(settings.t("detail.openSource"))
                }
            }
        }
    }
}
