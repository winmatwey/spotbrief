package ru.matwey.spotbrief.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Раньше здесь были заданы только primary/secondary, а весь остальной набор
 * ролей (фон, поверхности, контейнеры) брался из стандартной Material3-схемы,
 * которая сама по себе фиолетовая — отсюда и ощущение "цвета не сочетаются":
 * оранжевый акцент буквально сидел поверх чужой, несогласованной палитры.
 * Теперь описана полная схема ролей для обеих тем — все цвета подобраны
 * вокруг одного тёплого оранжево-красного акцента, а не смешаны из двух
 * разных наборов.
 */
val SpotBriefOrange = Color(0xFFFF6B00)
val SpotBriefRed = Color(0xFFE53935)

private val LightColors = lightColorScheme(
    primary = Color(0xFFC1490A),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFDBC7),
    onPrimaryContainer = Color(0xFF3A1300),

    secondary = Color(0xFFB3261E),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFDAD6),
    onSecondaryContainer = Color(0xFF410E0B),

    tertiary = Color(0xFF6B5B00),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFE289),
    onTertiaryContainer = Color(0xFF221B00),

    background = Color(0xFFFFFBF7),
    onBackground = Color(0xFF251A12),
    surface = Color(0xFFFFFBF7),
    onSurface = Color(0xFF251A12),
    surfaceVariant = Color(0xFFF3DFD2),
    onSurfaceVariant = Color(0xFF52443A),

    outline = Color(0xFF847469),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB68C),
    onPrimary = Color(0xFF5A2000),
    primaryContainer = Color(0xFF7F3300),
    onPrimaryContainer = Color(0xFFFFDBC7),

    secondary = Color(0xFFFFB4A9),
    onSecondary = Color(0xFF690003),
    secondaryContainer = Color(0xFF930006),
    onSecondaryContainer = Color(0xFFFFDAD6),

    tertiary = Color(0xFFE5C440),
    onTertiary = Color(0xFF383000),
    tertiaryContainer = Color(0xFF514500),
    onTertiaryContainer = Color(0xFFFFE289),

    background = Color(0xFF1C130D),
    onBackground = Color(0xFFF0DFD4),
    surface = Color(0xFF1C130D),
    onSurface = Color(0xFFF0DFD4),
    surfaceVariant = Color(0xFF52443A),
    onSurfaceVariant = Color(0xFFD7C3B5),

    outline = Color(0xFF9F8E82),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

@Composable
fun SpotBriefTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
