@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.matwey.spotbrief.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.matwey.spotbrief.model.NewsItem
import ru.matwey.spotbrief.ui.LocalAppContainer

@Composable
fun SearchScreen(onOpenItem: (NewsItem) -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val service = app.service
    var query by remember { mutableStateOf("") }
    val results = remember(query) { service.search(query) }

    Scaffold(
        topBar = { TopAppBar(title = { Text(settings.t("tab.search")) }) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(settings.t("search.prompt")) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            )

            when {
                query.isEmpty() -> EmptyState(settings.t("search.emptyTitle"), settings.t("search.emptyDescription"))
                results.isEmpty() -> EmptyState(settings.t("search.noResults"), "")
                else -> LazyColumn {
                    items(results, key = { it.stableId }) { item ->
                        Column(
                            Modifier.fillMaxWidth().clickable { onOpenItem(item) }.padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(
                                item.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                                maxLines = 2,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Text(
                                "${item.category.localizedName(settings.effectiveLanguage)} · ${item.allSourceNames.joinToString(", ")}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, description: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (description.isNotEmpty()) {
                Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
