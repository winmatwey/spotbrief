package ru.matwey.spotbrief.data

import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.model.NewsItem
import kotlin.math.abs

/**
 * Объединяет одну и ту же новость, пришедшую от нескольких РАЗНЫХ
 * источников, в одну карточку в ленте. Работает по сходству ЗАГОЛОВКОВ
 * (индекс Жаккара) и по близости времени публикации. См. подробное
 * объяснение в оригинальном NewsDeduplicator.swift.
 */
object NewsDeduplicator {
    private const val TITLE_SIMILARITY_THRESHOLD = 0.45
    private const val MAX_PUBLICATION_GAP_MILLIS = 20L * 60 * 60 * 1000
    private const val MAX_GROUP_SIZE = 6

    fun merge(items: List<NewsItem>): List<NewsItem> {
        val byCategory = items.groupBy { it.category }
        val result = mutableListOf<NewsItem>()
        for (category in NewsCategory.entries) {
            val group = byCategory[category] ?: continue
            result.addAll(mergeWithinCategory(group))
        }
        return result
    }

    private fun mergeWithinCategory(items: List<NewsItem>): List<NewsItem> {
        val remaining = items.toMutableList()
        val result = mutableListOf<NewsItem>()

        while (remaining.isNotEmpty()) {
            val base = remaining.removeAt(0)
            val group = mutableListOf(base)

            var index = 0
            while (index < remaining.size && group.size < MAX_GROUP_SIZE) {
                val candidate = remaining[index]
                if (isSameStory(base, candidate) && group.none { it.sourceName == candidate.sourceName }) {
                    group.add(remaining.removeAt(index))
                } else {
                    index++
                }
            }

            result.add(combine(group))
        }

        return result
    }

    private fun isSameStory(a: NewsItem, b: NewsItem): Boolean {
        if (a.sourceName == b.sourceName) return false

        val dateA = a.pubDateMillis
        val dateB = b.pubDateMillis
        if (dateA != null && dateB != null) {
            if (abs(dateA - dateB) > MAX_PUBLICATION_GAP_MILLIS) return false
        }

        return titleSimilarity(a.title, b.title) >= TITLE_SIMILARITY_THRESHOLD
    }

    private fun titleSimilarity(a: String, b: String): Double {
        val wordsA = significantWords(a).toSet()
        val wordsB = significantWords(b).toSet()
        if (wordsA.isEmpty() || wordsB.isEmpty()) return 0.0
        val intersection = wordsA.intersect(wordsB).size
        val union = wordsA.union(wordsB).size
        return if (union == 0) 0.0 else intersection.toDouble() / union.toDouble()
    }

    private fun significantWords(text: String): List<String> =
        text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 2 }

    /**
     * Выбирает "представителя" группы дублей — новость с самым длинным
     * тизером — и подставляет ему остальные источники и их ссылки, а также
     * заменяет описание на объединение тизеров ВСЕХ источников группы.
     *
     * Дата публикации объединённой карточки — ОТДЕЛЬНО от выбора текста:
     * это всегда самая свежая дата среди всех источников группы, а не дата
     * того источника, чьё описание оказалось длиннее всех. Раньше это было
     * одно и то же поле — и если в группу по сходству заголовков попадала
     * старая новость с более развёрнутым (но при этом устаревшим) текстом,
     * именно её дата показывалась на карточке, даже когда остальные
     * источники в той же группе были сегодняшними. Теперь текст и дата
     * выбираются независимо друг от друга.
     */
    private fun combine(group: List<NewsItem>): NewsItem {
        if (group.size <= 1) return group[0]

        val sorted = group.sortedWith(
            compareByDescending<NewsItem> { it.rawDescription.length }.thenBy { it.sourceName }
        )

        val representative = sorted[0]
        val others = sorted.drop(1)

        representative.mergedSourceNames = others.map { it.sourceName }.sorted()
        representative.mergedLinks = others.mapNotNull { it.link }
        representative.rawDescription = (listOf(representative.rawDescription) + others.map { it.rawDescription })
            .filter { it.isNotEmpty() }
            .joinToString(" ")

        val freshestDate = group.mapNotNull { it.pubDateMillis }.maxOrNull()
        return if (freshestDate != null && freshestDate != representative.pubDateMillis) {
            representative.copy(pubDateMillis = freshestDate)
        } else {
            representative
        }
    }
}
