package ru.matwey.spotbrief.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import ru.matwey.spotbrief.model.NewsItem
import java.io.File

/**
 * Файловое JSON-хранилище — аналог UserDefaults + JSONEncoder/JSONDecoder
 * из Persistence.swift. На Android для такого объёма данных (список
 * новостей) файл во внутреннем хранилище приложения — более подходящий
 * аналог, чем SharedPreferences (тот не предназначен для больших значений).
 *
 * ВАЖНО: чтение и запись файлов — блокирующие операции. Раньше они
 * выполнялись прямо в конструкторе хранилища (то есть в Application.onCreate,
 * на ГЛАВНОМ потоке) и прямо в обработчике нажатия (toggle/markRead — тоже
 * главный поток). На большом кэше новостей или скоплении закладок это
 * ощутимая блокировка UI — именно то, что выглядит как "зависание". Теперь
 * все файловые операции явно уходят в Dispatchers.IO через собственный
 * фоновый CoroutineScope каждого хранилища.
 */
private val json = Json { ignoreUnknownKeys = true }

private fun fileFor(context: Context, name: String): File = File(context.filesDir, name)

private inline fun <reified T> readJson(context: Context, name: String): T? {
    val file = fileFor(context, name)
    if (!file.exists()) return null
    return try {
        json.decodeFromString<T>(file.readText())
    } catch (e: Exception) {
        null
    }
}

private inline fun <reified T> writeJson(context: Context, name: String, value: T) {
    try {
        fileFor(context, name).writeText(json.encodeToString(value))
    } catch (e: Exception) {
        // Не критично — как и в Swift-версии, ошибка записи в кэш не должна
        // ронять приложение, просто данные не переживут перезапуск.
    }
}

/** Хранилище избранных новостей. Переживает перезапуск приложения (файл + JSON). */
class BookmarksStore(private val context: Context) {
    private val fileName = "spotbrief_bookmarks_v1.json"
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _bookmarks = MutableStateFlow<List<NewsItem>>(emptyList())
    val bookmarks: StateFlow<List<NewsItem>> = _bookmarks.asStateFlow()

    init {
        // Загрузка с диска — в фоне, а не в конструкторе (тот вызывается из
        // Application.onCreate на главном потоке). Пока файл не прочитан,
        // список закладок временно пуст — на практике это доли секунды,
        // и UI уже подписан на bookmarks через StateFlow, так что обновится
        // сам, как только чтение завершится.
        ioScope.launch {
            val loaded = readJson<List<NewsItem>>(context, fileName)
            if (loaded != null) _bookmarks.value = loaded
        }
    }

    fun isBookmarked(item: NewsItem): Boolean = _bookmarks.value.any { it.stableId == item.stableId }

    fun toggle(item: NewsItem) {
        _bookmarks.value = if (isBookmarked(item)) {
            _bookmarks.value.filterNot { it.stableId == item.stableId }
        } else {
            listOf(item) + _bookmarks.value
        }
        save()
    }

    /** Полная очистка избранного — используется отладочным меню. */
    fun removeAll() {
        _bookmarks.value = emptyList()
        save()
    }

    private fun save() {
        val snapshot = _bookmarks.value
        ioScope.launch { writeJson(context, fileName, snapshot) }
    }
}

/** Отслеживает прочитанные новости, чтобы притемнять их в лентах. */
class ReadStore(private val context: Context) {
    private val fileName = "spotbrief_read_v1.json"
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _readIds = MutableStateFlow<Set<String>>(emptySet())
    val readIds: StateFlow<Set<String>> = _readIds.asStateFlow()

    init {
        ioScope.launch {
            val loaded = readJson<List<String>>(context, fileName)
            if (loaded != null) _readIds.value = loaded.toSet()
        }
    }

    fun isRead(item: NewsItem): Boolean = item.stableId in _readIds.value

    fun markRead(item: NewsItem) {
        if (item.stableId in _readIds.value) return
        _readIds.value = _readIds.value + item.stableId
        val snapshot = _readIds.value
        ioScope.launch { writeJson(context, fileName, snapshot.toList()) }
    }

    /** Сбрасывает все отметки "прочитано" — используется отладочным меню. */
    fun clearAll() {
        _readIds.value = emptySet()
        ioScope.launch { fileFor(context, fileName).delete() }
    }
}

/**
 * Офлайн-кэш последней успешно загруженной ленты — приложение показывает
 * эти новости мгновенно при запуске, ещё до завершения сетевого запроса.
 */
class NewsCache(private val context: Context) {
    private val itemsFile = "spotbrief_cache_v1.json"
    private val dateFile = "spotbrief_cache_date_v1.json"

    /** Пишет кэш на диск. Не suspend — сама уходит в фон, вызывающему коду ждать не нужно. */
    fun save(items: List<NewsItem>) {
        CoroutineScope(Dispatchers.IO).launch {
            writeJson(context, itemsFile, items)
            writeJson(context, dateFile, System.currentTimeMillis())
        }
    }

    /** Suspend — вызывающий код сам решает, в каком контексте загружать (см. NewsAggregatorService.init). */
    suspend fun load(): Pair<List<NewsItem>, Long>? = withContext(Dispatchers.IO) {
        val items = readJson<List<NewsItem>>(context, itemsFile) ?: return@withContext null
        val date = readJson<Long>(context, dateFile) ?: System.currentTimeMillis()
        items to date
    }

    /** Стирает офлайн-кэш ленты — используется отладочным меню. */
    fun clear() {
        CoroutineScope(Dispatchers.IO).launch {
            fileFor(context, itemsFile).delete()
            fileFor(context, dateFile).delete()
        }
    }
}
