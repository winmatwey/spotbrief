package ru.matwey.spotbrief.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.matwey.spotbrief.data.L10n
import ru.matwey.spotbrief.data.Region
import ru.matwey.spotbrief.data.RegionSources
import ru.matwey.spotbrief.data.SourceAvailabilityChecker
import ru.matwey.spotbrief.ui.LocalAppContainer

/**
 * Экран выбора региона — второй шаг онбординга (после языка) и отдельный
 * экран из настроек. Аналог RegionPickerView.swift.
 */
@Composable
fun RegionPickerScreen(onFinished: (() -> Unit)?) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val service = app.service
    val language = settings.effectiveLanguage
    val scope = rememberCoroutineScope()
    val checker = remember { SourceAvailabilityChecker() }

    var selected by remember { mutableStateOf<Region?>(null) }
    var isChecking by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 24.dp))
        Spacer(Modifier.padding(top = 8.dp))
        Text(L10n.t("region.title", language), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(L10n.t("region.subtitle", language), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.padding(top = 16.dp))

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(Region.entries) { region ->
                val isSelected = selected == region
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant)
                        .border(
                            width = if (isSelected) 1.5.dp else 0.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { selected = region }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(region.flag, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.padding(start = 12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(region.localizedName(language), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            L10n.tf("region.sourcesCount", language, RegionSources.sources(for_ = region).size),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (isSelected) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        Button(
            onClick = {
                val region = selected ?: return@Button
                isChecking = true
                service.updateRegion(region)
                scope.launch {
                    checker.check(RegionSources.sources(for_ = region))
                    isChecking = false
                    onFinished?.invoke()
                }
            },
            enabled = selected != null && !isChecking,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isChecking) CircularProgressIndicator(modifier = Modifier.size(18.dp)) else Text(L10n.t("common.continue", language))
        }
    }
}
