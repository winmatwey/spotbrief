package ru.matwey.spotbrief.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.matwey.spotbrief.data.AddSourceError
import ru.matwey.spotbrief.data.AddSourceResult
import ru.matwey.spotbrief.ui.LocalAppContainer

/** Форма добавления собственного RSS-источника — аналог AddCustomSourceView.swift. */
@Composable
fun AddCustomSourceDialog(onDismiss: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val customSources = app.customSources
    val service = app.service
    val scope = rememberCoroutineScope()
    val language = settings.effectiveLanguage

    var name by remember { mutableStateOf("") }
    var urlString by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(settings.t("addSource.title")) },
        text = {
            Column {
                Text(settings.t("addSource.nameLabel"), style = MaterialTheme.typography.labelMedium)
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    placeholder = { Text(settings.t("addSource.namePlaceholder")) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Text(settings.t("addSource.urlLabel"), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 12.dp))
                OutlinedTextField(
                    value = urlString, onValueChange = { urlString = it },
                    placeholder = { Text(settings.t("addSource.urlPlaceholder")) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                errorMessage?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && urlString.isNotBlank(),
                onClick = {
                    when (val result = customSources.add(name, urlString)) {
                        is AddSourceResult.Success -> {
                            service.refreshSources()
                            scope.launch { service.refreshAll() }
                            onDismiss()
                        }
                        is AddSourceResult.Failure -> {
                            errorMessage = when (result.error) {
                                AddSourceError.EmptyName -> settings.t("addSource.errorEmptyName")
                                AddSourceError.InvalidUrl -> settings.t("addSource.errorInvalidURL")
                                AddSourceError.DuplicateUrl -> settings.t("addSource.errorDuplicate")
                            }
                        }
                    }
                }
            ) { Text(settings.t("addSource.add")) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(settings.t("addSource.cancel")) }
        }
    )
}
