package ru.matwey.spotbrief

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.core.content.ContextCompat
import ru.matwey.spotbrief.notifications.MorningNotificationScheduler
import ru.matwey.spotbrief.ui.LocalAppContainer
import ru.matwey.spotbrief.ui.RootScreen
import ru.matwey.spotbrief.ui.theme.SpotBriefTheme

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* результат читаем через hasNotificationPermission() при следующем обращении */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MorningNotificationScheduler.ensureChannel(this)

        val app = application as SpotBriefApplication

        setContent {
            SpotBriefTheme {
                // Раньше "Размер текста" в настройках сохранялся в
                // SettingsStore, но нигде не применялся к самому интерфейсу —
                // ползунок двигал только образец текста в самих настройках,
                // а не реальный размер шрифта во всём приложении. Единый
                // способ масштабировать ВЕСЬ Compose-текст (sp-размеры везде,
                // включая уже написанные экраны) — подменить LocalDensity.fontScale
                // здесь, в корне дерева, а не переписывать размер шрифта
                // в каждом отдельном Text().
                val userFontScale by app.settings.fontScale.collectAsState()
                val baseDensity = LocalDensity.current
                val scaledDensity = Density(
                    density = baseDensity.density,
                    fontScale = baseDensity.fontScale * userFontScale
                )

                // Surface красит фон в MaterialTheme.colorScheme.background и
                // задаёт LocalContentColor по умолчанию (contentColorFor(background)) —
                // без него экраны без своего Scaffold (в первую очередь
                // онбординг — выбор языка и региона) остаются на системном
                // белом фоне окна, а текст без явного цвета рисуется чёрным
                // по умолчанию, полностью игнорируя тему приложения.
                CompositionLocalProvider(
                    LocalDensity provides scaledDensity,
                    LocalAppContainer provides app
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        RootScreen(
                            requestNotificationPermission = { requestNotificationPermissionIfNeeded() }
                        )
                    }
                }
            }
        }
    }

    /**
     * Аналог MorningNotificationScheduler.requestAuthorizationIfNeeded() —
     * на Android 13+ (API 33) POST_NOTIFICATIONS нужно запрашивать явно в
     * рантайме, на более старых версиях разрешение выдаётся автоматически
     * при установке.
     */
    fun hasNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (!hasNotificationPermission()) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        (application as SpotBriefApplication).speechReader.shutdown()
    }
}
