package ru.matwey.spotbrief.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import ru.matwey.spotbrief.model.NewsSource
import java.net.URI
import java.util.UUID

private val customSourcesJson = Json { ignoreUnknownKeys = true }

/**
 * Источник, добавленный пользователем вручную (не из курируемого списка
 * региона). См. CustomSourcesStore.swift.
 */
@Serializable
data class CustomSource(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val feedUrlString: String
) {
    val asNewsSource: NewsSource
        get() = NewsSource(name = name, feedUrl = feedUrlString)
}

sealed class AddSourceError {
    data object EmptyName : AddSourceError()
    data object InvalidUrl : AddSourceError()
    data object DuplicateUrl : AddSourceError()
}

sealed class AddSourceResult {
    data class Success(val source: CustomSource) : AddSourceResult()
    data class Failure(val error: AddSourceError) : AddSourceResult()
}

/**
 * Хранилище пользовательских источников. Переживает перезапуск приложения,
 * не зависит от выбранного региона.
 *
 * Как и в Persistence.kt: чтение при старте и запись при add()/remove()
 * раньше были синхронными и блокирующими — а вызывались с главного потока
 * (конструктор — из Application.onCreate, add()/remove() — прямо из
 * обработчика нажатия в диалоге добавления источника). Теперь обе операции
 * уходят в Dispatchers.IO.
 */
class CustomSourcesStore(private val context: Context) {
    private val fileName = "spotbrief_custom_sources_v1.json"
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _sources = MutableStateFlow<List<CustomSource>>(emptyList())
    val sources: StateFlow<List<CustomSource>> = _sources.asStateFlow()

    val asNewsSources: List<NewsSource> get() = _sources.value.map { it.asNewsSource }

    init {
        ioScope.launch {
            val loaded = loadFromDisk()
            if (loaded.isNotEmpty()) _sources.value = loaded
        }
    }

    /**
     * Добавляет источник после базовой валидации. Не проверяет, что по
     * адресу действительно лежит RSS/Atom — это делает
     * SourceAvailabilityChecker сразу после добавления.
     */
    fun add(name: String, urlString: String): AddSourceResult {
        val trimmedName = name.trim()
        val trimmedUrl = urlString.trim()

        if (trimmedName.isEmpty()) return AddSourceResult.Failure(AddSourceError.EmptyName)

        // Многие пользователи копируют адрес без схемы — подставляем https://.
        val normalized = if (trimmedUrl.contains("://")) trimmedUrl else "https://$trimmedUrl"

        val uri = try { URI(normalized) } catch (e: Exception) { null }
        val scheme = uri?.scheme?.lowercase()
        val host = uri?.host
        if (uri == null || (scheme != "http" && scheme != "https") || host.isNullOrEmpty()) {
            return AddSourceResult.Failure(AddSourceError.InvalidUrl)
        }

        if (_sources.value.any { it.feedUrlString.equals(normalized, ignoreCase = true) }) {
            return AddSourceResult.Failure(AddSourceError.DuplicateUrl)
        }

        val source = CustomSource(name = trimmedName, feedUrlString = normalized)
        _sources.value = _sources.value + source
        save()
        return AddSourceResult.Success(source)
    }

    fun remove(source: CustomSource) {
        _sources.value = _sources.value.filterNot { it.id == source.id }
        save()
    }

    private fun loadFromDisk(): List<CustomSource> {
        val file = java.io.File(context.filesDir, fileName)
        if (!file.exists()) return emptyList()
        return try {
            customSourcesJson.decodeFromString<List<CustomSource>>(file.readText())
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save() {
        val snapshot = _sources.value
        ioScope.launch {
            try {
                java.io.File(context.filesDir, fileName)
                    .writeText(customSourcesJson.encodeToString(snapshot))
            } catch (e: Exception) {
                // не критично
            }
        }
    }
}
