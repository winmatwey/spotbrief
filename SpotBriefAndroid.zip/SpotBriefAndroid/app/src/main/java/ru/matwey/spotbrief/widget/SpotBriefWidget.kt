package ru.matwey.spotbrief.widget

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import ru.matwey.spotbrief.data.WidgetSharedDigest
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Виджет на главном экране со сводкой дня — реально работающий аналог
 * WidgetExtension-Reference/ из iOS-версии (там это была только заготовка
 * кода для будущего расширения, см. подробное объяснение в
 * WidgetSharedDigest.kt про то, почему на Android это не нужно).
 */
class SpotBriefWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val payload = WidgetSharedDigest.load(context)
        provideContent {
            Column(
                modifier = androidx.glance.GlanceModifier
                    .fillMaxSize()
                    .background(Color(0xFF1C1C1E))
                    .padding(12.dp)
            ) {
                Text(
                    text = "SpotBrief",
                    style = TextStyle(color = ColorProvider(Color(0xFFFF6B00)), fontWeight = FontWeight.Bold)
                )
                if (payload == null || payload.entries.isEmpty()) {
                    Text(
                        text = "Нет данных — откройте приложение",
                        style = TextStyle(color = ColorProvider(Color.White))
                    )
                } else {
                    for (entry in payload.entries.take(4)) {
                        Text(
                            text = "${entry.category}: ${entry.title}",
                            maxLines = 2,
                            style = TextStyle(color = ColorProvider(Color.White))
                        )
                    }
                }
            }
        }
    }
}

class SpotBriefWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = SpotBriefWidget()
}

/** Просит систему перерисовать все размещённые виджеты после обновления ленты. */
object SpotBriefWidgetUpdater {
    fun requestUpdate(context: Context) {
        GlobalScope.launch(Dispatchers.IO) {
            try {
                SpotBriefWidget().updateAll(context)
            } catch (e: Exception) {
                // Виджет мог быть не размещён на экране — это не ошибка.
            }
        }
    }
}
