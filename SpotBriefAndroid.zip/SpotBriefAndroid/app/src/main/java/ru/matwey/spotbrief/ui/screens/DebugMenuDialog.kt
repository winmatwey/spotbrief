package ru.matwey.spotbrief.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import ru.matwey.spotbrief.data.DailyDigest
import ru.matwey.spotbrief.notifications.MorningNotificationScheduler
import ru.matwey.spotbrief.ui.LocalAppContainer

/**
 * Отладочное меню — облегчённый аналог DebugMenuView.swift (там 500+
 * строк с расширенной статистикой; здесь только сами действия, которые
 * NewsAggregatorService.debug*() и хранилища уже предоставляют).
 * Открывается долгим нажатием на строку в разделе "О приложении" в
 * SettingsScreen, как и в оригинале.
 */
@Composable
fun DebugMenuDialog(onDismiss: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val service = app.service
    val bookmarks = app.bookmarks
    val readStore = app.readStore
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(settings.t("debug.title")) },
        text = {
            Column {
                DebugAction(settings.t("debug.mockFeed")) { service.debugPopulateMockFeed() }
                DebugAction(settings.t("debug.clearFeed")) { service.debugClearFeed() }
                DebugAction(settings.t("debug.injectError")) {
                    service.debugInjectSampleError("Debug Source: не удалось загрузить (test error)")
                }
                DebugAction(settings.t("debug.testNotification")) {
                    val digest = DailyDigest.build(service.items.value)
                    MorningNotificationScheduler.fireTestNotification(
                        context, digest, settings.t("notification.morningTitle"), settings.effectiveLanguage
                    )
                }
                DebugAction(settings.t("debug.clearBookmarksRead")) {
                    bookmarks.removeAll()
                    readStore.clearAll()
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(settings.t("addSource.cancel")) }
        }
    )
}

@Composable
private fun DebugAction(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.fillMaxWidth())
    }
}
