@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package ru.matwey.spotbrief.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch
import ru.matwey.spotbrief.data.AppLanguage
import ru.matwey.spotbrief.data.Region
import ru.matwey.spotbrief.data.RegionSources
import ru.matwey.spotbrief.data.SourceAvailability
import ru.matwey.spotbrief.data.SourceAvailabilityChecker
import ru.matwey.spotbrief.model.NewsSource
import ru.matwey.spotbrief.notifications.MorningNotificationScheduler
import ru.matwey.spotbrief.ui.LocalAppContainer
import androidx.compose.foundation.layout.RowScope

@Composable
fun SettingsScreen(requestNotificationPermission: () -> Unit) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val service = app.service
    val customSources = app.customSources
    val scope = rememberCoroutineScope()
    val checker = remember { SourceAvailabilityChecker() }

    val region by settings.region.collectAsState()
    val language by settings.language.collectAsState()
    val lowDataMode by settings.lowDataMode.collectAsState()
    val whitelistMode by settings.whitelistMode.collectAsState()
    val morningEnabled by settings.morningNotificationsEnabled.collectAsState()
    val morningHour by settings.morningNotificationHour.collectAsState()
    val morningMinute by settings.morningNotificationMinute.collectAsState()
    val autoRefresh by settings.autoRefreshMinutes.collectAsState()
    val fontScale by settings.fontScale.collectAsState()
    val mutedSources by settings.mutedSources.collectAsState()
    val customSourceList by customSources.sources.collectAsState()
    val serviceSources by service.sources.collectAsState()
    val statuses by checker.statuses.collectAsState()

    var showRegionPicker by remember { mutableStateOf(false) }
    var showLanguagePicker by remember { mutableStateOf(false) }
    var showAddSource by remember { mutableStateOf(false) }
    var showDebugMenu by remember { mutableStateOf(false) }
    var notificationDenied by remember { mutableStateOf(false) }

    val builtInSources = region?.let { RegionSources.sources(for_ = it) } ?: emptyList()

    LaunchedEffect(serviceSources) {
        checker.check(serviceSources)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(settings.t("tab.settings")) }) }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding)) {
            // Язык
            item {
                SettingsSection(settings.t("settings.language"), settings.t("settings.languageFooter")) {
                    ClickableRow(
                        leading = settings.effectiveLanguage.flag,
                        text = settings.effectiveLanguage.nativeName,
                        onClick = { showLanguagePicker = true }
                    )
                }
            }

            // Регион
            item {
                SettingsSection(settings.t("settings.region"), settings.t("settings.regionFooter")) {
                    ClickableRow(
                        leading = region?.flag ?: "\uD83C\uDF0D",
                        text = region?.localizedName(settings.effectiveLanguage) ?: settings.t("settings.regionNotSelected"),
                        onClick = { showRegionPicker = true }
                    )
                }
            }

            // Низкий трафик
            item {
                SettingsSection(settings.t("settings.lowDataModeHeader"), settings.t("settings.lowDataModeFooter")) {
                    ToggleRow(settings.t("settings.lowDataMode"), lowDataMode) {
                        settings.setLowDataMode(it)
                        scope.launch { service.refreshAll() }
                    }
                }
            }

            // Белые списки (только Россия)
            if (region == Region.RUSSIA) {
                item {
                    SettingsSection(settings.t("settings.whitelistModeHeader"), settings.t("settings.whitelistModeFooter")) {
                        ToggleRow(settings.t("settings.whitelistMode"), whitelistMode) {
                            settings.setWhitelistMode(it)
                            service.refreshSources()
                            scope.launch { service.refreshAll() }
                        }
                    }
                }
            }

            // Утренние уведомления
            item {
                SettingsSection(settings.t("settings.morningNotificationsHeader"), settings.t("settings.morningNotificationsFooter")) {
                    Column {
                        ToggleRow(settings.t("settings.morningNotifications"), morningEnabled) { isOn ->
                            if (isOn) {
                                requestNotificationPermission()
                                settings.setMorningNotificationsEnabled(true)
                                val digest = ru.matwey.spotbrief.data.DailyDigest.build(service.items.value)
                                MorningNotificationScheduler.reschedule(
                                    app, digest, morningHour, morningMinute,
                                    settings.t("notification.morningTitle"), settings.effectiveLanguage
                                )
                            } else {
                                settings.setMorningNotificationsEnabled(false)
                                MorningNotificationScheduler.cancel(app)
                            }
                        }
                        if (morningEnabled) {
                            TimePickerRow(
                                label = settings.t("settings.morningNotificationsTime"),
                                hour = morningHour, minute = morningMinute
                            ) { h, m ->
                                settings.setMorningNotificationTime(h, m)
                                val digest = ru.matwey.spotbrief.data.DailyDigest.build(service.items.value)
                                MorningNotificationScheduler.reschedule(
                                    app, digest, h, m, settings.t("notification.morningTitle"), settings.effectiveLanguage
                                )
                            }
                        }
                        if (notificationDenied) {
                            Text(
                                settings.t("settings.morningNotificationsDenied"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Автообновление
            item {
                SettingsSection(settings.t("settings.autoRefresh"), null) {
                    IntervalPicker(current = autoRefresh, settings = settings) { minutes ->
                        settings.setAutoRefreshMinutes(minutes)
                        service.scheduleAutoRefresh()
                    }
                }
            }

            // Размер текста
            item {
                SettingsSection(settings.t("settings.fontSize"), null) {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        Slider(
                            value = fontScale, onValueChange = { settings.setFontScale(it) },
                            valueRange = 0.85f..1.4f, steps = 10
                        )
                        Text(
                            settings.t("settings.sampleTitle"),
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Встроенные источники
            item {
                SettingsSection(settings.tf("settings.sourcesHeader", builtInSources.size), settings.t("settings.sourcesFooter")) {
                    Column {
                        builtInSources.forEach { source ->
                            SourceToggleRow(
                                source = source,
                                status = statuses[source.feedUrl] ?: SourceAvailability.CHECKING,
                                isEnabled = !mutedSources.contains(source.name),
                                onToggle = { settings.toggleMute(source) }
                            )
                        }
                    }
                }
            }

            // Свои источники
            item {
                SettingsSection(settings.t("settings.customSources"), settings.t("settings.customSourcesFooter")) {
                    Column {
                        if (customSourceList.isEmpty()) {
                            Text(
                                settings.t("settings.noCustomSources"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                            )
                        } else {
                            customSourceList.forEach { source ->
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AvailabilityIcon(statuses[source.feedUrlString] ?: SourceAvailability.CHECKING)
                                    Spacer(Modifier.padding(start = 8.dp))
                                    Text(source.name, modifier = Modifier.weight(1f))
                                    IconButton(onClick = {
                                        customSources.remove(source)
                                        service.refreshSources()
                                    }) {
                                        Icon(Icons.Filled.Delete, contentDescription = null)
                                    }
                                }
                            }
                        }
                        ClickableRow(leading = null, icon = Icons.Filled.Add, text = settings.t("settings.addSource"), onClick = { showAddSource = true })
                    }
                }
            }

            // О приложении
            item {
                SettingsSection(settings.t("settings.about"), settings.t("settings.aboutFooter")) {
                    Column {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
                        ) {
                            Text(settings.t("settings.appName"))
                            Text(settings.t("app.name"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .combinedClickable(onClick = {}, onLongClick = { showDebugMenu = true })
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
                        ) {
                            Text(settings.t("settings.newsSourcesCount"))
                            Text(serviceSources.size.toString(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    if (showRegionPicker) {
        Dialog(onDismissRequest = { showRegionPicker = false }) {
            androidx.compose.material3.Surface(shape = MaterialTheme.shapes.large) {
                RegionPickerScreen(onFinished = { showRegionPicker = false })
            }
        }
    }
    if (showLanguagePicker) {
        Dialog(onDismissRequest = { showLanguagePicker = false }) {
            androidx.compose.material3.Surface(shape = MaterialTheme.shapes.large) {
                LanguagePickerScreen(onFinished = { showLanguagePicker = false })
            }
        }
    }
    if (showAddSource) {
        AddCustomSourceDialog(onDismiss = { showAddSource = false })
    }
    if (showDebugMenu) {
        DebugMenuDialog(onDismiss = { showDebugMenu = false })
    }
}

@Composable
private fun SettingsSection(title: String, footer: String?, content: @Composable () -> Unit) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        content()
        footer?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        HorizontalDivider(Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun ClickableRow(leading: String?, icon: androidx.compose.ui.graphics.vector.ImageVector? = null, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            Text(leading, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.padding(start = 8.dp))
        }
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.padding(start = 8.dp))
        }
        Text(text, modifier = Modifier.weight(1f))
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ToggleRow(text: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun IntervalPicker(current: Int, settings: ru.matwey.spotbrief.data.SettingsStore, onSelect: (Int) -> Unit) {
    val options = listOf(
        0 to settings.t("settings.off"),
        5 to settings.t("settings.minutes5"),
        15 to settings.t("settings.minutes15"),
        30 to settings.t("settings.minutes30"),
        60 to settings.t("settings.hour1")
    )
    Column {
        options.forEach { (minutes, label) ->
            Row(
                Modifier.fillMaxWidth().clickable { onSelect(minutes) }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, modifier = Modifier.weight(1f))
                if (current == minutes) Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun TimePickerRow(label: String, hour: Int, minute: Int, onChange: (Int, Int) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable {
            android.app.TimePickerDialog(context, { _, h, m -> onChange(h, m) }, hour, minute, true).show()
        }.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Text(String.format("%02d:%02d", hour, minute), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SourceToggleRow(source: NewsSource, status: SourceAvailability, isEnabled: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AvailabilityIcon(status)
        Spacer(Modifier.padding(start = 8.dp))
        Text(source.name, modifier = Modifier.weight(1f))
        Switch(checked = isEnabled, onCheckedChange = { onToggle() })
    }
}

@Composable
private fun AvailabilityIcon(status: SourceAvailability) {
    when (status) {
        SourceAvailability.CHECKING -> CircularProgressIndicator(modifier = Modifier.size(14.dp))
        SourceAvailability.AVAILABLE -> Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = androidx.compose.ui.graphics.Color(0xFF4CAF50), modifier = Modifier.size(16.dp))
        SourceAvailability.UNAVAILABLE -> Icon(Icons.Filled.Error, contentDescription = null, tint = androidx.compose.ui.graphics.Color(0xFFF44336), modifier = Modifier.size(16.dp))
    }
}
