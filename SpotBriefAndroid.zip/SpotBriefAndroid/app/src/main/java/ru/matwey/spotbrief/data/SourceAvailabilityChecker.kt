package ru.matwey.spotbrief.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import ru.matwey.spotbrief.model.NewsSource
import java.net.HttpURLConnection
import java.net.URL

enum class SourceAvailability { CHECKING, AVAILABLE, UNAVAILABLE }

/**
 * Проверяет, отвечает ли RSS-лента конкретного источника прямо сейчас
 * с устройства пользователя — практическая проверка "доступности в
 * регионе". См. подробности в SourceAvailabilityChecker.swift.
 *
 * Ключ — адрес ленты (не NewsSource.id), т.к. id генерируется заново при
 * каждой пересборке списка источников.
 */
class SourceAvailabilityChecker {
    private val _statuses = MutableStateFlow<Map<String, SourceAvailability>>(emptyMap())
    val statuses: StateFlow<Map<String, SourceAvailability>> = _statuses.asStateFlow()

    private val maxConcurrentChecks = 6
    private val semaphore = Semaphore(maxConcurrentChecks)

    suspend fun check(sources: List<NewsSource>) = coroutineScope {
        _statuses.value = _statuses.value.toMutableMap().apply {
            for (source in sources) {
                if (this[key(source)] == null) this[key(source)] = SourceAvailability.CHECKING
            }
        }

        val jobs = sources.map { source ->
            async {
                val result = semaphore.withPermit { probe(source.feedUrl) }
                _statuses.value = _statuses.value.toMutableMap().apply { this[key(source)] = result }
            }
        }
        jobs.forEach { it.await() }
    }

    fun status(for_: NewsSource): SourceAvailability = _statuses.value[key(for_)] ?: SourceAvailability.CHECKING

    fun statusForUrl(url: String): SourceAvailability = _statuses.value[url] ?: SourceAvailability.CHECKING

    private fun key(source: NewsSource): String = source.feedUrl

    private suspend fun probe(url: String): SourceAvailability {
        if (attempt(url, "HEAD") == SourceAvailability.AVAILABLE) return SourceAvailability.AVAILABLE
        // Многие серверы отвечают на HEAD кодом 405 Method Not Allowed — это
        // не сетевая ошибка, а обычный ответ, поэтому всегда откатываемся на GET.
        return attempt(url, "GET")
    }

    private suspend fun attempt(urlString: String, method: String): SourceAvailability =
        withContext(Dispatchers.IO) {
            try {
                val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 8_000
                    readTimeout = 8_000
                    setRequestProperty("User-Agent", "Mozilla/5.0 (compatible; SpotBriefApp/1.0)")
                }
                val code = connection.responseCode
                connection.disconnect()
                // 2xx/3xx считаем доступным; некоторые ленты отвечают 403 на
                // HEAD, но сервер всё ещё достижим.
                if (code in 200..399) SourceAvailability.AVAILABLE else SourceAvailability.UNAVAILABLE
            } catch (e: Exception) {
                SourceAvailability.UNAVAILABLE
            }
        }
}
