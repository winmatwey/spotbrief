package ru.matwey.spotbrief.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ru.matwey.spotbrief.data.AppLanguage
import ru.matwey.spotbrief.data.L10n
import ru.matwey.spotbrief.ui.LocalAppContainer

/**
 * Экран выбора языка интерфейса — первый шаг онбординга и отдельный экран
 * из настроек. `onFinished == null` означает "это онбординг, закрывать
 * нечего" — аналог `var onFinished: (() -> Void)?` в LanguagePickerView.swift.
 */
@Composable
fun LanguagePickerScreen(onFinished: (() -> Unit)?) {
    val app = LocalAppContainer.current
    val settings = app.settings
    val currentLanguage by settings.language.collectAsState()
    var selected by remember { mutableStateOf<AppLanguage?>(null) }
    val displayLanguage = selected ?: currentLanguage ?: AppLanguage.RUSSIAN

    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 24.dp))
        Spacer(Modifier.padding(top = 8.dp))
        Text(L10n.t("language.title", displayLanguage), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(L10n.t("language.subtitle", displayLanguage), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.padding(top = 24.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            AppLanguage.entries.forEach { language ->
                val isSelected = selected == language || (selected == null && currentLanguage == language)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant)
                        .border(
                            width = if (isSelected) 1.5.dp else 0.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { selected = language }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(language.flag, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.padding(start = 12.dp))
                    Text(language.nativeName, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    if (isSelected) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        Button(
            onClick = {
                val language = selected ?: currentLanguage ?: return@Button
                settings.setLanguage(language)
                onFinished?.invoke()
            },
            enabled = selected != null || currentLanguage != null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(L10n.t("common.continue", displayLanguage))
        }
    }
}
