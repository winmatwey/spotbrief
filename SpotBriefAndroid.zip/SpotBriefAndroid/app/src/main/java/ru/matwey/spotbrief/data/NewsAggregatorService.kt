package ru.matwey.spotbrief.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.model.NewsItem
import ru.matwey.spotbrief.notifications.MorningNotificationScheduler
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Аналог NewsAggregatorService.NamedError из Swift-версии. */
private data class NamedError(val name: String, val message: String)

/**
 * Главный оркестратор: параллельно опрашивает все источники, объединяет,
 * классифицирует и суммирует новости. Прямой перенос
 * NewsAggregatorService.swift — тот же порядок шагов и те же комментарии
 * про причины именно такого порядка/лимитов, см. ниже по коду.
 */
class NewsAggregatorService(
    private val context: Context,
    private val settings: SettingsStore,
    private val customSources: CustomSourcesStore,
    private val newsCache: NewsCache
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _items = MutableStateFlow<List<NewsItem>>(emptyList())
    val items: StateFlow<List<NewsItem>> = _items.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _lastUpdatedMillis = MutableStateFlow<Long?>(null)
    val lastUpdatedMillis: StateFlow<Long?> = _lastUpdatedMillis.asStateFlow()

    private val _errors = MutableStateFlow<List<String>>(emptyList())
    val errors: StateFlow<List<String>> = _errors.asStateFlow()

    private val _sources = MutableStateFlow<List<ru.matwey.spotbrief.model.NewsSource>>(emptyList())
    val sources: StateFlow<List<ru.matwey.spotbrief.model.NewsSource>> = _sources.asStateFlow()

    private var autoRefreshJob: Job? = null

    // ВАЖНО: без этого замка `refreshAll()` мог запуститься одновременно из
    // нескольких мест сразу — pull-to-refresh, кнопка обновления, таймер
    // автообновления — и все они параллельно писали бы в один и тот же
    // НЕ потокобезопасный `expandedSummaryCache` (обычный HashMap). Именно
    // это было причиной частых крашей/зависаний: конкурентная запись в
    // HashMap может испортить его внутреннюю структуру и либо кинуть
    // исключение, либо уйти в бесконечный цикл при resize — на глаз это
    // выглядит именно как "зависло". Один `refreshAll()` за раз, остальные
    // вызовы, пока он не закончится, просто ничего не делают.
    private val refreshMutex = Mutex()

    // Лимит одновременных запросов полного текста статьи.
    private val maxConcurrentExpansions = 12
    private val expansionSemaphore = Semaphore(maxConcurrentExpansions)

    private val maxItemsPerSource = 80
    private val maxItemsPerSourceLowData = 25

    private val targetItemsPerCategory = 50
    private val maxItemsPerCategory = 65
    private val maxItemsPerCategoryLowData = 30

    private val maxLinksPerExpansion = 3

    // Раньше догрузка полного текста запускалась на ВСЕХ новостях с коротким
    // тизером сразу — при обычной ленте это легко полсотни-сотня новостей,
    // каждая по 1-3 сетевых запроса. Пока это всё не закончится, крутился
    // спиннер обновления — на практике ощущалось как зависшее приложение
    // на минуты. Теперь это ограничено сверху и, что важнее, вынесено из-под
    // спиннера (см. refreshAll): лента появляется сразу после разбора RSS,
    // а более длинные сводки дополняются в фоне.
    private val maxExpansionsPerRefresh = 40

    // Кэш уже "развёрнутых" (догруженных полным текстом) кратких содержаний
    // между обновлениями — по stableId новости. См. подробности в
    // NewsAggregatorService.swift.
    private val expandedSummaryCache = mutableMapOf<String, String>()
    private val expandedSummaryCacheMutex = Mutex()

    // Отдельный замок для фоновой догрузки полного текста — намеренно НЕ тот
    // же refreshMutex. Если бы использовали один и тот же, следующий
    // refreshAll() снова оказался бы заблокирован на всё время догрузки, то
    // есть мы вернулись бы к тому же багу, который только что починили выше.
    // Одновременно нам всё равно нужна защита от двух параллельных догрузок
    // (иначе снова конкурентная запись в expandedSummaryCache/_items) — этот
    // отдельный замок как раз её и даёт, никак не мешая refreshAll().
    private val expansionMutex = Mutex()

    init {
        refreshSources()
        scheduleAutoRefresh()
        // Загрузка офлайн-кэша — тоже в фоне (см. Persistence.kt): раньше
        // это было синхронным вызовом прямо в конструкторе, то есть в
        // Application.onCreate на главном потоке.
        scope.launch {
            newsCache.load()?.let { (cachedItems, cachedDate) ->
                _items.value = cachedItems
                _lastUpdatedMillis.value = cachedDate
                seedExpandedSummaryCache(cachedItems)
            }
        }
    }

    private fun seedExpandedSummaryCache(items: List<NewsItem>) {
        for (item in items) {
            if (NewsSummarizer.sentenceCount(item.summary) >= NewsSummarizer.MIN_SENTENCES) {
                expandedSummaryCache[item.stableId] = item.summary
            }
        }
    }

    /** Меняет активный регион и его набор источников. */
    fun updateRegion(region: Region) {
        settings.setRegion(region)
        refreshSources()
        _items.value = emptyList()
        _lastUpdatedMillis.value = null
        _errors.value = emptyList()
        scope.launch { refreshAll() }
    }

    /**
     * Пересобирает список активных источников: встроенные источники
     * текущего региона плюс источники, добавленные пользователем вручную.
     */
    fun refreshSources() {
        var builtIn = settings.region.value?.let { RegionSources.sources(for_ = it) } ?: emptyList()
        if (settings.region.value == Region.RUSSIA && settings.whitelistMode.value) {
            builtIn = builtIn.filter { it.isWhitelisted }
        }
        val custom = customSources.asNewsSources
        _sources.value = builtIn + custom
    }

    fun scheduleAutoRefresh() {
        autoRefreshJob?.cancel()
        val minutes = settings.autoRefreshMinutes.value
        if (minutes <= 0) return
        autoRefreshJob = scope.launch {
            while (true) {
                delay(minutes * 60_000L)
                refreshAll()
            }
        }
    }

    /**
     * Параллельно опрашивает все источники, объединяет, классифицирует и
     * суммирует новости. Если базовое обновление уже идёт — новый вызов
     * сразу возвращается, ничего не делая (см. refreshMutex выше).
     */
    suspend fun refreshAll() {
        if (refreshMutex.isLocked) return
        val categorized = refreshMutex.withLock {
            doRefresh()
        } ?: return

        // ВАЖНО: догрузка полного текста запускается ПОСЛЕ withLock, а не
        // внутри него. Раньше она была частью doRefresh() и потому всё ещё
        // держала refreshMutex занятым на всё время своей работы — а значит,
        // пока она не закончится (это могло растянуться надолго), pull-to-
        // refresh и таймер автообновления видели "уже идёт обновление" и
        // молча ничего не делали. Человек тянул ленту вниз раз за разом,
        // а на экране упрямо оставалась старая лента — выглядело так, будто
        // обновление вообще не работает. Теперь refreshMutex освобождается
        // сразу после публикации базовой ленты, а фоновая доработка сводок
        // защищена отдельным, независимым замком (expansionMutex).
        if (!settings.lowDataMode.value) {
            scope.launch { expandShortSummariesInBackground(categorized) }
        }
    }

    /** Возвращает опубликованную ленту, или null если обновлять было нечего. */
    private suspend fun doRefresh(): List<NewsItem>? {
        val activeSources = _sources.value.filter { !settings.isMuted(it) }
        if (activeSources.isEmpty()) return null

        _isLoading.value = true
        _errors.value = emptyList()

        try {
            val lowData = settings.lowDataMode.value
            val perSourceLimit = if (lowData) maxItemsPerSourceLowData else maxItemsPerSource

            val collected = mutableListOf<NewsItem>()
            val newErrors = mutableListOf<String>()

            coroutineScope {
                val jobs = activeSources.map { source ->
                    async {
                        try {
                            val parsed = RssFeedParser(source.name).parse(source.feedUrl)
                            parsed.take(perSourceLimit)
                        } catch (e: Exception) {
                            NamedError(source.name, e.message ?: e.toString())
                        }
                    }
                }
                for (job in jobs) {
                    when (val result = job.await()) {
                        is List<*> -> @Suppress("UNCHECKED_CAST") collected.addAll(result as List<NewsItem>)
                        is NamedError -> newErrors.add(
                            L10n.tf("error.sourceFailed", settings.effectiveLanguage, result.name, result.message)
                        )
                    }
                }
            }
            _errors.value = newErrors

            // Отсеиваем типовой "мусорный" контент (гороскопы, тесты/квизы,
            // регулярная погода) до классификации и суммаризации.
            val filtered = NewsJunkFilter.filter(collected)

            // Жёсткий фильтр "только сегодняшнее": новость остаётся в ленте,
            // только если источник дал дату публикации И она попадает в
            // сегодняшний календарный день по местному времени устройства.
            // Новости без даты (источник её не прислал, либо ни один из
            // распознаваемых форматов не подошёл) теперь ИСКЛЮЧАЮТСЯ
            // полностью, а не просто тонут в конце списка, как было раньше —
            // раньше именно это давало эффект "иногда попадаются январские":
            // без даты новость всё равно показывалась, просто в самом низу,
            // а склейка дублей (см. NewsDeduplicator) могла подмешать к ней
            // дату другого источника той же группы. Явный порог по дате куда
            // надёжнее любых догадок по правдоподобности парсинга.
            val todayOnly = filtered.filter { it.pubDateMillis != null && isToday(it.pubDateMillis) }

            // Классификация по категориям.
            var working = NewsCategorizer.categorizeAll(todayOnly)

            // Баланс по категориям — до суммаризации/догрузки полного текста,
            // чтобы не тратить время на новости, которые всё равно отбросим.
            val categoryCap = if (lowData) maxItemsPerCategoryLowData else maxItemsPerCategory
            working = balanceByCategory(working, categoryCap)

            // Объединяем одну и ту же новость от разных источников в одну карточку.
            working = NewsDeduplicator.merge(working)

            // Суммаризация каждой новости по тизеру из RSS — быстро, без сети.
            working = working.map { it.apply { summary = NewsSummarizer.summarize(this) } }

            // Уже развёрнутые в одном из прошлых обновлений сводки подставляем
            // из кэша сразу — без сетевого запроса.
            working = applyExpandedSummaryCache(working)

            // Сортировка по дате (свежие сверху), без даты — в конец.
            working = working.sortedByDescending { it.pubDateMillis ?: Long.MIN_VALUE }
            val categorized = working

            // Публикуем ленту СРАЗУ — пользователь видит новости уже здесь,
            // не дожидаясь догрузки полного текста статей (это может занимать
            // существенно больше времени и раньше держало спиннер обновления
            // повисшим на этот срок — см. maxExpansionsPerRefresh выше).
            _items.value = categorized
            _lastUpdatedMillis.value = System.currentTimeMillis()
            newsCache.save(categorized)
            seedExpandedSummaryCache(categorized)

            val digest = DailyDigest.build(categorized)
            WidgetSharedDigest.save(context, digest, settings.effectiveLanguage)
            ru.matwey.spotbrief.widget.SpotBriefWidgetUpdater.requestUpdate(context)

            if (settings.morningNotificationsEnabled.value) {
                MorningNotificationScheduler.reschedule(
                    context, digest,
                    settings.morningNotificationHour.value,
                    settings.morningNotificationMinute.value,
                    settings.t("notification.morningTitle"),
                    settings.effectiveLanguage
                )
            }
            return categorized
        } finally {
            _isLoading.value = false
        }
    }

    fun search(query: String): List<NewsItem> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()
        val lowered = trimmed.lowercase()
        return _items.value.filter {
            it.title.lowercase().contains(lowered) || it.rawDescription.lowercase().contains(lowered)
        }
    }

    fun itemsIn(category: NewsCategory): List<NewsItem> = _items.value.filter { it.category == category }

    fun countIn(category: NewsCategory): Int = _items.value.count { it.category == category }

    private fun applyExpandedSummaryCache(items: List<NewsItem>): List<NewsItem> = items.map { item ->
        val cached = expandedSummaryCache[item.stableId]
        if (cached != null && NewsSummarizer.sentenceCount(cached) > NewsSummarizer.sentenceCount(item.summary)) {
            item.copy(summary = cached)
        } else {
            item
        }
    }

    /**
     * Догружает полный текст статьи (а для объединённой новости — сразу
     * НЕСКОЛЬКИХ статей об одном и том же событии, см. NewsDeduplicator) и
     * пересчитывает по нему сводку для новостей, чья текущая сводка короче
     * NewsSummarizer.MIN_SENTENCES — не более maxExpansionsPerRefresh штук за
     * раз (самые свежие в приоритете). Работает уже ПОСЛЕ того, как лента
     * опубликована и спиннер обновления погашен — обновляет `_items`
     * точечно, по мере готовности каждой новости, а не одним большим
     * блокирующим шагом.
     */
    private suspend fun expandShortSummariesInBackground(baseItems: List<NewsItem>) {
        // Если предыдущая догрузка ещё не закончилась — не запускаем вторую
        // поверх неё (это снова была бы конкурентная запись в _items/кэш).
        // Просто выходим: следующий refreshAll() всё равно пересоберёт список
        // кандидатов заново, ничего не потеряется.
        if (expansionMutex.isLocked) return
        expansionMutex.withLock {
            doExpandShortSummaries(baseItems)
        }
    }

    private suspend fun doExpandShortSummaries(baseItems: List<NewsItem>) {
        val candidates = baseItems
            .filter { item ->
                val hasLink = item.link != null || !item.mergedLinks.isNullOrEmpty()
                hasLink &&
                    NewsSummarizer.sentenceCount(item.summary) < NewsSummarizer.MIN_SENTENCES &&
                    !ArticleContentFetcher.isLikelyMultiTopicContent(item.title, item.rawDescription)
            }
            .sortedByDescending { it.pubDateMillis ?: Long.MIN_VALUE }
            .take(maxExpansionsPerRefresh)
        if (candidates.isEmpty()) return

        coroutineScope {
            val jobs = candidates.map { item ->
                async {
                    val allLinks = (listOfNotNull(item.link) + (item.mergedLinks ?: emptyList()))
                        .take(maxLinksPerExpansion)
                    if (allLinks.isEmpty()) return@async null

                    expansionSemaphore.withPermit {
                        // Несколько ссылок одной новости запрашиваем ОДНОВРЕМЕННО,
                        // а не по очереди — иначе у новости с 3 источниками время
                        // ожидания утраивалось бы.
                        val texts = coroutineScope {
                            allLinks.map { link ->
                                async {
                                    try {
                                        ArticleContentFetcher.fetchArticleText(link, item.title)
                                    } catch (e: Exception) {
                                        null
                                    }
                                }
                            }.awaitAll().filterNotNull()
                        }
                        if (texts.isEmpty()) return@withPermit null
                        // maxSentences выше, чем для одиночного источника (8) —
                        // при нескольких независимых описаниях события реального
                        // материала обычно больше.
                        item.stableId to NewsSummarizer.summarize(item.title, texts.joinToString(" "), maxSentences = 10)
                    }
                }
            }

            for (job in jobs) {
                val result = job.await() ?: continue
                val (stableId, expanded) = result

                // Обновляем `_items` точечно — по одной новости за раз, сразу
                // как она готова, а не одним блокирующим шагом в конце.
                val current = _items.value
                val index = current.indexOfFirst { it.stableId == stableId }
                if (index == -1) continue
                if (NewsSummarizer.sentenceCount(expanded) <= NewsSummarizer.sentenceCount(current[index].summary)) continue

                val updatedItem = current[index].copy(summary = expanded)
                _items.value = current.toMutableList().apply { this[index] = updatedItem }

                expandedSummaryCacheMutex.withLock {
                    expandedSummaryCache[stableId] = expanded
                }
            }

            // Один раз в конце — а не на каждую новость — обновляем кэш на
            // диске уже с доработанными сводками.
            newsCache.save(_items.value)
        }
    }

    /**
     * Проверяет, что дата публикации попадает в сегодняшний календарный
     * день — по локальной таймзоне устройства (та же логика, что определяет
     * "сегодня" для человека, а не для UTC-абстракции). Используется как
     * жёсткий фильтр ленты — см. комментарий в doRefresh().
     */
    private fun isToday(pubDateMillis: Long): Boolean {
        val publishedDate = Instant.ofEpochMilli(pubDateMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        return publishedDate == LocalDate.now(ZoneId.systemDefault())
    }

    /**
     * Ограничивает каждую категорию сверху (maxPerCategory), оставляя самые
     * свежие новости — чтобы категория "Общество" не забирала себе
     * непропорционально много места за счёт более редких тем.
     */
    private fun balanceByCategory(items: List<NewsItem>, maxPerCategory: Int): List<NewsItem> {        val byCategory = items.groupBy { it.category }
        val balanced = mutableListOf<NewsItem>()
        for (category in NewsCategory.entries) {
            var group = byCategory[category] ?: continue
            group = group.sortedByDescending { it.pubDateMillis ?: Long.MIN_VALUE }
            if (group.size > maxPerCategory) group = group.take(maxPerCategory)
            balanced.addAll(group)
        }
        return balanced
    }

    // MARK: - Отладочные хелперы (аналог DebugMenuView)

    /** Мгновенно подставляет синтетическую ленту со всеми категориями. */
    fun debugPopulateMockFeed() {
        val mock = buildMockItems()
        _items.value = mock
        _lastUpdatedMillis.value = System.currentTimeMillis()
        _errors.value = emptyList()
        newsCache.save(mock)
        seedExpandedSummaryCache(mock)

        val digest = DailyDigest.build(mock)
        WidgetSharedDigest.save(context, digest, settings.effectiveLanguage)
    }

    /** Очищает ленту и офлайн-кэш — для проверки состояния "нет данных". */
    fun debugClearFeed() {
        _items.value = emptyList()
        _lastUpdatedMillis.value = null
        _errors.value = emptyList()
        newsCache.clear()
    }

    /** Добавляет фиктивную ошибку источника. */
    fun debugInjectSampleError(message: String) {
        _errors.value = _errors.value + message
    }

    private fun buildMockItems(): List<NewsItem> {
        val sourceNames = listOf("Debug Wire", "Тест Медиа", "DummyPress", "Заглушка Daily")
        val now = System.currentTimeMillis()
        val items = mutableListOf<NewsItem>()

        NewsCategory.entries.forEachIndexed { categoryIndex, category ->
            for (n in 0 until 5) {
                val minutesAgo = categoryIndex * 7 + n * 3
                val title = "[DEBUG] ${category.localizedName(settings.effectiveLanguage)} — тестовая новость №${n + 1}"
                val description = "Это синтетическая новость для отладочного меню SpotBrief. " +
                    "Категория: ${category.localizedName(settings.effectiveLanguage)}. Используется для проверки " +
                    "интерфейса без ожидания реальной загрузки RSS-лент."
                items.add(
                    NewsItem(
                        title = title,
                        rawDescription = description,
                        link = null,
                        pubDateMillis = now - minutesAgo * 60_000L,
                        sourceName = sourceNames[(categoryIndex + n) % sourceNames.size],
                        category = category,
                        summary = description
                    )
                )
            }
        }

        return items.sortedByDescending { it.pubDateMillis ?: Long.MIN_VALUE }
    }
}
