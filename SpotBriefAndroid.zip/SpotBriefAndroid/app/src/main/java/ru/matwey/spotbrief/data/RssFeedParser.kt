package ru.matwey.spotbrief.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import ru.matwey.spotbrief.model.NewsItem
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Простой потоковый парсер RSS 2.0 без внешних зависимостей — использует
 * встроенный в Android XmlPullParser (аналог XMLParser/XMLParserDelegate
 * из RSSFeedParser.swift).
 */
class RssFeedParser(private val sourceName: String) {

    sealed class FeedException(message: String) : Exception(message) {
        class HttpStatus(val code: Int) : FeedException("сервер ответил кодом $code")
        class Malformed(cause: Throwable?) : FeedException("не удалось разобрать XML" + (cause?.let { " (${it.message})" } ?: ""))
    }

    private val dateFormats = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "yyyy-MM-dd'T'HH:mm:ssXXX"
    )

    /** Загружает и парсит RSS-ленту по указанному URL. */
    suspend fun parse(feedUrl: String): List<NewsItem> = withContext(Dispatchers.IO) {
        val connection = (URL(feedUrl).openConnection() as HttpURLConnection).apply {
            setRequestProperty("User-Agent", "Mozilla/5.0 (compatible; SpotBriefApp/1.0)")
            connectTimeout = 10_000
            readTimeout = 10_000
        }

        val statusCode = connection.responseCode
        // Раньше HTTP-статус не проверялся: страница ошибки (404/500, часто
        // это HTML, а не RSS) просто "не парсилась" молча.
        if (statusCode !in 200..299) {
            connection.disconnect()
            throw FeedException.HttpStatus(statusCode)
        }

        try {
            connection.inputStream.use { stream ->
                parseStream(stream)
            }
        } catch (e: Exception) {
            throw FeedException.Malformed(e)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseStream(stream: java.io.InputStream): List<NewsItem> {
        val items = mutableListOf<NewsItem>()

        val factory = org.xmlpull.v1.XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = false
        val parser = factory.newPullParser()
        parser.setInput(stream, null)

        var insideItem = false
        var currentElement = ""
        var currentTitle = StringBuilder()
        var currentDescription = StringBuilder()
        var currentContentEncoded = StringBuilder()
        var currentLink = StringBuilder()
        var currentPubDate = StringBuilder()

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    currentElement = parser.name
                    if (currentElement == "item") {
                        insideItem = true
                        currentTitle = StringBuilder()
                        currentDescription = StringBuilder()
                        currentContentEncoded = StringBuilder()
                        currentLink = StringBuilder()
                        currentPubDate = StringBuilder()
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideItem) {
                        when (currentElement) {
                            "title" -> currentTitle.append(parser.text)
                            "description" -> currentDescription.append(parser.text)
                            "encoded", "content:encoded" -> currentContentEncoded.append(parser.text)
                            "link" -> currentLink.append(parser.text)
                            "pubDate" -> currentPubDate.append(parser.text)
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "item") {
                        val title = clean(currentTitle.toString())
                        // Многие ленты дублируют текст анонса и в <description>,
                        // и в <content:encoded> — выбираем более полный вариант.
                        val plainDescription = clean(currentDescription.toString())
                        val encodedDescription = clean(currentContentEncoded.toString())
                        val description = if (encodedDescription.length > plainDescription.length)
                            encodedDescription else plainDescription

                        if (title.isNotEmpty()) {
                            items.add(
                                NewsItem(
                                    title = title,
                                    rawDescription = description,
                                    link = currentLink.toString().trim().ifEmpty { null },
                                    pubDateMillis = parseDate(currentPubDate.toString()),
                                    sourceName = sourceName
                                )
                            )
                        }
                        insideItem = false
                    }
                }
            }
            eventType = parser.next()
        }

        return items
    }

    private fun clean(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("<![CDATA[")) {
            text = text.replace("<![CDATA[", "").replace("]]>", "")
        }
        if (text.contains("<")) {
            text = text.replace(Regex("(?is)<[^>]+>"), " ")
        }
        text = decodeHtmlEntities(text)
        text = text.replace(Regex("\\s+"), " ")
        return text.trim()
    }

    /**
     * Полноценно декодирует HTML-сущности (именованные и числовые/
     * шестнадцатеричные), иначе в тексте остаются "битые" фрагменты вроде
     * "&mdash;", "&hellip;", "&#8217;".
     */
    private fun decodeHtmlEntities(input: String): String {
        var text = input
        val namedEntities = mapOf(
            "&nbsp;" to " ", "&amp;" to "&", "&quot;" to "\"", "&apos;" to "'",
            "&laquo;" to "«", "&raquo;" to "»",
            "&ndash;" to "–", "&mdash;" to "—", "&hellip;" to "…",
            "&lsquo;" to "\u2018", "&rsquo;" to "\u2019", "&ldquo;" to "\u201C", "&rdquo;" to "\u201D",
            "&lt;" to "<", "&gt;" to ">"
        )
        for ((entity, replacement) in namedEntities) {
            text = text.replace(entity, replacement)
        }
        text = Regex("&#(x[0-9A-Fa-f]+|[0-9]+);").replace(text) { match ->
            val code = match.groupValues[1]
            val value = if (code.startsWith("x", ignoreCase = true))
                code.drop(1).toIntOrNull(16) else code.toIntOrNull()
            value?.let { String(Character.toChars(it)) } ?: match.value
        }
        return text
    }

    private fun parseDate(raw: String): Long? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        for (format in dateFormats) {
            try {
                // isLenient = false: без этого SimpleDateFormat по умолчанию
                // пытается "исправить" некорректную дату вместо того, чтобы
                // сообщить об ошибке — и в редких случаях выдаёт совершенно
                // не ту дату (например, читает поле года как день или
                // наоборот), причём молча, без исключения. Явные ошибки
                // парсинга нам куда безопаснее: тогда просто пробуем
                // следующий формат, а если ни один не подошёл — оставляем
                // дату пустой (null), а не показываем пользователю
                // выдуманную дату.
                val sdf = SimpleDateFormat(format, Locale.US).apply { isLenient = false }
                val millis = sdf.parse(trimmed)?.time ?: continue
                if (isPlausible(millis)) return millis
            } catch (_: Exception) {
                // пробуем следующий формат
            }
        }
        return null
    }

    /**
     * Отсекает даты, которые технически распарсились, но явно не могут быть
     * настоящей датой публикации: где-то в прошлом веке (часто это заглушка
     * вроде "01 Jan 1970" у источников с багом в собственной ленте) или
     * заметно в будущем (рассинхронизация времени на сервере источника).
     * Без этой проверки такая новость получала бы правдоподобный на вид, но
     * бессмысленный timestamp и либо тонула в самом низу ленты, либо — что
     * хуже — если баг был в другую сторону, эта дата могла восприниматься
     * как настоящая свежая новость.
     */
    private fun isPlausible(millis: Long): Boolean {
        val now = System.currentTimeMillis()
        val year2000 = 946_684_800_000L
        val oneDayMillis = 24L * 60 * 60 * 1000
        return millis in year2000..(now + oneDayMillis)
    }
}
