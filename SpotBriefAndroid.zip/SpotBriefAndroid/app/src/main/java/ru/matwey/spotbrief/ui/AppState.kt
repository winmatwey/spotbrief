package ru.matwey.spotbrief.ui

import androidx.compose.runtime.compositionLocalOf
import ru.matwey.spotbrief.SpotBriefApplication

/**
 * Аналог `@EnvironmentObject` из SwiftUI: вместо прокидывания service,
 * settings, bookmarks, readStore, customSources через параметры каждого
 * экрана, они читаются из CompositionLocal, установленного один раз в
 * MainActivity вокруг всего дерева экранов.
 */
val LocalAppContainer = compositionLocalOf<SpotBriefApplication> {
    error("LocalAppContainer не установлен — оберните экран в CompositionLocalProvider")
}
