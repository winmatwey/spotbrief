package ru.matwey.spotbrief.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.model.NewsItem
import ru.matwey.spotbrief.ui.screens.BookmarksScreen
import ru.matwey.spotbrief.ui.screens.CategoryDetailScreen
import ru.matwey.spotbrief.ui.screens.FeedScreen
import ru.matwey.spotbrief.ui.screens.LanguagePickerScreen
import ru.matwey.spotbrief.ui.screens.NewsDetailScreen
import ru.matwey.spotbrief.ui.screens.RegionPickerScreen
import ru.matwey.spotbrief.ui.screens.SearchScreen
import ru.matwey.spotbrief.ui.screens.SettingsScreen
import ru.matwey.spotbrief.ui.screens.StatsScreen

private data class Tab(val route: String, val labelKey: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val tabs = listOf(
    Tab("feed", "tab.feed", Icons.Filled.Newspaper),
    Tab("search", "tab.search", Icons.Filled.Search),
    Tab("bookmarks", "tab.bookmarks", Icons.Filled.Bookmark),
    Tab("stats", "tab.stats", Icons.Filled.BarChart),
    Tab("settings", "tab.settings", Icons.Filled.Settings)
)

/**
 * Аналог RootTabView.swift: нижняя навигация из пяти вкладок плюс
 * онбординг поверх всего, пока не выбраны язык и регион.
 *
 * Передача выбранной новости между экранами (лента → детали) сделана через
 * простой in-memory holder (`selectedItem`), а не через сериализацию
 * NewsItem в аргумент маршрута — так же просто, как передача `item: NewsItem`
 * в NavigationLink в SwiftUI-версии.
 */
@Composable
fun RootScreen(requestNotificationPermission: () -> Unit) {
    val app = LocalAppContainer.current
    val language by app.settings.language.collectAsState()
    val region by app.settings.region.collectAsState()
    val needsOnboarding = language == null || region == null

    if (needsOnboarding) {
        OnboardingFlow()
        return
    }

    val navController = rememberNavController()
    var selectedItem by remember { mutableStateOf<NewsItem?>(null) }
    var selectedCategory by remember { mutableStateOf<NewsCategory?>(null) }

    fun openItem(item: NewsItem) {
        selectedItem = item
        navController.navigate("detail")
    }

    fun openCategory(category: NewsCategory) {
        selectedCategory = category
        navController.navigate("category")
    }

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = backStackEntry?.destination
            NavigationBar {
                tabs.forEach { tab ->
                    val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = {
                            Text(
                                app.settings.t(tab.labelKey),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                softWrap = false,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "feed",
            modifier = Modifier.padding(padding)
        ) {
            composable("feed") {
                FeedScreen(onOpenItem = ::openItem, onOpenCategory = ::openCategory)
            }
            composable("search") {
                SearchScreen(onOpenItem = ::openItem)
            }
            composable("bookmarks") {
                BookmarksScreen(onOpenItem = ::openItem)
            }
            composable("stats") {
                StatsScreen()
            }
            composable("settings") {
                SettingsScreen(requestNotificationPermission = requestNotificationPermission)
            }
            composable("category") {
                selectedCategory?.let { category ->
                    CategoryDetailScreen(
                        category = category,
                        onOpenItem = ::openItem,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
            composable("detail") {
                selectedItem?.let { item ->
                    NewsDetailScreen(item = item, onBack = { navController.popBackStack() })
                }
            }
        }
    }
}

/** Первый запуск: язык, затем регион — аналог OnboardingView.swift. */
@Composable
private fun OnboardingFlow() {
    val app = LocalAppContainer.current
    val language by app.settings.language.collectAsState()

    if (language == null) {
        LanguagePickerScreen(onFinished = null)
    } else {
        RegionPickerScreen(onFinished = null)
    }
}
