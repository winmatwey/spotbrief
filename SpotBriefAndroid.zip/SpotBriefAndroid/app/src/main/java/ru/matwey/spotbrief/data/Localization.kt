package ru.matwey.spotbrief.data

import kotlinx.serialization.Serializable

/**
 * Язык интерфейса приложения. Не путать с языком самих новостей — тексты
 * статей приходят из RSS-лент как есть, а этот выбор влияет на кнопки,
 * заголовки, названия категорий и на голос озвучки (TextToSpeech).
 */
@Serializable
enum class AppLanguage(val code: String) {
    RUSSIAN("ru"),
    ENGLISH("en"),
    KAZAKH("kk"),
    GERMAN("de");

    val flag: String
        get() = when (this) {
            RUSSIAN -> "\uD83C\uDDF7\uD83C\uDDFA"
            ENGLISH -> "\uD83C\uDDEC\uD83C\uDDE7"
            KAZAKH -> "\uD83C\uDDF0\uD83C\uDDFF"
            GERMAN -> "\uD83C\uDDE9\uD83C\uDDEA"
        }

    /** Название языка на нём самом. */
    val nativeName: String
        get() = when (this) {
            RUSSIAN -> "Русский"
            ENGLISH -> "English"
            KAZAKH -> "Қазақша"
            GERMAN -> "Deutsch"
        }

    /** Код локали для TextToSpeech — аналог speechLanguageCode (AVSpeechSynthesisVoice). */
    val speechLanguageCode: String
        get() = when (this) {
            RUSSIAN -> "ru-RU"
            ENGLISH -> "en-US"
            KAZAKH -> "kk-KZ"
            GERMAN -> "de-DE"
        }

    companion object {
        fun fromCode(code: String?): AppLanguage? = entries.firstOrNull { it.code == code }
    }
}

/**
 * Простая офлайн-локализация: таблица строк "ключ → перевод на 4 языка".
 * Сделана вручную (не через res/values-*/strings.xml), чтобы язык
 * интерфейса можно было переключать мгновенно, из настроек, без
 * пересоздания Activity и без зависимости от системной локали устройства —
 * то же архитектурное решение, что и в Swift-версии (см. Localization.swift).
 */
object L10n {
    fun t(key: String, language: AppLanguage): String =
        table[key]?.get(language) ?: table[key]?.get(AppLanguage.RUSSIAN) ?: key

    /** Версия с подстановкой значений вместо %s / %d (аналог String(format:)). */
    fun tf(key: String, language: AppLanguage, vararg args: Any): String =
        String.format(t(key, language), *args)

    private fun e(key: String, ru: String, en: String, kk: String, de: String) =
        key to mapOf(
            AppLanguage.RUSSIAN to ru,
            AppLanguage.ENGLISH to en,
            AppLanguage.KAZAKH to kk,
            AppLanguage.GERMAN to de
        )

    private val table: Map<String, Map<AppLanguage, String>> = mapOf(
        // Вкладки
        e("tab.feed", "Лента", "Feed", "Таспа", "Feed"),
        e("tab.search", "Поиск", "Search", "Іздеу", "Suche"),
        e("tab.bookmarks", "Избранное", "Bookmarks", "Таңдаулылар", "Lesezeichen"),
        e("tab.stats", "Статистика", "Stats", "Статистика", "Statistik"),
        e("tab.settings", "Настройки", "Settings", "Баптаулар", "Einstellungen"),

        // Главная лента
        e("content.mainNow", "Главное сейчас", "Top story now", "Қазіргі басты жаңалық", "Aktuell wichtig"),
        e("content.sourcesUnavailable", "Некоторые источники недоступны", "Some sources are unavailable", "Кейбір көздер қолжетімсіз", "Einige Quellen sind nicht verfügbar"),
        e("content.categories", "Категории", "Categories", "Санаттар", "Kategorien"),
        e("content.updatedAt", "Обновлено: %s", "Updated: %s", "Жаңартылды: %s", "Aktualisiert: %s"),
        e("content.digest", "Сводка по всем группам", "Digest across all groups", "Барлық топтар бойынша жинақ", "Überblick über alle Gruppen"),
        e("content.loading", "Собираем новости…", "Gathering news…", "Жаңалықтар жиналуда…", "Nachrichten werden geladen…"),
        e("content.noData.title", "Нет данных", "No data", "Деректер жоқ", "Keine Daten"),
        e("content.noData.description", "Потяните вниз, чтобы загрузить новости из %d источников", "Pull down to load news from %d sources", "%d көзден жаңалық жүктеу үшін төмен тартыңыз", "Nach unten ziehen, um Nachrichten aus %d Quellen zu laden"),
        e("content.readingTime", "%d мин чтения", "%d min read", "%d мин оқу", "%d Min. Lesezeit"),
        e("content.newsCount", "%d новостей", "%d news", "%d жаңалық", "%d Nachrichten"),

        // Категория / детали новости
        e("category.digest", "Краткая сводка", "Summary", "Қысқаша шолу", "Kurzübersicht"),
        e("category.sortPicker", "Сортировка", "Sort by", "Сұрыптау", "Sortierung"),
        e("category.allNews", "Все новости (%d)", "All news (%d)", "Барлық жаңалықтар (%d)", "Alle Nachrichten (%d)"),
        e("swipe.addBookmark", "В избранное", "Add bookmark", "Таңдаулыларға", "Merken"),
        e("swipe.removeBookmark", "Убрать", "Remove", "Алып тастау", "Entfernen"),
        e("newsRow.readingTimeShort", "%d мин", "%d min", "%d мин", "%d Min."),
        e("detail.summary", "Краткое содержание", "Summary", "Қысқаша мазмұны", "Zusammenfassung"),
        e("detail.listen", "Прослушать", "Listen", "Тыңдау", "Anhören"),
        e("detail.stop", "Стоп", "Stop", "Тоқтату", "Stopp"),
        e("detail.fullDescription", "Полное описание из источника", "Full description from source", "Көздегі толық сипаттама", "Vollständige Beschreibung der Quelle"),
        e("detail.bookmarked", "В избранном", "Bookmarked", "Таңдаулыда", "Gemerkt"),
        e("detail.bookmark", "В избранное", "Bookmark", "Таңдаулыларға", "Merken"),
        e("detail.share", "Поделиться", "Share", "Бөлісу", "Teilen"),
        e("detail.openSource", "Открыть источник", "Open source", "Көзді ашу", "Quelle öffnen"),
        e("detail.loadingFull", "Загружаем полный текст статьи…", "Loading the full article…", "Мақаланың толық мәтіні жүктелуде…", "Vollständiger Artikel wird geladen…"),
        e("detail.expandedFromArticle", "Расширено из полного текста статьи", "Expanded from the full article", "Мақаланың толық мәтінінен кеңейтілді", "Aus dem vollständigen Artikel erweitert"),
        e("summary.unavailable", "Краткое содержание недоступно", "Summary unavailable", "Қысқаша мазмұны қолжетімсіз", "Zusammenfassung nicht verfügbar"),

        // Сортировка
        e("sort.newest", "Сначала новые", "Newest first", "Алдымен жаңалары", "Neueste zuerst"),
        e("sort.source", "По источнику", "By source", "Көзі бойынша", "Nach Quelle"),
        e("sort.readingTime", "По времени чтения", "By reading time", "Оқу уақыты бойынша", "Nach Lesezeit"),

        // Категории новостей
        e("category.politics", "Политика", "Politics", "Саясат", "Politik"),
        e("category.sports", "Спорт", "Sports", "Спорт", "Sport"),
        e("category.economy", "Экономика", "Economy", "Экономика", "Wirtschaft"),
        e("category.technology", "Технологии", "Technology", "Технологиялар", "Technologie"),
        e("category.science", "Наука", "Science", "Ғылым", "Wissenschaft"),
        e("category.culture", "Культура", "Culture", "Мәдениет", "Kultur"),
        e("category.incidents", "Происшествия", "Incidents", "Оқиғалар", "Vorfälle"),
        e("category.society", "Общество", "Society", "Қоғам", "Gesellschaft"),

        // Поиск
        e("search.emptyTitle", "Поиск по новостям", "Search the news", "Жаңалықтардан іздеу", "Nachrichten durchsuchen"),
        e("search.emptyDescription", "Введите слово из заголовка или описания", "Type a word from a headline or description", "Тақырып немесе сипаттамадан сөз енгізіңіз", "Geben Sie ein Wort aus Titel oder Beschreibung ein"),
        e("search.prompt", "Например: футбол, санкции, ИИ", "E.g. football, sanctions, AI", "Мысалы: футбол, санкциялар, ЖИ", "Z. B. Fußball, Sanktionen, KI"),
        e("search.noResults", "Ничего не найдено", "No results", "Ештеңе табылмады", "Keine Ergebnisse"),

        // Избранное
        e("bookmarks.emptyTitle", "Пока пусто", "Nothing yet", "Әзірге бос", "Noch leer"),
        e("bookmarks.emptyDescription", "Смахните новость влево или откройте её, чтобы добавить в избранное", "Swipe a news item left or open it to add a bookmark", "Жаңалықты солға сырғытыңыз немесе таңдаулыға қосу үшін ашыңыз", "Nachricht nach links wischen oder öffnen, um sie zu merken"),

        // Статистика
        e("stats.overview", "Обзор", "Overview", "Шолу", "Übersicht"),
        e("stats.totalNews", "Всего новостей", "Total news", "Барлық жаңалықтар", "Nachrichten gesamt"),
        e("stats.read", "Прочитано", "Read", "Оқылды", "Gelesen"),
        e("stats.sourcesCount", "Источников", "Sources", "Көздер", "Quellen"),
        e("stats.byCategory", "По категориям", "By category", "Санаттар бойынша", "Nach Kategorie"),
        e("stats.bySource", "По источникам", "By source", "Көздер бойынша", "Nach Quelle"),

        // Настройки
        e("settings.region", "Регион", "Region", "Аймақ", "Region"),
        e("settings.regionFooter", "Набор доступных новостных агентств зависит от выбранного региона", "The set of available news agencies depends on the selected region", "Қолжетімді жаңалық агенттіктерінің тізімі таңдалған аймаққа байланысты", "Die verfügbaren Nachrichtenagenturen hängen von der gewählten Region ab"),
        e("settings.regionNotSelected", "Не выбран", "Not selected", "Таңдалмаған", "Nicht ausgewählt"),
        e("settings.autoRefresh", "Автообновление", "Auto-refresh", "Автожаңарту", "Automatische Aktualisierung"),
        e("settings.interval", "Интервал", "Interval", "Аралық", "Intervall"),
        e("settings.off", "Выключено", "Off", "Өшірулі", "Aus"),
        e("settings.minutes5", "5 минут", "5 minutes", "5 минут", "5 Minuten"),
        e("settings.minutes15", "15 минут", "15 minutes", "15 минут", "15 Minuten"),
        e("settings.minutes30", "30 минут", "30 minutes", "30 минут", "30 Minuten"),
        e("settings.hour1", "1 час", "1 hour", "1 сағат", "1 Stunde"),
        e("settings.fontSize", "Размер текста", "Text size", "Мәтін өлшемі", "Textgröße"),
        e("settings.scale", "Масштаб", "Scale", "Масштаб", "Skalierung"),
        e("settings.sampleTitle", "Пример заголовка новости", "Sample news headline", "Жаңалық тақырыбының үлгісі", "Beispiel-Schlagzeile"),
        e("settings.sourcesHeader", "Источники (%d)", "Sources (%d)", "Көздер (%d)", "Quellen (%d)"),
        e("settings.sourcesFooter", "Отключённые источники не будут опрашиваться при обновлении ленты. Значок показывает, отвечает ли лента источника прямо сейчас с вашего устройства — так и проверяется доступность в регионе.", "Disabled sources won't be queried when the feed refreshes. The icon shows whether the source responds right now from your device — that's how availability in your region is checked.", "Өшірілген көздер жаңарту кезінде сұралмайды. Белгіше көздің қазір құрылғыдан жауап беретінін көрсетеді — аймақтағы қолжетімділік дәл осылай тексеріледі.", "Deaktivierte Quellen werden beim Aktualisieren nicht abgefragt. Das Symbol zeigt, ob die Quelle gerade von Ihrem Gerät aus antwortet — so wird die Verfügbarkeit in Ihrer Region geprüft."),
        e("settings.lowDataModeHeader", "Режим слабого интернета", "Low-internet mode", "Әлсіз интернет режимі", "Modus für schwaches Internet"),
        e("settings.lowDataMode", "Экономить трафик (легаси-режим)", "Save data (legacy mode)", "Трафикті үнемдеу (легаси режим)", "Datenverbrauch sparen (Legacy-Modus)"),
        e("settings.lowDataModeFooter", "Лента строится только по коротким тизерам из RSS, без догрузки полного текста каждой статьи. Новости грузятся заметно быстрее и тратят меньше интернета, но краткие содержания будут короче.", "The feed is built only from short RSS teasers, without downloading the full text of every article. News loads noticeably faster and uses less data, but summaries will be shorter.", "Лента тек RSS-тегі қысқа тизерлер бойынша құрылады, әр мақаланың толық мәтіні жүктелмейді. Жаңалықтар айтарлықтай жылдам жүктеледі және интернетті аз жұмсайды, бірақ қысқаша мазмұндар қысқарақ болады.", "Der Feed wird nur aus kurzen RSS-Teasern erstellt, ohne den vollständigen Text jedes Artikels herunterzuladen. Nachrichten laden spürbar schneller und verbrauchen weniger Daten, aber die Zusammenfassungen sind kürzer."),
        e("settings.whitelistModeHeader", "Режим белых списков (только Россия)", "Whitelist mode (Russia only)", "Ақ тізімдер режимі (тек Ресей)", "Whitelist-Modus (nur Russland)"),
        e("settings.whitelistMode", "Использовать только подборку из белого списка", "Use only the whitelist selection", "Тек ақ тізімдегі жинақты пайдалану", "Nur die Whitelist-Auswahl verwenden"),
        e("settings.whitelistModeFooter", "Сужает встроенные источники до редакционной подборки крупных, стабильно доступных российских СМИ приложения. Это подборка самого приложения, а не официальный документ какого-либо ведомства. Вручную добавленные вами источники этот режим не затрагивает.", "Narrows the built-in sources down to the app's editorial selection of major, reliably accessible Russian media. This is the app's own curated list, not an official document from any authority. Sources you added manually are not affected by this mode.", "Кірістірілген көздерді қолданбаның ірі, тұрақты қолжетімді ресей БАҚ-тарынан жасалған редакциялық жинағына дейін тарылтады. Бұл — қолданбаның өз жинағы, қандай да бір ведомствоның ресми құжаты емес. Сіз қолмен қосқан көздерге бұл режим әсер етпейді.", "Beschränkt die integrierten Quellen auf die redaktionelle Auswahl großer, zuverlässig erreichbarer russischer Medien der App. Dies ist eine eigene Zusammenstellung der App, kein offizielles Dokument einer Behörde. Von Ihnen manuell hinzugefügte Quellen sind von diesem Modus nicht betroffen."),
        e("settings.morningNotificationsHeader", "Утренние уведомления", "Morning notifications", "Таңғы хабарландырулар", "Morgenbenachrichtigungen"),
        e("settings.morningNotifications", "Присылать сводку дня", "Send the daily digest", "Күндізгі жинақты жіберу", "Täglichen Überblick senden"),
        e("settings.morningNotificationsTime", "Время", "Time", "Уақыт", "Uhrzeit"),
        e("settings.morningNotificationsDenied", "Уведомления запрещены в системных настройках. Разрешите их для SpotBrief в настройках Android → Приложения → SpotBrief → Уведомления.", "Notifications are blocked in system settings. Allow them for SpotBrief in Android Settings → Apps → SpotBrief → Notifications.", "Хабарландыруларға жүйелік баптауларда тыйым салынған. Android баптаулары → Қолданбалар → SpotBrief → Хабарландырулар бөлімінде рұқсат етіңіз.", "Benachrichtigungen sind in den Systemeinstellungen blockiert. Erlauben Sie sie für SpotBrief unter Android-Einstellungen → Apps → SpotBrief → Benachrichtigungen."),
        e("settings.morningNotificationsFooter", "Раз в день, в выбранное время, придёт уведомление с главной новостью из каждой группы. Текст обновляется при каждом обновлении ленты в приложении — без открытия приложения хотя бы изредка сводка может быть неактуальной, так как у приложения нет сервера для рассылки в реальном времени.", "Once a day, at the chosen time, you'll get a notification with the top story from every group. The text is refreshed every time the feed updates inside the app — without opening the app occasionally, the digest may be stale, since the app has no server for real-time delivery.", "Күніне бір рет, таңдалған уақытта, әр топтың басты жаңалығы бар хабарландыру келеді. Мәтін қолданбадағы лента жаңарған сайын жаңарады — қолданбаны кем дегенде кейде ашпасаңыз, жинақ ескіруі мүмкін, себебі қолданбаның нақты уақыттағы жеткізу серверінде жоқ.", "Einmal täglich, zur gewählten Uhrzeit, erhalten Sie eine Benachrichtigung mit der Top-Meldung aus jeder Gruppe. Der Text wird bei jeder Aktualisierung des Feeds in der App erneuert — ohne die App gelegentlich zu öffnen, kann der Überblick veraltet sein, da die App keinen Server für Echtzeit-Zustellung hat."),
        e("notification.morningTitle", "Сводка дня — SpotBrief", "Daily digest — SpotBrief", "Күн жинағы — SpotBrief", "Tagesüberblick — SpotBrief"),
        e("settings.about", "О приложении", "About", "Қолданба туралы", "Über die App"),
        e("settings.appName", "Название", "Name", "Атауы", "Name"),
        e("app.name", "ТочкаСводки", "SpotBrief", "ЖеделДерек", "PunktBericht"),
        e("settings.newsSourcesCount", "Источников новостей", "News sources", "Жаңалық көздері", "Nachrichtenquellen"),
        e("settings.aboutFooter", "Категории и краткие содержания формируются на устройстве без обращения к внешним ИИ-сервисам.", "Categories and summaries are generated on-device without calling external AI services.", "Санаттар мен қысқаша мазмұндар сыртқы ЖИ қызметтеріне жүгінбей, құрылғының өзінде жасалады.", "Kategorien und Zusammenfassungen werden auf dem Gerät erstellt, ohne externe KI-Dienste zu nutzen."),
        e("settings.language", "Язык", "Language", "Тіл", "Sprache"),
        e("settings.languageFooter", "Меняет язык интерфейса приложения", "Changes the app's interface language", "Қолданба интерфейсінің тілін өзгертеді", "Ändert die Sprache der App-Oberfläche"),

        // Выбор региона / языка (онбординг)
        e("region.title", "Выберите ваш регион", "Choose your region", "Аймағыңызды таңдаңыз", "Wählen Sie Ihre Region"),
        e("region.subtitle", "От этого зависит, какие новостные агентства будут предложены в приложении", "This determines which news agencies will be offered in the app", "Бұл қолданбада қандай жаңалық агенттіктері ұсынылатынын анықтайды", "Dies bestimmt, welche Nachrichtenagenturen in der App angeboten werden"),
        e("region.sourcesCount", "%d источников", "%d sources", "%d көз", "%d Quellen"),
        e("common.continue", "Продолжить", "Continue", "Жалғастыру", "Weiter"),

        e("region.russia", "Россия", "Russia", "Ресей", "Russland"),
        e("region.kazakhstan", "Казахстан", "Kazakhstan", "Қазақстан", "Kasachstan"),
        e("region.usa", "США", "USA", "АҚШ", "USA"),
        e("region.uk", "Великобритания", "United Kingdom", "Ұлыбритания", "Vereinigtes Königreich"),
        e("region.germany", "Германия", "Germany", "Германия", "Deutschland"),

        e("language.title", "Выберите язык приложения", "Choose app language", "Қолданба тілін таңдаңыз", "Wählen Sie die App-Sprache"),
        e("language.subtitle", "Можно изменить позже в настройках", "You can change it later in Settings", "Кейін баптауларда өзгертуге болады", "Sie können sie später in den Einstellungen ändern"),

        // Дайджест категории и ошибки источников
        e("digest.empty", "Новостей в категории «%s» пока нет.", "No news in the \u201c%s\u201d category yet.", "«%s» санатында әзірге жаңалық жоқ.", "In der Kategorie \u201e%s\u201c gibt es noch keine Neuigkeiten."),
        e("error.sourceFailed", "%s: не удалось загрузить (%s)", "%s: failed to load (%s)", "%s: жүктелмеді (%s)", "%s: Laden fehlgeschlagen (%s)"),

        // Свои источники
        e("settings.customSources", "Свои источники", "Custom sources", "Жеке дереккөздер", "Eigene Quellen"),
        e("settings.customSourcesFooter", "Добавленные вами RSS-ленты доступны независимо от выбранного региона.", "RSS feeds you add are available regardless of the selected region.", "Сіз қосқан RSS-таспалар таңдалған аймаққа қарамастан қолжетімді.", "Von dir hinzugefügte RSS-Feeds sind unabhängig von der gewählten Region verfügbar."),
        e("settings.addSource", "Добавить источник", "Add source", "Дереккөз қосу", "Quelle hinzufügen"),
        e("settings.noCustomSources", "Пока нет ни одного своего источника", "No custom sources yet", "Әзірге жеке дереккөз жоқ", "Noch keine eigenen Quellen"),
        e("addSource.title", "Новый источник", "New source", "Жаңа дереккөз", "Neue Quelle"),
        e("addSource.nameLabel", "Название", "Name", "Атауы", "Name"),
        e("addSource.namePlaceholder", "Например: Мой любимый блог", "E.g. My favorite blog", "Мысалы: Сүйікті блогым", "Z. B. Mein Lieblingsblog"),
        e("addSource.urlLabel", "Адрес RSS-ленты", "RSS feed address", "RSS-таспа мекенжайы", "RSS-Feed-Adresse"),
        e("addSource.urlPlaceholder", "example.com/rss.xml", "example.com/rss.xml", "example.com/rss.xml", "example.com/rss.xml"),
        e("addSource.add", "Добавить", "Add", "Қосу", "Hinzufügen"),
        e("addSource.cancel", "Отмена", "Cancel", "Бас тарту", "Abbrechen"),
        e("addSource.errorEmptyName", "Введите название источника", "Enter a name for the source", "Дереккөз атауын енгізіңіз", "Gib einen Namen für die Quelle ein"),
        e("addSource.errorInvalidURL", "Похоже, это не корректный адрес", "That doesn't look like a valid address", "Бұл дұрыс мекенжай сияқты көрінбейді", "Das sieht nicht nach einer gültigen Adresse aus"),
        e("addSource.errorDuplicate", "Такой источник уже добавлен", "This source is already added", "Мұндай дереккөз бұрыннан қосылған", "Diese Quelle wurde bereits hinzugefügt"),

        // Отладочное меню (аналог DebugMenuView)
        e("debug.title", "Отладочное меню", "Debug menu", "Іске асыру мәзірі", "Debug-Menü"),
        e("debug.mockFeed", "Подставить тестовую ленту", "Load mock feed", "Сынақ таспасын қою", "Testfeed laden"),
        e("debug.clearFeed", "Очистить ленту и кэш", "Clear feed and cache", "Таспа мен кэшті тазалау", "Feed und Cache leeren"),
        e("debug.injectError", "Добавить тестовую ошибку источника", "Inject sample source error", "Сынақ көз қатесін қосу", "Beispiel-Quellenfehler einfügen"),
        e("debug.testNotification", "Тестовое уведомление", "Test notification", "Сынақ хабарландыруы", "Test-Benachrichtigung"),
        e("debug.clearBookmarksRead", "Сбросить избранное и «прочитано»", "Reset bookmarks and read state", "Таңдаулылар мен «оқылды» белгілерін тазалау", "Lesezeichen und Gelesen-Status zurücksetzen")
    )
}
