package ru.matwey.spotbrief.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Озвучивает краткое содержание новости offline через системный синтез
 * речи — без сторонних API и ключей. Аналог SpeechReader.swift
 * (AVSpeechSynthesizer → android.speech.tts.TextToSpeech). Одна общая
 * копия на всё приложение (см. SpotBriefApplication), чтобы при переходе
 * на другую новость озвучка предыдущей корректно останавливалась.
 */
class SpeechReader(context: Context) {
    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _speakingItemId = MutableStateFlow<String?>(null)
    val speakingItemId: StateFlow<String?> = _speakingItemId.asStateFlow()

    private var tts: TextToSpeech? = null
    private var ready = false
    private val utteranceId = "spotbrief_utterance"

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                _isSpeaking.value = false
                _speakingItemId.value = null
            }
            @Deprecated("Deprecated in API")
            override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
                _speakingItemId.value = null
            }
        })
    }

    /**
     * Озвучивает переданный текст на заданном языке. Повторное нажатие на
     * уже озвучиваемую новость — останавливает чтение.
     */
    fun toggle(id: String, text: String, languageCode: String) {
        if (_isSpeaking.value && _speakingItemId.value == id) {
            stop()
            return
        }

        val engine = tts ?: return
        if (!ready) return

        engine.stop()
        // Ищет голос для нужного языка; если для него (например, казахского)
        // на устройстве нет системного голоса, откатываемся на язык по
        // умолчанию, а не молча ничего не произносим — тот же принцип, что
        // и bestAvailableVoice в Swift-версии.
        val locale = localeFor(languageCode)
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.getDefault())
        }

        _speakingItemId.value = id
        _isSpeaking.value = true
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _speakingItemId.value = null
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }

    private fun localeFor(languageCode: String): Locale {
        val parts = languageCode.split("-")
        return if (parts.size == 2) Locale(parts[0], parts[1]) else Locale(languageCode)
    }
}
