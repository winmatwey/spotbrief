package ru.matwey.spotbrief.model

import java.util.UUID

/**
 * Источник новостей (RSS). Полные списки источников по регионам — в
 * `data/Region.kt` (аналог `NewsSource.sources(for:)` в Region.swift).
 */
data class NewsSource(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val feedUrl: String,
    /**
     * Помечает источник как входящий в подборку "режима белых списков" —
     * редакционная подборка приложения, а не официальный документ
     * какого-либо ведомства (см. Region.kt).
     */
    val isWhitelisted: Boolean = false
)
