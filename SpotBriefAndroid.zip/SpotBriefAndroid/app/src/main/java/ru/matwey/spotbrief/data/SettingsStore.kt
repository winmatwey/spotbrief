package ru.matwey.spotbrief.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import ru.matwey.spotbrief.model.NewsSource

enum class SortOrder {
    NEWEST, SOURCE, READING_TIME;

    fun localizedName(language: AppLanguage): String = when (this) {
        NEWEST -> L10n.t("sort.newest", language)
        SOURCE -> L10n.t("sort.source", language)
        READING_TIME -> L10n.t("sort.readingTime", language)
    }
}

/**
 * Настройки приложения — аналог SettingsStore.swift (там @AppStorage поверх
 * UserDefaults). На Android для синхронного доступа (нужен во многих местах
 * UI, как и `settings.sortOrder` в SwiftUI) используем SharedPreferences
 * напрямую вместо асинхронного DataStore, и публикуем изменения через
 * StateFlow, чтобы Compose-экраны перерисовывались реактивно.
 */
class SettingsStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("spotbrief_settings", Context.MODE_PRIVATE)

    // MARK: - Регион / язык (nil, пока пользователь не выбрал — сигнал онбординга)

    private val _region = MutableStateFlow(Region.fromCode(prefs.getString(KEY_REGION, null)))
    val region: StateFlow<Region?> = _region.asStateFlow()
    fun setRegion(value: Region?) {
        _region.value = value
        prefs.edit().putString(KEY_REGION, value?.code).apply()
    }

    private val _language = MutableStateFlow(AppLanguage.fromCode(prefs.getString(KEY_LANGUAGE, null)))
    val language: StateFlow<AppLanguage?> = _language.asStateFlow()
    fun setLanguage(value: AppLanguage?) {
        _language.value = value
        prefs.edit().putString(KEY_LANGUAGE, value?.code).apply()
    }

    /** Текущий язык интерфейса с безопасным запасным значением до выбора на онбординге. */
    val effectiveLanguage: AppLanguage get() = _language.value ?: AppLanguage.RUSSIAN

    fun t(key: String): String = L10n.t(key, effectiveLanguage)
    fun tf(key: String, vararg args: Any): String = L10n.tf(key, effectiveLanguage, *args)

    // MARK: - Приглушённые источники

    private val _mutedSources = MutableStateFlow(
        (prefs.getString(KEY_MUTED_SOURCES, "") ?: "").split("|").filter { it.isNotEmpty() }.toSet()
    )
    val mutedSources: StateFlow<Set<String>> = _mutedSources.asStateFlow()

    fun isMuted(source: NewsSource): Boolean = source.name in _mutedSources.value

    fun toggleMute(source: NewsSource) {
        val set = _mutedSources.value.toMutableSet()
        if (source.name in set) set.remove(source.name) else set.add(source.name)
        _mutedSources.value = set
        prefs.edit().putString(KEY_MUTED_SOURCES, set.joinToString("|")).apply()
    }

    // MARK: - Прочие настройки

    private val _autoRefreshMinutes = MutableStateFlow(prefs.getInt(KEY_AUTO_REFRESH, 0))
    val autoRefreshMinutes: StateFlow<Int> = _autoRefreshMinutes.asStateFlow()
    fun setAutoRefreshMinutes(value: Int) {
        _autoRefreshMinutes.value = value
        prefs.edit().putInt(KEY_AUTO_REFRESH, value).apply()
    }

    private val _fontScale = MutableStateFlow(prefs.getFloat(KEY_FONT_SCALE, 1.0f))
    val fontScale: StateFlow<Float> = _fontScale.asStateFlow()
    fun setFontScale(value: Float) {
        _fontScale.value = value
        prefs.edit().putFloat(KEY_FONT_SCALE, value).apply()
    }

    private val _sortOrder = MutableStateFlow(
        SortOrder.entries.firstOrNull { it.name == prefs.getString(KEY_SORT_ORDER, null) } ?: SortOrder.NEWEST
    )
    val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()
    fun setSortOrder(value: SortOrder) {
        _sortOrder.value = value
        prefs.edit().putString(KEY_SORT_ORDER, value.name).apply()
    }

    /**
     * Режим слабого интернета: лента грузится только по тизерам из RSS, без
     * догрузки полного текста статьи и с меньшим числом новостей на источник.
     */
    private val _lowDataMode = MutableStateFlow(prefs.getBoolean(KEY_LOW_DATA, false))
    val lowDataMode: StateFlow<Boolean> = _lowDataMode.asStateFlow()
    fun setLowDataMode(value: Boolean) {
        _lowDataMode.value = value
        prefs.edit().putBoolean(KEY_LOW_DATA, value).apply()
    }

    /** Режим белых списков — ТОЛЬКО для региона "Россия". */
    private val _whitelistMode = MutableStateFlow(prefs.getBoolean(KEY_WHITELIST, false))
    val whitelistMode: StateFlow<Boolean> = _whitelistMode.asStateFlow()
    fun setWhitelistMode(value: Boolean) {
        _whitelistMode.value = value
        prefs.edit().putBoolean(KEY_WHITELIST, value).apply()
    }

    private val _morningNotificationsEnabled = MutableStateFlow(prefs.getBoolean(KEY_MORNING_ENABLED, false))
    val morningNotificationsEnabled: StateFlow<Boolean> = _morningNotificationsEnabled.asStateFlow()
    fun setMorningNotificationsEnabled(value: Boolean) {
        _morningNotificationsEnabled.value = value
        prefs.edit().putBoolean(KEY_MORNING_ENABLED, value).apply()
    }

    private val _morningNotificationHour = MutableStateFlow(prefs.getInt(KEY_MORNING_HOUR, 8))
    val morningNotificationHour: StateFlow<Int> = _morningNotificationHour.asStateFlow()

    private val _morningNotificationMinute = MutableStateFlow(prefs.getInt(KEY_MORNING_MINUTE, 0))
    val morningNotificationMinute: StateFlow<Int> = _morningNotificationMinute.asStateFlow()

    fun setMorningNotificationTime(hour: Int, minute: Int) {
        _morningNotificationHour.value = hour
        _morningNotificationMinute.value = minute
        prefs.edit().putInt(KEY_MORNING_HOUR, hour).putInt(KEY_MORNING_MINUTE, minute).apply()
    }

    private companion object {
        const val KEY_REGION = "spotbrief.regionRaw"
        const val KEY_LANGUAGE = "spotbrief.languageRaw"
        const val KEY_MUTED_SOURCES = "spotbrief.mutedSources"
        const val KEY_AUTO_REFRESH = "spotbrief.autoRefreshMinutes"
        const val KEY_FONT_SCALE = "spotbrief.fontScale"
        const val KEY_SORT_ORDER = "spotbrief.sortOrderRaw"
        const val KEY_LOW_DATA = "spotbrief.lowDataMode"
        const val KEY_WHITELIST = "spotbrief.whitelistMode"
        const val KEY_MORNING_ENABLED = "spotbrief.morningNotificationsEnabled"
        const val KEY_MORNING_HOUR = "spotbrief.morningNotificationHour"
        const val KEY_MORNING_MINUTE = "spotbrief.morningNotificationMinute"
    }
}
