package ru.matwey.spotbrief.model

import kotlinx.serialization.Serializable
import java.util.Base64
import java.util.UUID
import kotlin.math.ceil

/**
 * Одна новость. `rawDescription` и `summary` — `var` (а не `val`), потому
 * что `NewsDeduplicator` при объединении одной и той же новости от
 * нескольких источников заменяет `rawDescription` на объединённый текст
 * всех источников (см. NewsDeduplicator.combine), а `NewsAggregatorService`
 * пересчитывает `summary` после догрузки полного текста статьи.
 */
@Serializable
data class NewsItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    var rawDescription: String,
    val link: String?,
    /** Unix-время публикации в миллисекундах, или null если источник его не указал. */
    val pubDateMillis: Long?,
    val sourceName: String,
    var category: NewsCategory = NewsCategory.SOCIETY,
    var summary: String = "",
    /**
     * Названия остальных источников, где нашлась та же новость — заполняется
     * NewsDeduplicator при объединении дублей от разных источников в одну
     * карточку. Пусто/null — новость встретилась только в источнике `sourceName`.
     */
    var mergedSourceNames: List<String>? = null,
    /**
     * Ссылки на статьи остальных объединённых источников — используется
     * NewsAggregatorService.expandShortSummaries, чтобы догрузить полный
     * текст НЕ только своей статьи, а всех версий этой новости.
     */
    var mergedLinks: List<String>? = null
) {
    /**
     * Стабильный идентификатор, не меняющийся между обновлениями ленты —
     * используется для избранного и отметок "прочитано". Основан только на
     * заголовке и sourceName "представителя" объединённой группы (см.
     * NewsDeduplicator).
     */
    val stableId: String
        get() {
            val raw = "$sourceName|$title"
            return Base64.getEncoder().encodeToString(raw.toByteArray(Charsets.UTF_8))
        }

    /**
     * Все источники, в которых нашлась эта новость, включая основной
     * `sourceName` — отсортированы для стабильного отображения в интерфейсе.
     */
    val allSourceNames: List<String>
        get() {
            val merged = mergedSourceNames
            if (merged.isNullOrEmpty()) return listOf(sourceName)
            return (listOf(sourceName) + merged).sorted()
        }

    /** Примерное время чтения полного описания (по 200 слов/мин). */
    val readingTimeMinutes: Int
        get() {
            val words = rawDescription.split(" ").count { it.isNotBlank() }
            return maxOf(1, ceil(words / 200.0).toInt())
        }

    // Аналог кастомного Equatable/Hashable из Models.swift: две новости
    // считаются одинаковыми по заголовку и источнику, не по случайному id —
    // это важно для SwiftUI ForEach id: \.self / Compose key(), где сравнение
    // должно быть по смыслу новости, а не по объекту.
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is NewsItem) return false
        return title == other.title && sourceName == other.sourceName
    }

    override fun hashCode(): Int {
        var result = title.hashCode()
        result = 31 * result + sourceName.hashCode()
        return result
    }
}
