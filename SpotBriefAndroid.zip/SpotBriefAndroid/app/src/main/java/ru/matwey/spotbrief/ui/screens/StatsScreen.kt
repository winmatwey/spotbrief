@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.matwey.spotbrief.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import ru.matwey.spotbrief.model.NewsCategory
import ru.matwey.spotbrief.ui.LocalAppContainer
import ru.matwey.spotbrief.ui.colorFor

@Composable
fun StatsScreen() {
    val app = LocalAppContainer.current
    val settings = app.settings
    val service = app.service
    val readStore = app.readStore

    val items by service.items.collectAsState()
    val sources by service.sources.collectAsState()
    val readIds by readStore.readIds.collectAsState()

    val categoryCounts = remember(items) {
        NewsCategory.entries.map { it to items.count { i -> i.category == it } }.sortedByDescending { it.second }
    }
    val sourceCounts = remember(items) {
        items.flatMap { it.allSourceNames }.groupingBy { it }.eachCount().entries
            .sortedByDescending { it.value }
    }
    val readCount = remember(items, readIds) { items.count { it.stableId in readIds } }
    val maxCategoryCount = categoryCounts.maxOfOrNull { it.second } ?: 1

    Scaffold(
        topBar = { TopAppBar(title = { Text(settings.t("tab.stats")) }) }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding)) {
            item {
                SectionTitle(settings.t("stats.overview"))
                StatRow(settings.t("stats.totalNews"), items.size.toString())
                StatRow(settings.t("stats.read"), readCount.toString())
                StatRow(settings.t("stats.sourcesCount"), sources.size.toString())
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
            }

            item {
                SectionTitle(settings.t("stats.byCategory"))
                Column(Modifier.padding(horizontal = 16.dp)) {
                    categoryCounts.forEach { (category, count) ->
                        BarRow(
                            label = category.localizedName(settings.effectiveLanguage),
                            value = count,
                            maxValue = maxCategoryCount,
                            color = colorFor(category)
                        )
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
            }

            item { SectionTitle(settings.t("stats.bySource")) }
            items(sourceCounts) { (source, count) ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(source, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Text(count.toString(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(16.dp))
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun BarRow(label: String, value: Int, maxValue: Int, color: androidx.compose.ui.graphics.Color) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row {
            Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            Text(value.toString(), style = MaterialTheme.typography.labelMedium)
        }
        val fraction = if (maxValue == 0) 0f else value.toFloat() / maxValue.toFloat()
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction.coerceIn(0f, 1f))
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
            )
        }
    }
}
