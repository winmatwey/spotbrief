package ru.matwey.spotbrief.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

/**
 * Загружает полный текст статьи по ссылке из RSS и извлекает из HTML
 * читаемый текст простым эвристическим разбором — без внешних библиотек
 * и без ИИ. Прямой перенос ArticleContentFetcher.swift, включая все
 * накопленные там исправления (декодирование HTML-сущностей, вырезание
 * блоков кода, отсев гороскопов и колонок читательских писем).
 */
object ArticleContentFetcher {

    class NotEnoughTextException : Exception("not enough text")
    class BadResponseException : Exception("bad response")

    private val multiTopicTitleKeywords = setOf(
        "гороскоп", "horoscope", "horoskop", "zodiac", "sternzeichen",
        "dear abby", "ask amy", "dear prudence", "dear prudie", "miss manners", "dear annie"
    )

    private val zodiacSigns = listOf(
        "овен", "телец", "близнецы", "рак", "лев", "дева",
        "весы", "скорпион", "стрелец", "козерог", "водолей", "рыбы"
    )

    /** Проверка ДО загрузки — по заголовку и тизеру. */
    fun isLikelyMultiTopicContent(title: String, description: String): Boolean {
        val haystack = (title + " " + description).lowercase()
        if (multiTopicTitleKeywords.any { haystack.contains(it) }) return true
        val signHits = zodiacSigns.count { haystack.contains(it) }
        return signHits >= 4
    }

    /**
     * Проверка ПОСЛЕ загрузки — по структуре текста: несколько обращений
     * вида "DEAR ABBY:" подряд означают, что в тексте склеено несколько
     * разных писем.
     */
    private fun looksLikeConcatenatedLetters(text: String): Boolean {
        val regex = Regex("(?i)\\bDEAR [A-ZÀ-Ö][^:.!?]{1,40}:")
        return regex.findAll(text).count() >= 2
    }

    /**
     * Одна попытка "вслепую", повтор — только если сеть УЖЕ ответила не тем
     * содержимым (см. подробное объяснение в оригинальном ArticleContentFetcher.swift).
     */
    suspend fun fetchArticleText(url: String, relatedTo: String): String {
        val title = relatedTo
        val text = try {
            singleAttempt(url)
        } catch (e: Exception) {
            throw NotEnoughTextException()
        }
        if (isRelevant(text, title) && !looksLikeConcatenatedLetters(text)) {
            return text
        }
        val retryText = try {
            singleAttempt(url)
        } catch (e: Exception) {
            null
        }
        if (retryText != null && isRelevant(retryText, title) && !looksLikeConcatenatedLetters(retryText)) {
            return retryText
        }
        throw NotEnoughTextException()
    }

    private suspend fun singleAttempt(urlString: String): String = withContext(Dispatchers.IO) {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            setRequestProperty("User-Agent", "Mozilla/5.0 (compatible; SpotBriefApp/1.0)")
            // Раньше было 12с — при двух попытках это давало до 24с ожидания.
            // 7с с запасом хватает на нормальный ответ, но куда быстрее
            // "сдаётся" на источниках, которые реально недоступны.
            connectTimeout = 7_000
            readTimeout = 7_000
        }

        val statusCode = connection.responseCode
        if (statusCode !in 200..299) {
            connection.disconnect()
            throw BadResponseException()
        }

        val charset = detectCharset(connection.contentType) ?: Charsets.UTF_8
        val html = connection.inputStream.use { stream ->
            BufferedReader(InputStreamReader(stream, charset)).readText()
        }
        connection.disconnect()

        val text = extractReadableText(html)
        if (text.length <= 200) throw NotEnoughTextException()
        return@withContext text
    }

    private fun detectCharset(contentType: String?): Charset? {
        val match = contentType?.let { Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(it) }
        return match?.groupValues?.get(1)?.let {
            try { Charset.forName(it) } catch (e: Exception) { null }
        }
    }

    /**
     * Проверяет, что извлечённый текст действительно похож на статью С ЭТИМ
     * заголовком, а не на баннер согласия/заглушку/страницу с другим материалом.
     */
    private fun isRelevant(text: String, title: String): Boolean {
        val titleWords = significantWords(title)
        if (titleWords.isEmpty()) return true
        val lowered = text.lowercase()
        val matches = titleWords.count { lowered.contains(it) }
        return matches >= maxOf(1, titleWords.size / 3)
    }

    private fun significantWords(text: String): List<String> =
        text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 3 }

    /** Очень простой аналог "режима чтения". */
    private fun extractReadableText(html: String): String {
        var cleaned = html
        cleaned = cleaned.replace(Regex("(?is)<script.*?</script>"), " ")
        cleaned = cleaned.replace(Regex("(?is)<style.*?</style>"), " ")
        cleaned = cleaned.replace(Regex("(?is)<!--.*?-->"), " ")

        // Код (<pre>/<code>) — не текст статьи, а листинги/конфиги/регулярки.
        cleaned = cleaned.replace(Regex("(?is)<pre[^>]*>.*?</pre>"), " ")
        cleaned = cleaned.replace(Regex("(?is)<code[^>]*>.*?</code>"), " ")

        // Вырезаем целиком навигацию, сайдбары, подвал.
        for (tag in listOf("nav", "header", "footer", "aside")) {
            cleaned = cleaned.replace(Regex("(?is)<$tag[^>]*>.*?</$tag>"), " ")
        }

        // Если на странице есть <article>, тело статьи почти всегда именно там.
        firstTagRange(cleaned, "article")?.let { cleaned = it }

        val paragraphs = extractParagraphs(cleaned)
        return dedupParagraphs(paragraphs).joinToString(" ")
    }

    private fun firstTagRange(html: String, tag: String): String? {
        val openMatch = Regex("(?is)<$tag[^>]*>").find(html) ?: return null
        val closeMatch = Regex("(?is)</$tag>").findAll(html).lastOrNull() ?: return null
        val start = openMatch.range.last + 1
        val end = closeMatch.range.first
        if (start >= end) return null
        return html.substring(start, end)
    }

    private fun extractParagraphs(html: String): List<String> {
        val paragraphs = mutableListOf<String>()
        val regex = Regex("(?is)<p[^>]*>(.*?)</p>")
        for (match in regex.findAll(html)) {
            val text = stripTags(match.groupValues[1])
            if (isLikelyArticleText(text)) paragraphs.add(text)
        }
        return paragraphs
    }

    /**
     * Отсеивает то, что похоже не на текст статьи, а на элемент виджета со
     * списком других новостей.
     */
    private fun isLikelyArticleText(text: String): Boolean {
        if (text.length <= 60) return false
        if (Regex("\\d{1,2}:\\d{2}\\s*$").containsMatchIn(text)) return false

        val navLabels = setOf(
            "политика", "общество", "экономика", "спорт", "технологии", "наука",
            "культура", "происшествия", "подписка на рбк", "загрузить еще",
            "загрузить ещё", "читайте также", "все новости", "входит в сюжеты"
        )
        val normalized = text.lowercase().trim()
        if (normalized in navLabels) return false

        if (looksLikeCode(text)) return false

        return true
    }

    /**
     * Подстраховка на случай, если код на странице не обёрнут в `<pre>`/`<code>`.
     * Считает долю символов, типичных для кода/конфигов, среди непробельных.
     */
    private fun looksLikeCode(text: String): Boolean {
        val codeCharacters = setOf('{', '}', '[', ']', '<', '>', ';', '=', '|', '\\', '_', '`')
        val nonWhitespace = text.filterNot { it.isWhitespace() }
        if (nonWhitespace.length <= 20) return false
        val codeCount = nonWhitespace.count { it in codeCharacters }
        return codeCount.toDouble() / nonWhitespace.length.toDouble() > 0.04
    }

    private fun dedupParagraphs(paragraphs: List<String>): List<String> {
        val seen = mutableSetOf<String>()
        val result = mutableListOf<String>()
        for (paragraph in paragraphs) {
            val key = paragraph.lowercase()
            if (key in seen) continue
            seen.add(key)
            result.add(paragraph)
        }
        return result
    }

    private fun stripTags(raw: String): String {
        var text = raw.replace(Regex("(?is)<[^>]+>"), " ")
        text = decodeHtmlEntities(text)
        text = text.replace(Regex("\\s+"), " ")
        return text.trim()
    }

    /** Полноценно декодирует HTML-сущности (именованные и числовые/шестнадцатеричные). */
    private fun decodeHtmlEntities(input: String): String {
        var text = input
        val namedEntities = mapOf(
            "&nbsp;" to " ", "&amp;" to "&", "&quot;" to "\"", "&apos;" to "'",
            "&laquo;" to "«", "&raquo;" to "»",
            "&ndash;" to "–", "&mdash;" to "—", "&hellip;" to "…",
            "&lsquo;" to "\u2018", "&rsquo;" to "\u2019", "&ldquo;" to "\u201C", "&rdquo;" to "\u201D",
            "&lt;" to "<", "&gt;" to ">"
        )
        for ((entity, replacement) in namedEntities) {
            text = text.replace(entity, replacement)
        }
        text = Regex("&#(x[0-9A-Fa-f]+|[0-9]+);").replace(text) { match ->
            val code = match.groupValues[1]
            val value = if (code.startsWith("x", ignoreCase = true))
                code.drop(1).toIntOrNull(16) else code.toIntOrNull()
            value?.let { String(Character.toChars(it)) } ?: match.value
        }
        return text
    }
}
