# SpotBrief — порт на Kotlin/Android

Полный перенос логики и интерфейса SpotBrief (SwiftUI, iOS/Swift Playgrounds)
на Kotlin + Jetpack Compose. Пакет: `ru.matwey.spotbrief`.

## Что сделано (1:1 или идиоматичный аналог)

**Логика (`data/`, `model/`)** — прямой построчный перенос со всеми
комментариями и накопленными фиксами из iOS-версии:
- `RssFeedParser` — разбор RSS через `XmlPullParser` (аналог `XMLParser`)
- `NewsCategorizer`, `NewsJunkFilter`, `NewsDeduplicator`, `NewsSummarizer`
  (разбивка предложений — `java.text.BreakIterator` вместо `NLTokenizer`)
- `ArticleContentFetcher` — включая отсев гороскопов/колонок писем и вырезание
  блоков кода, обе истории багов из чата перенесены как фиксы
- `NewsAggregatorService` — параллельная загрузка, объединение дублей,
  догрузка полного текста с лимитом одновременных запросов
- `SettingsStore`, `CustomSourcesStore`, `Persistence` (Bookmarks/Read/Cache),
  `Region`, `Localization` (тот же принцип — своя таблица переводов, не
  `strings.xml`, чтобы язык переключался мгновенно из настроек)

**Экраны (`ui/`)** — Jetpack Compose, Material 3, Navigation-Compose:
лента, категория, детали новости (с озвучкой и догрузкой полного текста),
поиск, избранное, статистика, настройки, онбординг (язык → регион),
добавление источника, отладочное меню.

**Платформенные части:**
- **Виджет** (`widget/`) — на Glance, и он **реально работает**, в отличие
  от iOS-версии: там был только код-заготовка (`WidgetSharedDigest.swift` +
  `WidgetExtension-Reference/`), потому что формат `.swiftpm` не позволял
  завести второй таргет. На Android виджет живёт в том же процессе — App
  Group не нужна, всё уже подключено.
- **Уведомления** (`notifications/`) — `AlarmManager` + `BroadcastReceiver`
  вместо `UNUserNotificationCenter`.
- **Озвучка** (`speech/`) — системный `TextToSpeech` вместо `AVSpeechSynthesizer`.

## Чего нет / что упрощено

- **Иконка приложения** — простая заглушка (векторная), не дизайн.
- **Отладочное меню** урезано до самих действий (мок-лента, очистка кэша,
  тестовая ошибка, тестовое уведомление, сброс избранного/прочитанного) —
  без расширенной статистики, которая была в 500-строчном `DebugMenuView.swift`.
- **`IPAFile.swift`/`ExportIPA.swift`** не переносились — это был трюк для
  экспорта `.ipa` прямо из Swift Playgrounds на iPad. На Android ничего
  подобного не нужно: `./gradlew assembleDebug` (или Run в Android Studio)
  сразу даёт устанавливаемый APK.
- Верстка не копирует SwiftUI 1:1 (другой design language) — воссоздана по
  смыслу и содержимому, не попиксельно.

## Как собрать

**Через Android Studio (проще всего):** File → Open → выбрать папку
`SpotBriefAndroid`. Studio сама предложит сгенерировать `gradle-wrapper.jar`,
которого не хватает в архиве (бинарник, я не мог его скачать в своей
песочнице без доступа в сеть) — согласитесь, и дальше просто Run.

**Через терминал**, если Gradle уже стоит у вас:
```
cd SpotBriefAndroid
gradle wrapper --gradle-version 8.9   # один раз, сгенерирует gradlew
./gradlew assembleDebug
```
APK появится в `app/build/outputs/apk/debug/`.

minSdk 26 (Android 8.0+), Kotlin 2.0, Compose BOM 2024.10.00.

## Важно: это не проверено компилятором

У меня в песочнице нет Android SDK/Gradle, поэтому собрать проект и
прогнать через компилятор я не мог — то же ограничение, что и с Xcode для
iOS-версии в этом чате. Код я написал и вычитал внимательно (сбалансировал
скобки, сверил все ключи локализации 1:1 с использованием), но реальные
ошибки компиляции (особенно на стыке версий Compose/Material3 API,
которые меняются от релиза к релизу) исключить не могу. Если при сборке
в Android Studio что-то не сойдётся — пришлите текст ошибки, разберём.
