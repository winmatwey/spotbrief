// ЭТОТ ФАЙЛ НЕ УЧАСТВУЕТ В СБОРКЕ ПРИЛОЖЕНИЯ.
//
// Он лежит вне Sources/SpotBrief специально: Swift Playgrounds App
// Playground (см. Package.swift — единственный продукт .iOSApplication)
// не поддерживает второй таргет в проекте, а виджет на экране блокировки —
// это отдельный таргет-расширение (WidgetKit Extension). Добавить его
// можно только открыв проект в Xcode и создав новый таргет через
// File → New → Target… → Widget Extension.
//
// Как подключить:
// 1. Откройте "SpotBrief 20.swiftpm" в Xcode (не в Swift Playgrounds).
// 2. File → New → Target… → Widget Extension, назовите, например,
//    "SpotBriefWidget". Снимите галку "Include Live Activity", если не
//    нужна — для сводки на экране блокировки достаточно обычного виджета.
// 3. В Signing & Capabilities ОБОИХ таргетов (основного приложения и
//    нового расширения) добавьте одну и ту же App Group, например
//    "group.ru.matwey.spotbrief" — тот же идентификатор, что указан в
//    WidgetSharedDigest.appGroupIdentifier (Sources/SpotBrief/WidgetSharedDigest.swift).
// 4. Скопируйте содержимое этого файла в новый таргет расширения вместо
//    сгенерированного Xcode шаблона.
// 5. Также добавьте в таргет расширения файл WidgetSharedDigest.swift
//    (тот же код чтения — см. основной таргет) либо просто продублируйте
//    структуры WidgetDigestEntry/WidgetDigestPayload и функцию load().
//
// Семейства виджетов ниже (.accessoryRectangular, .accessoryInline) —
// именно те, что показываются на экране блокировки iOS. .accessoryCircular
// добавлен как третий вариант на выбор пользователя в галерее виджетов.

import WidgetKit
import SwiftUI

struct SpotBriefWidgetEntry: TimelineEntry {
    let date: Date
    let payload: WidgetDigestPayload?
}

struct SpotBriefWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> SpotBriefWidgetEntry {
        SpotBriefWidgetEntry(date: Date(), payload: nil)
    }

    func getSnapshot(in context: Context, completion: @escaping (SpotBriefWidgetEntry) -> Void) {
        completion(SpotBriefWidgetEntry(date: Date(), payload: WidgetSharedDigest.load()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<SpotBriefWidgetEntry>) -> Void) {
        let entry = SpotBriefWidgetEntry(date: Date(), payload: WidgetSharedDigest.load())
        // Виджет сам по себе не умеет ходить в сеть за свежими новостями —
        // он просто перечитывает то, что последним записало основное
        // приложение (см. WidgetSharedDigest.save, вызывается из
        // NewsAggregatorService.refreshAll()). Точка обновления через час —
        // не за новыми данными, а чтобы виджет перечитал App Group на
        // случай, если приложение открывали в фоне.
        let nextUpdate = Calendar.current.date(byAdding: .hour, value: 1, to: Date()) ?? Date().addingTimeInterval(3600)
        completion(Timeline(entries: [entry], policy: .after(nextUpdate)))
    }
}

struct SpotBriefWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: SpotBriefWidgetEntry

    var body: some View {
        switch family {
        case .accessoryInline:
            if let first = entry.payload?.entries.first {
                Text("\(first.category): \(first.title)")
            } else {
                Text("SpotBrief")
            }
        case .accessoryCircular:
            VStack(spacing: 2) {
                Image(systemName: "newspaper.fill")
                if let count = entry.payload?.entries.count {
                    Text("\(count)")
                        .font(.caption2.weight(.bold))
                }
            }
        default: // .accessoryRectangular
            VStack(alignment: .leading, spacing: 2) {
                if let entries = entry.payload?.entries, !entries.isEmpty {
                    ForEach(Array(entries.prefix(2).enumerated()), id: \.offset) { _, item in
                        Text(item.title)
                            .font(.caption2.weight(.semibold))
                            .lineLimit(1)
                    }
                } else {
                    Text("SpotBrief")
                        .font(.caption2.weight(.semibold))
                }
            }
        }
    }
}

struct SpotBriefWidget: Widget {
    let kind = "SpotBriefWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: SpotBriefWidgetProvider()) { entry in
            SpotBriefWidgetView(entry: entry)
        }
        .configurationDisplayName("SpotBrief")
        .description("Главные новости из каждой группы.")
        .supportedFamilies([.accessoryRectangular, .accessoryInline, .accessoryCircular])
    }
}

@main
struct SpotBriefWidgetBundle: WidgetBundle {
    var body: some Widget {
        SpotBriefWidget()
    }
}
