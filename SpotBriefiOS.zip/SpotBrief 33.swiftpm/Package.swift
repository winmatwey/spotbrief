// swift-tools-version: 5.9

import PackageDescription
import AppleProductTypes

let package = Package(
    name: "SpotBrief",
    platforms: [
        .iOS("17.0")
    ],
    products: [
        .iOSApplication(
            name: "SpotBrief",
            targets: ["SpotBrief"],
            bundleIdentifier: "ru.matwey.spotbrief",
            teamIdentifier: "",
            displayVersion: "1.0",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .openBook),
            accentColor: .presetColor(.orange),
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ],
            // Добавляет UIBackgroundModes и BGTaskSchedulerPermittedIdentifiers
            // из Info-Additions.plist — без них фоновое обновление ленты
            // (см. BackgroundRefreshScheduler.swift) не заработает: iOS
            // молча откажется регистрировать и запускать задачу без этих
            // двух ключей в Info.plist собранного приложения.
            additionalInfoPlistContentFilePath: "Info-Additions.plist"
        )
    ],
    targets: [
        .executableTarget(
            name: "SpotBrief"
        )
    ]
)
