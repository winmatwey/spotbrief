import Foundation
import SwiftUI

@MainActor
final class NewsAggregatorService: ObservableObject {

    // Слабая ссылка на уже созданный сервис приложения (создаётся один раз
    // в SpotBriefApp и живёт всё время работы приложения). Нужна фоновой
    // задаче обновления (см. BackgroundRefreshScheduler): если процесс
    // приложения ещё жив (не выгружен системой), фоновая задача переиспользует
    // именно этот экземпляр — тогда обновлённая лента сразу видна в уже
    // открытых экранах, без задержки на перечитывание диска. Если процесса
    // нет (система запускает его "с нуля" специально под фоновую задачу),
    // ссылка будет nil, и BackgroundRefreshScheduler создаст отдельный
    // экземпляр только для сохранения результата в кэш — см. его комментарии.
    static weak var current: NewsAggregatorService?

    @Published private(set) var items: [NewsItem] = []
    @Published private(set) var isLoading = false
    @Published private(set) var lastUpdated: Date?
    @Published private(set) var errors: [String] = []
    @Published private(set) var sources: [NewsSource] = []

    /// Новости за последние дни, которые НЕ попали в сегодняшнюю ленту (см.
    /// комментарий у freshnessLimit в refreshAll) — доступны отдельно,
    /// через архив, а не смешиваются с сегодняшними новостями в `items`.
    @Published private(set) var archivedItems: [NewsItem] = []

    private var autoRefreshTask: Task<Void, Never>?
    private weak var settings: SettingsStore?
    private weak var customSources: CustomSourcesStore?

    // Ограничение на число одновременных запросов полного текста статьи —
    // как и в SourceAvailabilityChecker, чтобы не заваливать источники
    // (и не упереться в системный лимит одновременных соединений) при
    // расширении сразу многих коротких сводок после обновления ленты.
    // Раньше было 6 — это и было основной причиной долгой загрузки: почти
    // каждая новость требует догрузки полного текста (см. expandShortSummaries),
    // и при сотнях новостей за обновление 6 одновременных запросов означали
    // десятки последовательных "волн" запросов. 6 было осторожным числом на
    // случай медленных источников, но на практике большинство ответов
    // укладывается в секунды, а системный лимит соединений на хост/сессию
    // это всё равно ограничивает — поднимаем до значения, которое ощутимо
    // сокращает число волн, но не начинает "заваливать" источники.
    private let maxConcurrentExpansions = 16

    // Верхняя граница числа новостей, которые берутся из одной ленты за
    // одно обновление, — защита от патологически большого фида, а не
    // реальный инструмент отбора: раньше обрезка на 30 применялась ДО
    // классификации по темам, и источник просто отдавал первые 30 новостей
    // вслепую, не зная, какая из них про политику, а какая — про науку.
    // Из-за этого у редких категорий не оставалось шанса набрать даже
    // минимум (см. targetItemsPerCategory) — весь бюджет уходил в темы,
    // которые и так преобладают в топе ленты. Реальный отбор и баланс между
    // категориями теперь делает balanceByCategory(_:maxPerCategory:) уже
    // после классификации — см. вызов в refreshAll().
    private let maxItemsPerSource = 80
    private let maxItemsPerSourceLowData = 25

    // Целевой минимум новостей на категорию в ленте — по просьбе
    // пользователя: "на группу (например политика или экономика) должно
    // быть не менее 50 новостей, если больше — нормально, но должен быть
    // баланс". Это ориентир, а не гарантия: если по какой-то теме источники
    // реально прислали меньше 50 новостей, придумывать недостающие нельзя —
    // категория останется такой, какая есть. maxItemsPerCategory — верхняя
    // граница: без неё категория по умолчанию ("Общество", куда попадает
    // всё, что не подошло под более узкую тему по ключевым словам)
    // разрослась бы за счёт остальных и забрала бы себе весь бюджет времени
    // на суммаризацию и особенно догрузку полного текста статьи
    // (expandShortSummaries — самая дорогая по времени часть обновления).
    // Раньше граница была 2x от цели (100) — при 8-9 категориях это до ~800
    // новостей на догрузку текста за одно обновление, что и было основной
    // причиной "очень долгой" загрузки. Сузили до близкого к цели запаса:
    // "если больше — нормально" по-прежнему верно, просто не в 2 раза
    // больше, а с запасом, ощутимо не удваивающим время загрузки.
    private let targetItemsPerCategory = 50
    private let maxItemsPerCategory = 65
    private let maxItemsPerCategoryLowData = 30

    /// Потолок архивных новостей на категорию — архив читают реже основной
    /// ленты, поэтому держим его заметно компактнее, а не 1:1 с основным
    /// maxItemsPerCategory.
    private let maxArchiveItemsPerCategory = 25

    // Кэш уже "развёрнутых" (догруженных полным текстом) кратких содержаний
    // между обновлениями — по stableID новости. Одна и та же новость обычно
    // остаётся в ленте несколько обновлений подряд (пока источник её не
    // вытеснит более свежими), и без этого кэша для неё каждый раз заново
    // скачивался бы и разбирался полный текст статьи, хотя результат уже
    // известен. Заполняется из офлайн-кэша при старте и пополняется после
    // каждого refreshAll().
    private var expandedSummaryCache: [String: String] = [:]

    init() {
        if let cached = NewsCache.load() {
            self.items = cached.items
            self.lastUpdated = cached.date
            seedExpandedSummaryCache(from: cached.items)
        }
        if let archived = ArchiveCache.load() {
            self.archivedItems = archived
        }
    }

    private func seedExpandedSummaryCache(from items: [NewsItem]) {
        for item in items where NewsSummarizer.sentenceCount(in: item.summary) >= NewsSummarizer.minSentences {
            expandedSummaryCache[item.stableID] = item.summary
        }
    }

    /// Подключает настройки и хранилище пользовательских источников, чтобы
    /// учитывать отключённые источники, автообновление, выбранный регион
    /// и вручную добавленные ленты. Если регион уже выбран (не первый
    /// запуск), сразу подставляет его источники.
    func attach(settings: SettingsStore, customSources: CustomSourcesStore) {
        self.settings = settings
        self.customSources = customSources
        NewsAggregatorService.current = self
        refreshSources()
        scheduleAutoRefresh()
    }

    /// Меняет активный регион и его набор источников. Вызывается при первом
    /// выборе региона на онбординге и при смене региона в настройках.
    func updateRegion(_ region: Region) {
        settings?.region = region
        refreshSources()
        // Очищаем текущую ленту сразу, а не только после завершения refreshAll():
        // иначе пока грузятся источники нового региона, на экране ещё
        // какое-то время висят новости из старого региона.
        items = []
        lastUpdated = nil
        errors = []
        Task { await refreshAll() }
    }

    /// Пересобирает список активных источников: встроенные источники текущего
    /// региона плюс источники, добавленные пользователем вручную (они не
    /// привязаны к региону и доступны всегда). Вызывается при подключении
    /// настроек, при смене региона и после добавления/удаления
    /// пользовательского источника в настройках.
    func refreshSources() {
        var builtIn = settings?.region.map(NewsSource.sources(for:)) ?? []
        // Режим белых списков — только для региона "Россия" (см. комментарий
        // у SettingsStore.whitelistMode). Для любого другого региона флаг
        // просто не действует, даже если почему-то остался включён с
        // прошлого раза, когда был выбран другой регион.
        if settings?.region == .russia, settings?.whitelistMode == true {
            builtIn = builtIn.filter(\.isWhitelisted)
        }
        let custom = customSources?.asNewsSources ?? []
        sources = builtIn + custom
    }

    func scheduleAutoRefresh() {
        autoRefreshTask?.cancel()
        guard let minutes = settings?.autoRefreshMinutes, minutes > 0 else { return }
        autoRefreshTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: UInt64(minutes) * 60_000_000_000)
                guard !Task.isCancelled else { return }
                await self?.refreshAll()
            }
        }
    }

    /// Параллельно опрашивает все источники, объединяет, классифицирует и суммирует новости.
    func refreshAll() async {
        // До выбора региона sources пуст — раньше это всё равно проставляло
        // lastUpdated = Date(), и в шапке ленты на миг мелькало "Обновлено: …",
        // хотя по факту ничего не грузилось.
        guard !sources.isEmpty else { return }

        isLoading = true
        errors = []
        defer { isLoading = false }

        let activeSources = sources.filter { settings?.isMuted($0) != true }
        let lowData = settings?.lowDataMode ?? false
        let perSourceLimit = lowData ? maxItemsPerSourceLowData : maxItemsPerSource
        var collected: [NewsItem] = []

        await withTaskGroup(of: Swift.Result<[NewsItem], NamedError>.self) { group in
            for source in activeSources {
                group.addTask {
                    let parser = RSSFeedParser(sourceName: source.name)
                    do {
                        let items = try await parser.parse(url: source.feedURL)
                        return .success(Array(items.prefix(perSourceLimit)))
                    } catch {
                        return .failure(NamedError(name: source.name, underlying: error))
                    }
                }
            }

            for await result in group {
                switch result {
                case .success(let parsedItems):
                    collected.append(contentsOf: parsedItems)
                case .failure(let err):
                    let language = settings?.effectiveLanguage ?? .russian
                    errors.append(L10n.tf("error.sourceFailed", language, err.name, err.underlying.localizedDescription))
                }
            }
        }

        // Разделяем на "сегодня" (основная лента) и "архив" (последние 7 дней,
        // но не сегодня) — по требованию: в основной ленте должны быть ТОЛЬКО
        // сегодняшние новости, а не просто "свежие последние несколько дней".
        // Новости без даты (pubDate == nil, например источник с нестандартным
        // форматом даты, который не распознал RSSFeedParser) не наказываем —
        // не можем определить их возраст, поэтому оставляем в основной ленте,
        // а не молча теряем и не закидываем в архив без оснований.
        let archiveLimit: TimeInterval = 7 * 24 * 60 * 60
        let archiveCutoff = Date().addingTimeInterval(-archiveLimit)
        var todayRaw: [NewsItem] = []
        var archiveRaw: [NewsItem] = []
        for item in collected {
            if let date = item.pubDate {
                if Calendar.current.isDateInToday(date) {
                    todayRaw.append(item)
                } else if date >= archiveCutoff {
                    archiveRaw.append(item)
                }
                // Старше archiveCutoff — не архивируем совсем, просто отбрасываем:
                // архив не должен расти бесконечно, а материал недельной
                // давности уже едва ли кому-то нужен даже в архиве.
            } else {
                todayRaw.append(item)
            }
        }

        // Отсеиваем типовой "мусорный" контент, который RSS-ленты подмешивают
        // к настоящим новостям (гороскопы, тесты/квизы, регулярная погода) —
        // см. NewsJunkFilter. Делаем это ДО классификации и суммаризации,
        // чтобы не тратить на такой контент вычисления впустую.
        let filteredToday = NewsJunkFilter.filter(todayRaw)

        // Классификация по категориям
        var categorized = NewsCategorizer.categorizeAll(filteredToday)

        // Баланс по категориям — см. комментарий у targetItemsPerCategory /
        // maxItemsPerCategory выше. Делаем это ДО суммаризации и догрузки
        // полного текста (expandShortSummaries), чтобы не тратить время на
        // новости, которые всё равно будут отброшены при обрезке избыточной
        // категории.
        let categoryCap = lowData ? maxItemsPerCategoryLowData : maxItemsPerCategory
        categorized = balanceByCategory(categorized, maxPerCategory: categoryCap)

        // Объединяем одну и ту же новость от разных источников в одну
        // карточку — см. NewsDeduplicator. Делаем это ПОСЛЕ обрезки по
        // категориям (иначе пришлось бы сравнивать друг с другом все
        // новости категории ДО обрезки, а их может быть на порядок больше)
        // и ДО суммаризации: объединённая новость получает описание сразу
        // от всех источников-дублей, и суммаризатору есть из чего набрать
        // приличную сводку, а не только из тизера одного источника.
        categorized = NewsDeduplicator.merge(categorized)

        // Суммаризация каждой новости
        for index in categorized.indices {
            categorized[index].summary = NewsSummarizer.summarize(categorized[index])
        }

        // Тизера из RSS <description> почти никогда не хватает на
        // NewsSummarizer.minSentences предложений — догружаем полный текст
        // статьи и пересчитываем сводку по нему для всех новостей, где сводки
        // не хватает, чтобы краткое содержание было развёрнутым везде, а не
        // только в открытой карточке новости.
        //
        // В режиме слабого интернета это и есть основной источник трафика и
        // задержки (по запросу на каждую новость, к тому же с двумя попытками
        // на источник — см. ArticleContentFetcher), поэтому в этом режиме
        // полностью пропускаем догрузку и остаёмся с тизером как есть.
        if !lowData {
            await expandShortSummaries(&categorized)
        }

        // Сортировка по дате (свежие сверху), без даты — в конец
        categorized.sort { ($0.pubDate ?? .distantPast) > ($1.pubDate ?? .distantPast) }

        self.items = categorized
        self.lastUpdated = Date()
        NewsCache.save(categorized)
        seedExpandedSummaryCache(from: categorized)

        // Архив обрабатываем заметно легче основной ленты: категоризация,
        // склейка дублей и короткая суммаризация — но БЕЗ дорогой догрузки
        // полного текста статьи (expandShortSummaries), которая и так уже
        // основное время обновления тратит на сегодняшние новости. Архивные
        // новости читают реже и не настолько нуждаются в развёрнутой сводке.
        var archived = NewsCategorizer.categorizeAll(archiveRaw)
        archived = NewsDeduplicator.merge(archived)
        for index in archived.indices {
            archived[index].summary = NewsSummarizer.summarize(archived[index])
        }
        archived.sort { ($0.pubDate ?? .distantPast) > ($1.pubDate ?? .distantPast) }
        // Не даём архиву расти бесконечно — тот же принцип балансировки по
        // категориям, что и у основной ленты, но с меньшим потолком.
        archived = balanceByCategory(archived, maxPerCategory: maxArchiveItemsPerCategory)

        self.archivedItems = archived
        ArchiveCache.save(archived)

        let digest = DailyDigest.build(from: categorized)
        WidgetSharedDigest.save(digest, language: settings?.effectiveLanguage ?? .russian)

        if settings?.morningNotificationsEnabled == true {
            await MorningNotificationScheduler.reschedule(
                digest: digest,
                hour: settings?.morningNotificationHour ?? 8,
                minute: settings?.morningNotificationMinute ?? 0,
                title: settings?.t("notification.morningTitle") ?? "SpotBrief",
                language: settings?.effectiveLanguage ?? .russian
            )
        }
    }

    func search(_ query: String) -> [NewsItem] {
        guard !query.trimmingCharacters(in: .whitespaces).isEmpty else { return [] }
        let lowered = query.lowercased()
        return items.filter {
            $0.title.lowercased().contains(lowered) || $0.rawDescription.lowercased().contains(lowered)
        }
    }

    func items(in category: NewsCategory) -> [NewsItem] {
        items.filter { $0.category == category }
    }

    func count(in category: NewsCategory) -> Int {
        items.lazy.filter { $0.category == category }.count
    }

    func archivedItems(in category: NewsCategory) -> [NewsItem] {
        archivedItems.filter { $0.category == category }
    }

    func archivedCount(in category: NewsCategory) -> Int {
        archivedItems.lazy.filter { $0.category == category }.count
    }

    /// Не догружаем полный текст больше чем с этого числа ссылок одной
    /// объединённой новости (представитель + N-1 дублей) — у объединения
    /// с maxGroupSize (см. NewsDeduplicator) может набраться до 6 источников,
    /// а для более длинной и разнообразной сводки хватает и материала от
    /// нескольких: дальше это в основном одни и те же факты чужими словами,
    /// а не новый смысл, зато каждая лишняя ссылка — это ещё один сетевой
    /// запрос на каждую такую новость.
    private let maxLinksPerExpansion = 3

    /// Догружает полный текст статьи (а для новости, объединённой из
    /// нескольких источников — см. NewsDeduplicator — текст СРАЗУ
    /// нескольких статей об одном и том же событии) и пересчитывает по нему
    /// сводку для каждой новости, чья текущая сводка (построенная только по
    /// тизеру из RSS `<description>`) короче `NewsSummarizer.minSentences`.
    /// Именно объединение материала нескольких источников и делает
    /// требование "сводка не короче 5 предложений" выполнимым чаще: один
    /// тизер редко даёт достаточно текста, а два-три независимых описания
    /// одного события — как правило, да. Новости без ссылок или те, где
    /// загрузка не удалась (источник недоступен, блокирует запрос и т.п.),
    /// остаются с тем, что уже есть, — придумывать недостающие предложения
    /// нельзя, это была бы уже не новость источника.
    private func expandShortSummaries(_ items: inout [NewsItem]) async {
        // Новости, которые уже были развёрнуты в одном из предыдущих
        // обновлений (та же пара источник+заголовок — см. stableID),
        // подставляем из кэша без сетевого запроса: результат для того же
        // текста статьи не изменится, а часть новостей (особенно у медленно
        // обновляющихся источников) остаётся в ленте по несколько обновлений
        // подряд.
        for index in items.indices {
            if let cachedSummary = expandedSummaryCache[items[index].stableID],
               NewsSummarizer.sentenceCount(in: cachedSummary) > NewsSummarizer.sentenceCount(in: items[index].summary) {
                items[index].summary = cachedSummary
            }
        }

        let candidateIndices = items.indices.filter { index in
            // Достаточно хотя бы одной ссылки — своей или от объединённого
            // источника-дубля (mergedLinks, см. NewsDeduplicator).
            (items[index].link != nil || !(items[index].mergedLinks ?? []).isEmpty)
            && NewsSummarizer.sentenceCount(in: items[index].summary) < NewsSummarizer.minSentences
            // Гороскопы, колонки читательских писем и подобные "сборные"
            // материалы — не один связный текст, а несколько разных
            // мини-тем подряд; экстрактивная суммаризация на них даёт
            // бессвязную кашу из фраз о разных темах. Отсеиваем такие ещё
            // до запроса — та же проверка, что и в NewsDetailView.
            && !ArticleContentFetcher.isLikelyMultiTopicContent(title: items[index].title, description: items[index].rawDescription)
        }
        guard !candidateIndices.isEmpty else { return }

        await withTaskGroup(of: (Int, String?).self) { group in
            var iterator = candidateIndices.makeIterator()
            var running = 0

            func addNext() {
                guard let index = iterator.next() else { return }
                // Как и в SourceAvailabilityChecker: URL и заголовок считаем здесь,
                // на MainActor, а не внутри addTask — обращаться к элементам
                // `items` из конкурентного замыкания без await нельзя.
                let allLinks = Array((([items[index].link].compactMap { $0 }) + (items[index].mergedLinks ?? []))
                    .prefix(maxLinksPerExpansion))
                // Ссылка гарантированно есть — так уже отфильтровано в candidateIndices,
                // но проверяем ещё раз, чтобы не рассинхронизировать running/addTask.
                guard !allLinks.isEmpty else { addNext(); return }
                running += 1
                let title = items[index].title
                group.addTask {
                    // Несколько ссылок одной новости запрашиваем ОДНОВРЕМЕННО,
                    // а не по очереди — иначе у новости с 3 источниками
                    // время ожидания утраивалось бы (до 3× таймаут вместо 1×),
                    // а из-за общего лимита maxConcurrentExpansions это ещё и
                    // надолго занимало бы "слот" на фоне остальных новостей.
                    let texts: [String] = await withTaskGroup(of: String?.self) { linkGroup in
                        for link in allLinks {
                            linkGroup.addTask {
                                try? await ArticleContentFetcher.fetchArticleText(from: link, relatedTo: title)
                            }
                        }
                        var collected: [String] = []
                        for await text in linkGroup {
                            if let text { collected.append(text) }
                        }
                        return collected
                    }
                    guard !texts.isEmpty else { return (index, nil) }
                    // maxSentences выше, чем для одиночного источника (8) —
                    // при нескольких независимых описаниях одного события
                    // реального материала обычно больше, и есть смысл дать
                    // суммаризатору больше "на выбор" при отборе непохожих
                    // друг на друга предложений (см. NewsSummarizer).
                    let expanded = NewsSummarizer.summarize(title: title, text: texts.joined(separator: " "), maxSentences: 10)
                    return (index, expanded)
                }
            }

            for _ in 0..<maxConcurrentExpansions { addNext() }

            while let (index, expanded) = await group.next() {
                running -= 1
                // Обновляем, только если реально получили более длинную сводку —
                // если полный текст статьи вдруг оказался короче тизера (бывает
                // на страницах-агрегаторах), тизер остаётся лучшим вариантом.
                if let expanded, NewsSummarizer.sentenceCount(in: expanded) > NewsSummarizer.sentenceCount(in: items[index].summary) {
                    items[index].summary = expanded
                }
                addNext()
                if running == 0 { break }
            }
        }
    }

    /// Ограничивает каждую категорию сверху (maxPerCategory), оставляя в
    /// каждой самые свежие новости, — чтобы категория по умолчанию
    /// ("Общество") или любая другая с большим "естественным" числом
    /// совпадений по ключевым словам не забирала себе непропорционально
    /// много места и времени на суммаризацию за счёт более редких тем.
    /// Категории, которых оказалось меньше maxPerCategory, не трогает —
    /// это и есть тот случай "если больше — нормально, а если меньше —
    /// значит, столько реально нашлось", который нельзя обойти без
    /// придумывания несуществующих новостей.
    private func balanceByCategory(_ items: [NewsItem], maxPerCategory: Int) -> [NewsItem] {
        var byCategory: [NewsCategory: [NewsItem]] = [:]
        for item in items {
            byCategory[item.category, default: []].append(item)
        }
        var balanced: [NewsItem] = []
        balanced.reserveCapacity(items.count)
        for category in NewsCategory.allCases {
            guard var group = byCategory[category] else { continue }
            group.sort { ($0.pubDate ?? .distantPast) > ($1.pubDate ?? .distantPast) }
            if group.count > maxPerCategory {
                group = Array(group.prefix(maxPerCategory))
            }
            balanced.append(contentsOf: group)
        }
        return balanced
    }

    struct NamedError: Error {
        let name: String
        let underlying: Error
    }

    // MARK: - Отладочные хелперы (DebugMenuView)

    /// Мгновенно подставляет синтетическую ленту со всеми категориями —
    /// чтобы проверить главный экран, дайджест, статистику, поиск и
    /// закладки без ожидания реального сетевого обновления по RSS.
    /// Настоящую сеть не трогает и не портит: реальная лента просто
    /// перезапишется при следующем refreshAll() (pull-to-refresh или
    /// авто-обновление), как и после смены региона.
    func debugPopulateMockFeed() {
        let mock = Self.buildMockItems()
        items = mock
        lastUpdated = Date()
        errors = []
        NewsCache.save(mock)
        seedExpandedSummaryCache(from: mock)

        let digest = DailyDigest.build(from: mock)
        WidgetSharedDigest.save(digest, language: settings?.effectiveLanguage ?? .russian)
    }

    /// Очищает ленту и офлайн-кэш — для проверки состояния "нет данных"
    /// (ContentUnavailableView в ContentView) без переустановки приложения.
    func debugClearFeed() {
        items = []
        lastUpdated = nil
        errors = []
        NewsCache.clear()
        archivedItems = []
        ArchiveCache.clear()
    }

    /// Добавляет фиктивную ошибку источника — для проверки секции
    /// "источники недоступны" в ContentView без реального сбоя сети.
    func debugInjectSampleError(_ message: String) {
        errors.append(message)
    }

    /// Синтетические новости на все категории — с `link: nil`, чтобы
    /// открытие карточки не пыталось догрузить полный текст статьи по
    /// несуществующей ссылке (см. NewsDetailView.loadFullArticle).
    private static func buildMockItems() -> [NewsItem] {
        let sourceNames = ["Debug Wire", "Тест Медиа", "DummyPress", "Заглушка Daily"]
        let now = Date()
        var items: [NewsItem] = []

        for (categoryIndex, category) in NewsCategory.allCases.enumerated() {
            for n in 0..<5 {
                let minutesAgo = categoryIndex * 7 + n * 3
                let title = "[DEBUG] \(category.rawValue) — тестовая новость №\(n + 1)"
                let description = "Это синтетическая новость для отладочного меню SpotBrief. " +
                    "Категория: \(category.rawValue). Используется для проверки интерфейса " +
                    "без ожидания реальной загрузки RSS-лент."
                items.append(
                    NewsItem(
                        title: title,
                        rawDescription: description,
                        link: nil,
                        pubDate: now.addingTimeInterval(TimeInterval(-minutesAgo * 60)),
                        sourceName: sourceNames[(categoryIndex + n) % sourceNames.count],
                        category: category,
                        summary: description
                    )
                )
            }
        }

        return items.sorted { ($0.pubDate ?? .distantPast) > ($1.pubDate ?? .distantPast) }
    }
}
