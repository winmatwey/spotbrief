import Foundation
import BackgroundTasks

/// Планирует и выполняет обновление ленты новостей, когда приложение
/// свёрнуто или не запущено — через системный `BackgroundTasks`.
///
/// Раньше "автообновление" (см. `NewsAggregatorService.scheduleAutoRefresh`)
/// было устроено как простой `Task` с `Task.sleep` внутри. Это прекрасно
/// работает, пока приложение открыто или недавно свёрнуто, но как только
/// iOS приостанавливает или выгружает процесс из памяти — а на практике
/// это происходит уже через несколько секунд после ухода в фон — этот
/// `Task` умирает вместе с процессом и никогда не просыпается сам.
/// Обновление в этом случае происходит только при следующем ручном
/// открытии приложения. `BackgroundTasks` — единственный официальный
/// способ на iOS попросить систему разбудить приложение именно для
/// обновления данных, пока пользователь им не пользуется.
///
/// Важная оговорка, которую стоит понимать: `earliestBeginDate` — это
/// именно "не раньше", а не "ровно в это время". iOS сама решает, когда
/// реально запустить задачу, — исходя из того, как часто человек обычно
/// открывает приложение, заряда батареи, состояния сети и общей загрузки
/// системы фоновыми задачами всех приложений сразу. Иногда это будет
/// заметно позже, чем выбранный в настройках интервал автообновления —
/// это ожидаемое поведение системы, а не баг приложения.
enum BackgroundRefreshScheduler {

    /// Идентификатор задачи. Должен быть перечислен в Info.plist в массиве
    /// `BGTaskSchedulerPermittedIdentifiers` — см. Info-Additions.plist и
    /// комментарий в Package.swift. Без этого `register` ниже провалится
    /// с ошибкой уже на старте приложения.
    static let taskIdentifier = "ru.matwey.spotbrief.refresh"

    /// Ios не запускает фоновые задачи чаще, чем примерно раз в 15 минут,
    /// даже если попросить раньше, — независимо от того, что выбрано в
    /// настройках автообновления. Держим эту нижнюю границу явно в коде,
    /// а не полагаемся молча на системный лимит.
    private static let minimumIntervalMinutes = 15

    /// Регистрирует обработчик задачи. Должно быть вызвано один раз при
    /// запуске приложения, и обязательно ДО того, как приложение закончит
    /// запуск (то есть из `init()` SpotBriefApp, а не из `.onAppear` —
    /// `.onAppear` вызывается уже после того, как первый экран показан,
    /// и к этому моменту регистрировать задачу системе иногда уже поздно).
    static func registerBackgroundTask() {
        BGTaskScheduler.shared.register(
            forTaskWithIdentifier: taskIdentifier,
            using: nil
        ) { task in
            guard let refreshTask = task as? BGAppRefreshTask else {
                task.setTaskCompleted(success: false)
                return
            }
            handleAppRefresh(refreshTask)
        }
    }

    /// Ставит в очередь следующее фоновое обновление. Вызывается при уходе
    /// приложения в фон (см. SpotBriefApp) и повторно из самого обработчика
    /// задачи — `BGAppRefreshTaskRequest` одноразовый, и после каждого
    /// выполнения его нужно пересоздавать заново, иначе следующего
    /// фонового обновления просто не случится.
    static func scheduleAppRefresh() {
        // Уважаем явный выбор пользователя: если автообновление выключено
        // в настройках (0 минут), фоновые обновления тоже не планируем,
        // а снимаем всё, что могло остаться запланированным с прошлого раза.
        //
        // Читаем значение напрямую из UserDefaults, а не через
        // `SettingsStore().autoRefreshMinutes` — SettingsStore помечен
        // @MainActor, а эта функция вызывается в том числе из обработчика
        // фоновой задачи (см. handleAppRefresh), который iOS запускает НЕ
        // на главном потоке. Создать там @MainActor-объект синхронно нельзя —
        // именно это компилятор и не разрешал. UserDefaults потокобезопасен
        // сам по себе, так что для одного Int-значения актор не нужен.
        let minutes = UserDefaults.standard.integer(forKey: SettingsStore.autoRefreshMinutesKey)
        guard minutes > 0 else {
            BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: taskIdentifier)
            return
        }

        let request = BGAppRefreshTaskRequest(identifier: taskIdentifier)
        let intervalMinutes = max(minutes, minimumIntervalMinutes)
        request.earliestBeginDate = Date(timeIntervalSinceNow: TimeInterval(intervalMinutes * 60))

        do {
            try BGTaskScheduler.shared.submit(request)
        } catch {
            // На симуляторе BGTaskScheduler.submit почти всегда бросает
            // ошибку — это нормально и не баг: симулятор не умеет по-настоящему
            // планировать фоновые задачи. На реальном устройстве ошибка здесь
            // означает, что заявка не встала в очередь (например, система
            // уже придерживает слишком много отложенных задач разом) —
            // ничего страшного, следующая попытка произойдёт сама собой при
            // следующем уходе приложения в фон.
        }
    }

    private static func handleAppRefresh(_ task: BGAppRefreshTask) {
        // Сразу подаём заявку на следующее обновление — если этого не
        // сделать здесь, а положиться только на вызов при уходе в фон,
        // цепочка обновлений оборвётся в тот же день, когда пользователь
        // просто не закроет и не свернёт приложение вручную (не будет
        // события scenePhase == .background).
        scheduleAppRefresh()

        let work = Task { @MainActor in
            let service = NewsAggregatorService.current ?? makeStandaloneService()
            await service.refreshAll()
            task.setTaskCompleted(success: true)
        }

        // Система даёт на фоновую задачу считаные секунды. Если не уложились —
        // корректно отменяем работу вместо того, чтобы быть принудительно
        // прибитыми системой посреди сетевого запроса.
        task.expirationHandler = {
            work.cancel()
        }
    }

    /// Если систем запускает процесс "с нуля" специально под фоновую задачу
    /// (приложение было выгружено из памяти), живого `NewsAggregatorService`
    /// из `RootTabView` ещё не существует. Создаём отдельный экземпляр —
    /// он выполнит тот же `refreshAll()` и сохранит результат в общий
    /// дисковый кэш и данные виджета; при следующем открытии приложения
    /// обычный сервис прочитает эти уже готовые данные из кэша сам же.
    @MainActor
    private static func makeStandaloneService() -> NewsAggregatorService {
        let service = NewsAggregatorService()
        let settings = SettingsStore()
        let customSources = CustomSourcesStore()
        service.attach(settings: settings, customSources: customSources)
        return service
    }
}
