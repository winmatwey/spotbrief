import SwiftUI

/// Архив — новости за последние 7 дней, которые не попали в сегодняшнюю
/// ленту (см. NewsAggregatorService.refreshAll, разбиение на "сегодня" /
/// "архив"). Основная лента показывает СТРОГО сегодняшние новости; всё,
/// что чуть старше, не теряется, а оседает здесь.
struct ArchiveView: View {
    @EnvironmentObject var service: NewsAggregatorService
    @EnvironmentObject var settings: SettingsStore

    var body: some View {
        List {
            if service.archivedItems.isEmpty {
                ContentUnavailableView(
                    settings.t("archive.emptyTitle"),
                    systemImage: "archivebox",
                    description: Text(settings.t("archive.emptyDescription"))
                )
            } else {
                Section {
                    ForEach(NewsCategory.allCases) { category in
                        let count = service.archivedCount(in: category)
                        if count > 0 {
                            NavigationLink {
                                ArchiveCategoryDetailView(category: category)
                            } label: {
                                ArchiveCategoryRow(category: category, count: count)
                            }
                        }
                    }
                } header: {
                    Text(settings.t("archive.footer"))
                        .textCase(nil)
                }
            }
        }
        .navigationTitle(settings.t("archive.title"))
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct ArchiveCategoryRow: View {
    @EnvironmentObject var settings: SettingsStore
    let category: NewsCategory
    let count: Int

    var body: some View {
        HStack {
            Image(systemName: category.symbolName)
                .foregroundStyle(.secondary)
                .frame(width: 28)
            Text(category.localizedName(settings.effectiveLanguage))
                .font(.body)
            Spacer()
            Text("\(count)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 2)
    }
}

struct ArchiveCategoryDetailView: View {
    @EnvironmentObject var service: NewsAggregatorService
    @EnvironmentObject var bookmarks: BookmarksStore
    @EnvironmentObject var readStore: ReadStore
    @EnvironmentObject var settings: SettingsStore
    let category: NewsCategory

    private var items: [NewsItem] {
        service.archivedItems(in: category)
    }

    var body: some View {
        List {
            ForEach(items) { item in
                NavigationLink {
                    NewsDetailView(item: item)
                } label: {
                    ArchiveNewsRow(item: item)
                }
                .swipeActions(edge: .leading) {
                    Button {
                        bookmarks.toggle(item)
                    } label: {
                        Label(bookmarks.isBookmarked(item) ? settings.t("swipe.removeBookmark") : settings.t("swipe.addBookmark"),
                              systemImage: bookmarks.isBookmarked(item) ? "bookmark.slash" : "bookmark")
                    }
                    .tint(.orange)
                }
            }
        }
        .navigationTitle(category.localizedName(settings.effectiveLanguage))
        .navigationBarTitleDisplayMode(.large)
    }
}

private struct ArchiveNewsRow: View {
    @EnvironmentObject var readStore: ReadStore
    @EnvironmentObject var settings: SettingsStore
    let item: NewsItem

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(item.title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(readStore.isRead(item) ? .secondary : .primary)
                .lineLimit(3)
            Text(item.summary.isEmpty ? settings.t("summary.unavailable") : item.summary)
                .font(.caption)
                .foregroundStyle(.secondary)
                .italic(item.summary.isEmpty)
                .lineLimit(2)
            HStack {
                Text(item.allSourceNames.joined(separator: ", "))
                    .lineLimit(1)
                if let date = item.pubDate {
                    Text("· \(date.formatted(date: .abbreviated, time: .shortened))")
                }
                Spacer()
            }
            .font(.caption2)
            .foregroundStyle(.tertiary)
        }
        .padding(.vertical, 2)
    }
}
