import Foundation

/// Компактная, кодируемая версия DailyDigest — то, что реально нужно
/// виджету на экране блокировки: заголовок и группа, без полного текста
/// новости и служебных полей NewsItem.
struct WidgetDigestEntry: Codable {
    let category: String
    let title: String
    let sourceName: String
}

struct WidgetDigestPayload: Codable {
    let generatedAt: Date
    let entries: [WidgetDigestEntry]
}

/// Пишет актуальную сводку в App Group, чтобы её мог прочитать виджет на
/// экране блокировки (WidgetKit-расширение — отдельный процесс, у него нет
/// доступа к памяти основного приложения, поэтому обмен идёт через общее
/// хранилище).
///
/// ВАЖНО: сам проект сейчас собран как Swift Playgrounds App Playground
/// (см. Package.swift — единственный продукт `.iOSApplication`). Этот
/// формат проекта не поддерживает добавление второго таргета — а виджет
/// экрана блокировки технически ЯВЛЯЕТСЯ отдельным таргетом (App Extension
/// с точкой расширения `com.apple.widgetkit-extension`). Написать сам
/// виджет и вывести его на экран блокировки без Xcode-проекта с двумя
/// таргетами и общей App Group нельзя — таково ограничение формата
/// .swiftpm, а не что-то, что можно обойти кодом.
///
/// Что сделано здесь и сейчас: приложение готовит и складывает данные для
/// виджета при каждом обновлении ленты, и в комплекте — готовый код самого
/// виджета (см. WidgetExtension-Reference/ рядом с Sources) на тот момент,
/// когда проект будет открыт в Xcode и в него добавят таргет расширения:
/// тогда останется прописать тот же App Group Identifier здесь и в
/// таргете расширения — и виджет сразу увидит эти данные.
enum WidgetSharedDigest {
    /// Замените на реальный идентификатор App Group после того, как
    /// добавите его в Xcode (Signing & Capabilities → + App Groups — для
    /// ОБОИХ таргетов, основного приложения и расширения виджета).
    private static let appGroupIdentifier = "group.ru.matwey.spotbrief"
    private static let storageKey = "spotbrief.widgetDigest"

    private static var store: UserDefaults {
        // Пока App Group не настроена в Xcode, UserDefaults(suiteName:)
        // с несуществующей группой вернёт nil — используем .standard как
        // безопасный запасной вариант, чтобы приложение не падало и данные
        // всё равно готовились (просто виджет их пока прочитать не сможет).
        UserDefaults(suiteName: appGroupIdentifier) ?? .standard
    }

    static func save(_ digest: DailyDigest, language: AppLanguage) {
        let entries = digest.entries.map {
            WidgetDigestEntry(
                category: $0.category.localizedName(language),
                title: $0.item.title,
                sourceName: $0.item.sourceName
            )
        }
        let payload = WidgetDigestPayload(generatedAt: Date(), entries: entries)
        guard let data = try? JSONEncoder().encode(payload) else { return }
        store.set(data, forKey: storageKey)
    }

    static func load() -> WidgetDigestPayload? {
        guard let data = store.data(forKey: storageKey) else { return nil }
        return try? JSONDecoder().decode(WidgetDigestPayload.self, from: data)
    }
}
