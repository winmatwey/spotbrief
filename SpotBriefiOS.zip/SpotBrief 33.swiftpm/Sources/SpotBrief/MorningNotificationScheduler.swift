import Foundation
import UserNotifications

/// Планирует ежедневное локальное уведомление со сводкой (см. DailyDigest).
///
/// ВАЖНО про свежесть содержимого: у приложения нет своего сервера и push-
/// рассылки, поэтому текст уведомления — это не "сводка на момент 8:00", а
/// снимок сводки на момент, когда приложение ПОСЛЕДНИЙ РАЗ обновляло ленту
/// (сама система на этот текст не влияет, она просто показывает уже готовое
/// уведомление в заданное время — таковы возможности локальных уведомлений
/// без расширения-сервиса). Каждый раз, когда NewsAggregatorService.refreshAll()
/// успешно отрабатывает, уведомление на завтра переставляется заново с
/// актуальным текстом — так что если открывать приложение хотя бы раз в
/// день, сводка в уведомлении почти всегда свежая; если не открывать
/// несколько дней — уведомление в это время всё равно придёт, но с той
/// сводкой, что была на момент последнего запуска.
enum MorningNotificationScheduler {
    private static let identifier = "spotbrief.morningDigest"

    /// Текущий статус разрешения на уведомления, без запроса его показа.
    static func authorizationStatus() async -> UNAuthorizationStatus {
        await UNUserNotificationCenter.current().notificationSettings().authorizationStatus
    }

    /// Запрашивает разрешение, если пользователь ещё не отвечал. Возвращает
    /// true, если после вызова уведомления разрешены (были разрешены раньше
    /// или пользователь только что согласился).
    @discardableResult
    static func requestAuthorizationIfNeeded() async -> Bool {
        let center = UNUserNotificationCenter.current()
        let current = await center.notificationSettings().authorizationStatus
        switch current {
        case .authorized, .provisional, .ephemeral:
            return true
        case .notDetermined:
            return (try? await center.requestAuthorization(options: [.alert, .sound, .badge])) ?? false
        default:
            return false
        }
    }

    /// Переставляет ежедневное уведомление на заданное время с текстом из
    /// digest. Если digest пуст (например, лента ещё ни разу не грузилась),
    /// уведомление не ставится — рассылать пустое "Сводка дня: (ничего)"
    /// нет смысла.
    static func reschedule(digest: DailyDigest, hour: Int, minute: Int, title: String, language: AppLanguage) async {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [identifier])
        guard !digest.isEmpty else { return }

        let content = UNMutableNotificationContent()
        content.title = title
        content.body = digest.notificationBody(language: language)
        content.sound = .default

        var dateComponents = DateComponents()
        dateComponents.hour = hour
        dateComponents.minute = minute
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)

        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        try? await center.add(request)
    }

    static func cancel() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [identifier])
    }

    // MARK: - Отладка (DebugMenuView)

    /// Отдельный identifier от `identifier` (обычного ежедневного
    /// уведомления) — чтобы тестовый запуск не отменял и не подменял уже
    /// запланированное реальное утреннее уведомление.
    private static let debugIdentifier = "spotbrief.debugTestNotification"

    /// Присылает тестовое уведомление через несколько секунд вместо
    /// ожидания заданного времени дня — чтобы проверить содержимое и
    /// сам факт доставки прямо во время тестирования.
    static func fireTestNotification(digest: DailyDigest, title: String, language: AppLanguage) async {
        let granted = await requestAuthorizationIfNeeded()
        guard granted else { return }

        let content = UNMutableNotificationContent()
        content.title = title
        content.body = digest.isEmpty
            ? "Debug test notification — SpotBrief"
            : digest.notificationBody(language: language)
        content.sound = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
        let request = UNNotificationRequest(identifier: debugIdentifier, content: content, trigger: trigger)
        try? await UNUserNotificationCenter.current().add(request)
    }
}
