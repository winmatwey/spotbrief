import SwiftUI
import UniformTypeIdentifiers

// Support type for exportIPA() (see ExportIPA.swift).
// Source: https://gist.github.com/rileytestut/5b3ede1cfeaba47cea9e6c1c8c114e4e

extension UTType
{
    static let ipa = UTType(filenameExtension: "ipa")!
}

// FileWrapper — класс из Foundation, который Apple пока не пометил как
// Sendable, хотя по факту безопасно передавать его между потоками, пока
// никто не мутирует один и тот же экземпляр параллельно (здесь он либо
// только читается, либо создаётся заново — см. использование ниже).
//
// Раньше здесь было `extension FileWrapper: @unchecked Sendable {}` —
// оно убирало исходное предупреждение, но порождало новое: "Extension
// declares a conformance of imported type 'FileWrapper' to imported
// protocol 'Sendable'" — компилятор предупреждает, что ретроактивно
// конформить ЧУЖОЙ тип ЧУЖОМУ протоколу небезопасно на будущее (вдруг
// Apple сама объявит FileWrapper как Sendable иначе). Правильный способ —
// не трогать сам тип FileWrapper, а точечно пометить как "доверенное"
// именно это свойство через nonisolated(unsafe).
struct IPAFile: FileDocument
{
    nonisolated(unsafe) let file: FileWrapper

    static var readableContentTypes: [UTType] { [.ipa] }
    static var writableContentTypes: [UTType] { [.ipa] }

    init(ipaURL: URL) throws
    {
        self.file = try FileWrapper(url: ipaURL, options: .immediate)
    }

    init(configuration: ReadConfiguration) throws
    {
        self.file = configuration.file
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper
    {
        return self.file
    }
}
