import SwiftUI
import UserNotifications
import BackgroundTasks
#if canImport(UIKit)
import UIKit
#endif

/// Скрытое меню разработчика — открывается долгим нажатием (2–3 секунды)
/// на строку "Источников новостей" в разделе "О приложении" настроек
/// (см. SettingsView). Позволяет проверить состояния экранов, уведомления,
/// смену региона/языка и другие функции мгновенно, не дожидаясь реальной
/// загрузки RSS-лент по сети и не проходя онбординг заново вручную.
///
/// Ничего из этого не рассчитано на обычного пользователя — сюда не ведёт
/// ни одна видимая кнопка, только секретный жест.
struct DebugMenuView: View {
    @EnvironmentObject private var service: NewsAggregatorService
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var customSources: CustomSourcesStore
    @EnvironmentObject private var bookmarks: BookmarksStore
    @EnvironmentObject private var readStore: ReadStore
    @Environment(\.dismiss) private var dismiss

    @StateObject private var debugChecker = SourceAvailabilityChecker()
    @ObservedObject private var speech = SpeechReader.shared

    @State private var toastMessage: String?
    @State private var toastToken = 0

    @State private var showConfetti = false
    @State private var confettiPieces: [ConfettiPiece] = []
    @State private var headerTapCount = 0

    @State private var jokeIndex = 0
    @State private var speechTestID = UUID()

    @State private var notificationStatusText = "…"
    @State private var showResetConfirmation = false
    @State private var backgroundRefreshStatusText = "…"

    private let devJokes = [
        "Здесь могла быть ваша реклама.",
        "Работает как часы — то есть иногда отстаёт.",
        "Это не баг, это недокументированная фича.",
        "Собрано на кухне в 3 часа ночи.",
        "Ошибка 418: я чайник ☕️",
        "99 маленьких багов в коде, 99 багов…",
        "Ctrl+Z сюда, к сожалению, не дотягивается."
    ]

    var body: some View {
        NavigationStack {
            Form {
                headerSection
                instantTestingSection
                notificationsSection
                backgroundRefreshSection
                sourcesSection
                regionSection
                languageSection
                onboardingSection
                speechSection
                dataSection
                diagnosticsSection
                aboutSection
            }
            .navigationTitle("Debug Menu")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Готово") { dismiss() }
                }
            }
            .confirmationDialog(
                "Сбросить всё приложение?",
                isPresented: $showResetConfirmation,
                titleVisibility: .visible
            ) {
                Button("Сбросить всё", role: .destructive) { performFullReset() }
                Button("Отмена", role: .cancel) {}
            } message: {
                Text("Удалит закладки, «прочитанное», свои источники, кэш ленты и настройки. Онбординг откроется заново. Действие необратимо.")
            }
            .task {
                let status = await MorningNotificationScheduler.authorizationStatus()
                notificationStatusText = describe(status)
            }
        }
        .overlay(alignment: .top) {
            if let toastMessage {
                DebugToast(message: toastMessage)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .overlay {
            if showConfetti {
                ConfettiOverlay(pieces: confettiPieces)
                    .ignoresSafeArea()
            }
        }
    }

    // MARK: - Секции

    private var headerSection: some View {
        Section {
            HStack(spacing: 12) {
                Text("🛠️")
                    .font(.system(size: 34))
                    .onTapGesture { handleHeaderTap() }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Debug Menu")
                        .font(.headline)
                    Text("Скрытое меню — только для тестирования")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(.vertical, 4)
        }
    }

    private var instantTestingSection: some View {
        Section {
            Button {
                service.debugPopulateMockFeed()
                showToast("📰 Тестовая лента загружена мгновенно")
            } label: {
                Label("Загрузить тестовую ленту мгновенно", systemImage: "bolt.fill")
            }

            Button {
                Task {
                    await service.refreshAll()
                    showToast("Лента обновлена")
                }
            } label: {
                Label("Обновить ленту сейчас", systemImage: "arrow.clockwise")
            }

            Button {
                service.debugClearFeed()
                showToast("Лента очищена")
            } label: {
                Label("Очистить ленту (тест пустого экрана)", systemImage: "tray")
            }

            Button {
                service.debugInjectSampleError("Debug Source: не удалось загрузить (тестовая ошибка)")
                showToast("Добавлена тестовая ошибка источника")
            } label: {
                Label("Симулировать ошибку источника", systemImage: "wifi.exclamationmark")
            }
        } header: {
            Text("Мгновенное тестирование")
        } footer: {
            Text("Проверяет состояния экрана без ожидания реальной загрузки RSS-лент по сети.")
        }
    }

    private var notificationsSection: some View {
        Section {
            LabeledContent("Статус разрешения", value: notificationStatusText)
            Button {
                Task {
                    let digest = DailyDigest.build(from: service.items)
                    await MorningNotificationScheduler.fireTestNotification(
                        digest: digest,
                        title: settings.t("notification.morningTitle"),
                        language: settings.effectiveLanguage
                    )
                    let status = await MorningNotificationScheduler.authorizationStatus()
                    notificationStatusText = describe(status)
                    showToast("🔔 Тестовое уведомление придёт через ~3 сек")
                }
            } label: {
                Label("Прислать тестовое уведомление сейчас", systemImage: "bell.badge")
            }
        } header: {
            Text("Уведомления")
        } footer: {
            Text("Отдельное тестовое уведомление приходит через несколько секунд и не отменяет уже запланированное утреннее.")
        }
    }

    private var backgroundRefreshSection: some View {
        Section {
            Button {
                BackgroundRefreshScheduler.scheduleAppRefresh()
                Task {
                    // Небольшая пауза перед перечитыванием статуса — заявка
                    // уходит в BGTaskScheduler не мгновенно синхронно.
                    try? await Task.sleep(nanoseconds: 300_000_000)
                    await refreshBackgroundStatus()
                }
                showToast("📥 Заявка на фоновое обновление отправлена системе")
            } label: {
                Label("Поставить фоновое обновление в очередь", systemImage: "arrow.triangle.2.circlepath")
            }
        } header: {
            Text("Фоновое обновление")
        } footer: {
            Text("На симуляторе BGTaskScheduler по-настоящему не выполняет задачи — статус здесь показателен только на реальном устройстве. Принудительно вызвать саму фоновую задачу можно через Xcode: Debug ▸ Simulate Background Fetch, или командой в LLDB (см. документацию Apple по BGTaskScheduler).")
        }
    }

    private var sourcesSection: some View {
        Section {
            Toggle("Экономия трафика (легаси-режим)", isOn: $settings.lowDataMode)
                .onChange(of: settings.lowDataMode) {
                    Task { await service.refreshAll() }
                }

            if settings.region == .russia {
                Toggle("Режим белых списков", isOn: $settings.whitelistMode)
                    .onChange(of: settings.whitelistMode) {
                        service.refreshSources()
                        Task { await service.refreshAll() }
                    }
            }

            Button {
                settings.mutedSources = []
                showToast("Все источники включены")
            } label: {
                Label("Включить все отключённые источники", systemImage: "speaker.wave.2")
            }

            Button {
                Task {
                    await debugChecker.check(service.sources)
                    showToast("Проверка доступности запущена")
                }
            } label: {
                Label("Перепроверить доступность источников", systemImage: "checkmark.shield")
            }
        } header: {
            Text("Источники")
        }
    }

    private var regionSection: some View {
        Section {
            ForEach(Region.allCases) { region in
                Button {
                    service.updateRegion(region)
                    showToast("Регион: \(region.displayName)")
                } label: {
                    HStack {
                        Text(region.flag)
                        Text(region.displayName)
                            .foregroundStyle(.primary)
                        Spacer()
                        if settings.region == region {
                            Image(systemName: "checkmark")
                                .foregroundStyle(.orange)
                        }
                    }
                }
            }
        } header: {
            Text("Быстрая смена региона")
        } footer: {
            Text("Сразу применяет регион и запускает загрузку его источников — без экрана выбора.")
        }
    }

    private var languageSection: some View {
        Section {
            ForEach(AppLanguage.allCases) { language in
                Button {
                    settings.language = language
                    showToast("Язык: \(language.nativeName)")
                } label: {
                    HStack {
                        Text(language.flag)
                        Text(language.nativeName)
                            .foregroundStyle(.primary)
                        Spacer()
                        if settings.language == language {
                            Image(systemName: "checkmark")
                                .foregroundStyle(.orange)
                        }
                    }
                }
            }
        } header: {
            Text("Быстрая смена языка")
        }
    }

    private var onboardingSection: some View {
        Section {
            Button(role: .destructive) {
                dismiss()
                Task {
                    try? await Task.sleep(nanoseconds: 300_000_000)
                    settings.language = nil
                    settings.region = nil
                }
            } label: {
                Label("Сбросить онбординг", systemImage: "arrow.counterclockwise")
            }
        } header: {
            Text("Онбординг")
        } footer: {
            Text("Открывает экран выбора языка и региона заново — как при первом запуске.")
        }
    }

    private var speechSection: some View {
        Section {
            Button {
                speech.toggle(
                    id: speechTestID,
                    text: "Это тестовая озвучка для проверки речи в отладочном меню.",
                    languageCode: settings.effectiveLanguage.speechLanguageCode
                )
            } label: {
                let isSpeakingTest = speech.isSpeaking && speech.speakingItemID == speechTestID
                Label(isSpeakingTest ? "Остановить озвучку" : "Проверить озвучку",
                      systemImage: isSpeakingTest ? "stop.circle.fill" : "speaker.wave.2.fill")
            }
        } header: {
            Text("Озвучка")
        }
    }

    private var dataSection: some View {
        Section {
            Button(role: .destructive) {
                bookmarks.removeAll()
                showToast("Закладки очищены")
            } label: {
                Label("Очистить закладки", systemImage: "bookmark.slash")
            }

            Button(role: .destructive) {
                readStore.clearAll()
                showToast("Отметки «прочитано» сброшены")
            } label: {
                Label("Сбросить «прочитано»", systemImage: "eye.slash")
            }

            Button(role: .destructive) {
                for source in customSources.sources {
                    customSources.remove(source)
                }
                service.refreshSources()
                showToast("Свои источники удалены")
            } label: {
                Label("Удалить все свои источники", systemImage: "trash")
            }

            Button(role: .destructive) {
                showResetConfirmation = true
            } label: {
                Label("Полный сброс приложения…", systemImage: "exclamationmark.triangle")
            }
        } header: {
            Text("Данные (осторожно)")
        }
    }

    private var diagnosticsSection: some View {
        Section {
            LabeledContent("Новостей в ленте", value: "\(service.items.count)")
            LabeledContent("Источников (активно)", value: "\(service.sources.count)")
            LabeledContent("Отключённых источников", value: "\(settings.mutedSources.count)")
            LabeledContent("Ошибок источников", value: "\(service.errors.count)")
            LabeledContent(
                "Последнее обновление",
                value: service.lastUpdated?.formatted(date: .abbreviated, time: .standard) ?? "—"
            )
            LabeledContent("Закладок", value: "\(bookmarks.bookmarks.count)")
            LabeledContent("Прочитано", value: "\(readStore.readIDs.count)")
            LabeledContent("Своих источников", value: "\(customSources.sources.count)")
            LabeledContent("Фоновое обновление", value: backgroundRefreshStatusText)
                .task { await refreshBackgroundStatus() }
        } header: {
            Text("Диагностика")
        }
    }

    private var aboutSection: some View {
        Section {
            LabeledContent(
                "Версия",
                value: (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
            )
            .contentShape(Rectangle())
            .onLongPressGesture(minimumDuration: 1.0) {
                showToast(devJokes[jokeIndex % devJokes.count])
                jokeIndex += 1
            }
        } footer: {
            Text("Подсказка: подержите строку с версией.")
        }
    }

    // MARK: - Пасхалки

    /// Первая пасхалка: 7 нажатий на иконку 🛠️ в шапке меню открывают
    /// конфетти и поздравление. Порог не привязан к таймеру нарочно —
    /// это лёгкая, случайная находка, а не головоломка с точным ритмом.
    private func handleHeaderTap() {
        headerTapCount += 1
        guard headerTapCount >= 7 else { return }
        headerTapCount = 0
        triggerConfetti()
        showToast("🎉 Пасхалка найдена! Секретный уровень открыт.")
        #if canImport(UIKit)
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        #endif
    }

    /// Вторая пасхалка: долгое нажатие на строку версии в разделе
    /// "О приложении" (aboutSection выше) листает шуточные "девелоперские"
    /// сообщения по кругу.

    private func triggerConfetti() {
        let symbols = ["🎉", "✨", "📰", "🥳", "⭐️", "🎊"]
        confettiPieces = (0..<24).map { _ in
            ConfettiPiece(
                symbol: symbols.randomElement() ?? "🎉",
                x: CGFloat.random(in: 0.05...0.95),
                delay: Double.random(in: 0...0.4),
                duration: Double.random(in: 1.0...1.8),
                rotation: Double.random(in: -180...180)
            )
        }
        showConfetti = true
        Task {
            try? await Task.sleep(nanoseconds: 2_200_000_000)
            showConfetti = false
        }
    }

    // MARK: - Вспомогательное

    private func showToast(_ text: String) {
        toastToken += 1
        let token = toastToken
        withAnimation { toastMessage = text }
        Task {
            try? await Task.sleep(nanoseconds: 1_800_000_000)
            // Если за это время запустился более новый тост, не гасим его чужим таймером.
            if token == toastToken {
                withAnimation { toastMessage = nil }
            }
        }
    }

    private func performFullReset() {
        bookmarks.removeAll()
        readStore.clearAll()
        for source in customSources.sources {
            customSources.remove(source)
        }
        service.debugClearFeed()
        settings.mutedSources = []
        settings.autoRefreshMinutes = 0
        settings.sortOrder = .newest
        settings.lowDataMode = false
        settings.whitelistMode = false
        settings.morningNotificationsEnabled = false
        MorningNotificationScheduler.cancel()
        service.refreshSources()
        dismiss()
        Task {
            // Небольшая задержка, чтобы лист успел закрыться до того, как
            // RootTabView покажет полноэкранный онбординг поверх всего.
            try? await Task.sleep(nanoseconds: 300_000_000)
            settings.language = nil
            settings.region = nil
        }
    }

    private func describe(_ status: UNAuthorizationStatus) -> String {
        switch status {
        case .notDetermined: return "не запрошено"
        case .denied: return "запрещено"
        case .authorized: return "разрешено"
        case .provisional: return "разрешено (предварительно)"
        case .ephemeral: return "временно (App Clip)"
        @unknown default: return "неизвестно"
        }
    }

    /// Читает у системы, действительно ли фоновое обновление стоит в
    /// очереди, и на какое ближайшее время (не точное время запуска —
    /// см. комментарий в BackgroundRefreshScheduler про earliestBeginDate).
    /// На симуляторе BGTaskScheduler по-настоящему задачи не планирует,
    /// поэтому там здесь почти всегда будет "не запланировано" даже сразу
    /// после ухода в фон — это ограничение симулятора, не баг приложения.
    private func refreshBackgroundStatus() async {
        let requests: [BGTaskRequest] = await withCheckedContinuation { continuation in
            BGTaskScheduler.shared.getPendingTaskRequests { requests in
                continuation.resume(returning: requests)
            }
        }
        guard let request = requests.first(where: { $0.identifier == BackgroundRefreshScheduler.taskIdentifier }) else {
            backgroundRefreshStatusText = settings.autoRefreshMinutes > 0 ? "не запланировано" : "выключено"
            return
        }
        if let date = request.earliestBeginDate {
            backgroundRefreshStatusText = "не раньше \(date.formatted(date: .omitted, time: .shortened))"
        } else {
            backgroundRefreshStatusText = "запланировано"
        }
    }
}

// MARK: - Тост

private struct DebugToast: View {
    let message: String

    var body: some View {
        Text(message)
            .font(.subheadline.weight(.semibold))
            .multilineTextAlignment(.center)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.thinMaterial, in: Capsule())
            .shadow(radius: 4)
            .padding(.horizontal, 24)
    }
}

// MARK: - Конфетти (вторая часть первой пасхалки)

private struct ConfettiPiece: Identifiable {
    let id = UUID()
    let symbol: String
    let x: CGFloat
    let delay: Double
    let duration: Double
    let rotation: Double
}

private struct ConfettiOverlay: View {
    let pieces: [ConfettiPiece]
    @State private var animate = false

    var body: some View {
        GeometryReader { geo in
            ZStack {
                ForEach(pieces) { piece in
                    Text(piece.symbol)
                        .font(.system(size: 28))
                        .rotationEffect(.degrees(animate ? piece.rotation : 0))
                        .position(
                            x: piece.x * geo.size.width,
                            y: animate ? geo.size.height + 40 : -40
                        )
                        .animation(
                            .easeIn(duration: piece.duration).delay(piece.delay),
                            value: animate
                        )
                }
            }
        }
        .allowsHitTesting(false)
        .onAppear { animate = true }
    }
}
