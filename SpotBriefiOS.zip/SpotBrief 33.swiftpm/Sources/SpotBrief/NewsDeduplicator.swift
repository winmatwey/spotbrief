import Foundation

/// Объединяет одну и ту же новость, пришедшую от нескольких РАЗНЫХ
/// источников, в одну карточку в ленте — вместо нескольких почти
/// одинаковых заголовков подряд (частый случай: крупное событие в один
/// день одновременно освещают РИА, ТАСС, Lenta.ru и т.п.).
///
/// Работает по сходству ЗАГОЛОВКОВ (индекс Жаккара по значимым словам —
/// та же техника, что и NewsSummarizer.isNearDuplicate для предложений
/// внутри одного текста) и по близости времени публикации. Только сходства
/// заголовка недостаточно: два разных, но лексически похожих заголовка
/// (например, регулярная тема вроде обзора курса валют, публикуемая изо
/// дня в день) могли бы склеиться в один, хотя это разные новости за
/// разные дни, — поэтому дополнительно требуется, чтобы источники
/// опубликовали материал в пределах одного и того же окна времени.
enum NewsDeduplicator {
    /// Порог схожести заголовков. Выше, чем в NewsSummarizer (0.6 — там для
    /// почти дословных повторов внутри одного текста): заголовки одного
    /// события от разных редакций перефразированы сильнее, чем предложения
    /// внутри одной статьи, но и заметно ниже 1.0 не годится — иначе
    /// склеятся просто похожие по теме, а не одна и та же новость.
    private static let titleSimilarityThreshold = 0.45

    /// Максимальный разброс по времени публикации между источниками одной
    /// и той же новости. У настоящего совместного освещения событий это
    /// обычно минуты-часы; сутки с запасом покрывают и медленно
    /// обновляющиеся источники.
    private static let maxPublicationGap: TimeInterval = 20 * 60 * 60

    /// Не объединяет больше этого числа источников в одну карточку — защита
    /// от вырожденного случая (например, очень общий заголовок в спокойный
    /// новостной день), когда порог сходства случайно набрал слишком много
    /// "кандидатов"; выше этого числа они, скорее всего, уже не про одно
    /// и то же событие, а совпадение — случайность.
    private static let maxGroupSize = 6

    /// Объединяет дубли ВНУТРИ каждой категории отдельно — новости из
    /// разных категорий по построению не могут быть одним и тем же
    /// событием (см. NewsCategorizer), а группировка по категории заодно
    /// на порядок сокращает число сравнений по сравнению со сравнением
    /// каждой новости с каждой по всей ленте сразу.
    static func merge(_ items: [NewsItem]) -> [NewsItem] {
        var byCategory: [NewsCategory: [NewsItem]] = [:]
        for item in items {
            byCategory[item.category, default: []].append(item)
        }

        var result: [NewsItem] = []
        result.reserveCapacity(items.count)
        for category in NewsCategory.allCases {
            guard let group = byCategory[category] else { continue }
            result.append(contentsOf: mergeWithinCategory(group))
        }
        return result
    }

    private static func mergeWithinCategory(_ items: [NewsItem]) -> [NewsItem] {
        var remaining = items
        var result: [NewsItem] = []
        result.reserveCapacity(items.count)

        while !remaining.isEmpty {
            let base = remaining.removeFirst()
            var group = [base]

            var index = 0
            while index < remaining.count && group.count < maxGroupSize {
                // Помимо сравнения с `base`, проверяем, что в группе ещё нет
                // записи от этого же источника — иначе у источника с двумя
                // похоже озаглавленными, но разными материалами (например,
                // два репортажа с одной пресс-конференции) обе попали бы
                // в одну группу, хотя это два разных текста ОДНОГО источника,
                // а не подтверждение от независимой редакции.
                if isSameStory(base, remaining[index])
                    && !group.contains(where: { $0.sourceName == remaining[index].sourceName }) {
                    group.append(remaining.remove(at: index))
                } else {
                    index += 1
                }
            }

            result.append(combine(group))
        }

        return result
    }

    private static func isSameStory(_ a: NewsItem, _ b: NewsItem) -> Bool {
        // Один и тот же источник дважды про одно и то же событие в ленте
        // не встречается (RSS не дублирует свои же новости), а заголовки
        // РАЗНЫХ материалов ОДНОЙ редакции иногда лексически близки
        // (например, два репортажа с одной пресс-конференции) — сравнивать
        // между собой новости одного источника не нужно и рискованно.
        guard a.sourceName != b.sourceName else { return false }

        // Раньше: если хотя бы у одной из новостей pubDate не распознался
        // (nil), проверка временного окна целиком пропускалась — совпадение
        // решалось только по схожести заголовков. Из-за этого старая (иногда
        // на годы) новость с нераспознанной или просто старой датой могла
        // "склеиться" с сегодняшней по случайному лексическому сходству
        // заголовков, и объединённая карточка потом показывала чужую
        // древнюю дату поверх свежей новости. Теперь дата обязана быть
        // у ОБЕИХ новостей и укладываться в окно — иначе объединения нет,
        // и обе новости остаются отдельными карточками (не хуже, чем
        // просто отсутствие дедупликации для этой пары).
        guard let dateA = a.pubDate, let dateB = b.pubDate,
              abs(dateA.timeIntervalSince(dateB)) <= maxPublicationGap else {
            return false
        }

        return titleSimilarity(a.title, b.title) >= titleSimilarityThreshold
    }

    private static func titleSimilarity(_ a: String, _ b: String) -> Double {
        let wordsA = Set(significantWords(in: a))
        let wordsB = Set(significantWords(in: b))
        guard !wordsA.isEmpty, !wordsB.isEmpty else { return 0 }
        let intersection = wordsA.intersection(wordsB).count
        let union = wordsA.union(wordsB).count
        guard union > 0 else { return 0 }
        return Double(intersection) / Double(union)
    }

    private static func significantWords(in text: String) -> [String] {
        text.lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { $0.count > 2 }
    }

    /// Выбирает "представителя" группы дублей — новость с самым длинным
    /// исходным тизером (обычно значит более подробное описание событие
    /// и, как следствие, более содержательную сводку без догрузки полного
    /// текста) — и подставляет ему остальные источники и их ссылки, а
    /// также заменяет описание на объединение тизеров ВСЕХ источников
    /// группы. Это и есть основной механизм для требования "сводка не
    /// короче 5 предложений": несколько независимых тизеров одного события
    /// от разных редакций почти всегда дают больше материала, чем один, —
    /// а сама суммаризация (см. NewsSummarizer) уже умеет убирать почти
    /// дословные повторы между ними.
    private static func combine(_ group: [NewsItem]) -> NewsItem {
        guard group.count > 1 else { return group[0] }

        let sorted = group.sorted { lhs, rhs in
            if lhs.rawDescription.count != rhs.rawDescription.count {
                return lhs.rawDescription.count > rhs.rawDescription.count
            }
            return lhs.sourceName < rhs.sourceName
        }

        let base = sorted[0]
        let others = Array(sorted.dropFirst())

        // Дата объединённой карточки — самая свежая из ВСЕХ источников
        // группы, а не обязательно дата "представителя" (которого выбираем
        // по длине тизера, а не по свежести). `pubDate` — `let`, поэтому
        // карточку приходится пересобрать целиком, а не просто переписать
        // одно поле.
        let mostRecentDate = group.compactMap(\.pubDate).max() ?? base.pubDate

        var representative = NewsItem(
            id: base.id,
            title: base.title,
            rawDescription: base.rawDescription,
            link: base.link,
            pubDate: mostRecentDate,
            sourceName: base.sourceName,
            category: base.category,
            summary: base.summary
        )

        representative.mergedSourceNames = others.map(\.sourceName).sorted()
        representative.mergedLinks = others.compactMap(\.link)
        representative.rawDescription = ([base.rawDescription] + others.map(\.rawDescription))
            .filter { !$0.isEmpty }
            .joined(separator: " ")

        return representative
    }
}
