import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct SettingsView: View {
    @EnvironmentObject var service: NewsAggregatorService
    @EnvironmentObject var settings: SettingsStore
    @EnvironmentObject var customSources: CustomSourcesStore
    @StateObject private var checker = SourceAvailabilityChecker()
    @State private var showingRegionPicker = false
    @State private var showingLanguagePicker = false
    @State private var showingAddSource = false
    @State private var isExportingIPA = false
    @State private var ipaFile: IPAFile?
    @State private var isPreparingIPA = false
    @State private var exportErrorMessage: String?
    @State private var notificationAuthDenied = false
    // Секретное отладочное меню (см. DebugMenuView) — открывается долгим
    // нажатием на строку "Источников новостей" ниже, а не отдельной
    // кнопкой в интерфейсе, чтобы не путать обычных пользователей.
    @State private var showingDebugMenu = false

    private var notificationTimeBinding: Binding<Date> {
        Binding<Date>(
            get: {
                var components = DateComponents()
                components.hour = settings.morningNotificationHour
                components.minute = settings.morningNotificationMinute
                return Calendar.current.date(from: components) ?? Date()
            },
            set: { newDate in
                let components = Calendar.current.dateComponents([.hour, .minute], from: newDate)
                settings.morningNotificationHour = components.hour ?? 8
                settings.morningNotificationMinute = components.minute ?? 0
                rescheduleMorningNotification()
            }
        )
    }

    private func rescheduleMorningNotification() {
        guard settings.morningNotificationsEnabled else { return }
        Task {
            let digest = DailyDigest.build(from: service.items)
            await MorningNotificationScheduler.reschedule(
                digest: digest,
                hour: settings.morningNotificationHour,
                minute: settings.morningNotificationMinute,
                title: settings.t("notification.morningTitle"),
                language: settings.effectiveLanguage
            )
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Button {
                        showingLanguagePicker = true
                    } label: {
                        HStack {
                            Text(settings.effectiveLanguage.flag)
                            Text(settings.effectiveLanguage.nativeName)
                                .foregroundStyle(.primary)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                    }
                } header: {
                    Text(settings.t("settings.language"))
                } footer: {
                    Text(settings.t("settings.languageFooter"))
                }

                Section {
                    Button {
                        showingRegionPicker = true
                    } label: {
                        HStack {
                            Text(settings.region?.flag ?? "🌍")
                            Text(settings.region?.localizedName(settings.effectiveLanguage) ?? settings.t("settings.regionNotSelected"))
                                .foregroundStyle(.primary)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                    }
                } header: {
                    Text(settings.t("settings.region"))
                } footer: {
                    Text(settings.t("settings.regionFooter"))
                }

                Section {
                    Toggle(isOn: $settings.lowDataMode) {
                        Text(settings.t("settings.lowDataMode"))
                    }
                    .onChange(of: settings.lowDataMode) {
                        Task { await service.refreshAll() }
                    }
                } header: {
                    Text(settings.t("settings.lowDataModeHeader"))
                } footer: {
                    Text(settings.t("settings.lowDataModeFooter"))
                }

                if settings.region == .russia {
                    Section {
                        Toggle(isOn: $settings.whitelistMode) {
                            Text(settings.t("settings.whitelistMode"))
                        }
                        .onChange(of: settings.whitelistMode) {
                            service.refreshSources()
                            Task { await service.refreshAll() }
                        }
                    } header: {
                        Text(settings.t("settings.whitelistModeHeader"))
                    } footer: {
                        Text(settings.t("settings.whitelistModeFooter"))
                    }
                }

                Section {
                    Toggle(isOn: Binding(
                        get: { settings.morningNotificationsEnabled },
                        set: { isOn in
                            if isOn {
                                Task {
                                    let granted = await MorningNotificationScheduler.requestAuthorizationIfNeeded()
                                    settings.morningNotificationsEnabled = granted
                                    notificationAuthDenied = !granted
                                    if granted { rescheduleMorningNotification() }
                                }
                            } else {
                                settings.morningNotificationsEnabled = false
                                MorningNotificationScheduler.cancel()
                            }
                        }
                    )) {
                        Text(settings.t("settings.morningNotifications"))
                    }

                    if settings.morningNotificationsEnabled {
                        DatePicker(
                            settings.t("settings.morningNotificationsTime"),
                            selection: notificationTimeBinding,
                            displayedComponents: .hourAndMinute
                        )
                    }

                    if notificationAuthDenied {
                        Text(settings.t("settings.morningNotificationsDenied"))
                            .font(.footnote)
                            .foregroundStyle(.orange)
                    }
                } header: {
                    Text(settings.t("settings.morningNotificationsHeader"))
                } footer: {
                    Text(settings.t("settings.morningNotificationsFooter"))
                }

                Section(settings.t("settings.autoRefresh")) {
                    Picker(settings.t("settings.interval"), selection: $settings.autoRefreshMinutes) {
                        Text(settings.t("settings.off")).tag(0)
                        Text(settings.t("settings.minutes5")).tag(5)
                        Text(settings.t("settings.minutes15")).tag(15)
                        Text(settings.t("settings.minutes30")).tag(30)
                        Text(settings.t("settings.hour1")).tag(60)
                    }
                    .onChange(of: settings.autoRefreshMinutes) {
                        service.scheduleAutoRefresh()
                    }
                }

                Section {
                    ForEach(builtInSources) { source in
                        Toggle(isOn: Binding(
                            get: { !settings.isMuted(source) },
                            set: { _ in settings.toggleMute(source) }
                        )) {
                            HStack(spacing: 8) {
                                availabilityIcon(for: checker.status(for: source))
                                Text(source.name)
                            }
                        }
                    }
                } header: {
                    Text(settings.tf("settings.sourcesHeader", builtInSources.count))
                } footer: {
                    Text(settings.t("settings.sourcesFooter"))
                }

                Section {
                    if customSources.sources.isEmpty {
                        Text(settings.t("settings.noCustomSources"))
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(customSources.sources) { source in
                            HStack(spacing: 8) {
                                if let url = source.feedURL {
                                    availabilityIcon(for: checker.status(forURL: url))
                                }
                                Text(source.name)
                            }
                        }
                        .onDelete { offsets in
                            let toRemove = offsets.map { customSources.sources[$0] }
                            for source in toRemove {
                                customSources.remove(source)
                            }
                            service.refreshSources()
                        }
                    }
                    Button {
                        showingAddSource = true
                    } label: {
                        Label(settings.t("settings.addSource"), systemImage: "plus.circle")
                    }
                } header: {
                    Text(settings.t("settings.customSources"))
                } footer: {
                    Text(settings.t("settings.customSourcesFooter"))
                }

                Section(settings.t("settings.about")) {
                    LabeledContent(settings.t("settings.appName"), value: settings.t("app.name"))
                        .onLongPressGesture(minimumDuration: 2.5) {
                            exportIPAFile()
                        }
                    LabeledContent(settings.t("settings.newsSourcesCount"), value: "\(service.sources.count)")
                        .contentShape(Rectangle())
                        .onLongPressGesture(minimumDuration: 2.5) {
                            #if canImport(UIKit)
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            #endif
                            showingDebugMenu = true
                        }
                    Text(settings.t("settings.aboutFooter"))
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    if isPreparingIPA {
                        HStack {
                            ProgressView()
                                .controlSize(.small)
                            Text(settings.t("settings.exportIPA"))
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    }
                    if let exportErrorMessage {
                        Text(exportErrorMessage)
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle(settings.t("tab.settings"))
            .task(id: service.sources.map(\.id)) {
                await checker.check(service.sources)
            }
            .sheet(isPresented: $showingRegionPicker) {
                RegionPickerView(onFinished: { showingRegionPicker = false })
            }
            .sheet(isPresented: $showingLanguagePicker) {
                LanguagePickerView(onFinished: { showingLanguagePicker = false })
            }
            .sheet(isPresented: $showingAddSource) {
                AddCustomSourceView()
            }
            .sheet(isPresented: $showingDebugMenu) {
                DebugMenuView()
            }
            .fileExporter(isPresented: $isExportingIPA, document: ipaFile, contentType: .ipa) { result in
                if case .failure(let error) = result {
                    exportErrorMessage = error.localizedDescription
                }
            }
        }
    }

    private func exportIPAFile() {
        exportErrorMessage = nil
        isPreparingIPA = true
        Task { @MainActor in
            defer { isPreparingIPA = false }
            do {
                let ipaPath = try await exportIPA()
                let ipaURL = URL(fileURLWithPath: ipaPath)
                ipaFile = try IPAFile(ipaURL: ipaURL)
                isExportingIPA = true
            } catch {
                exportErrorMessage = error.localizedDescription
            }
        }
    }

    private var builtInSources: [NewsSource] {
        settings.region.map(NewsSource.sources(for:)) ?? []
    }

    @ViewBuilder
    private func availabilityIcon(for status: SourceAvailability) -> some View {
        switch status {
        case .checking:
            ProgressView()
                .controlSize(.mini)
        case .available:
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(.green)
                .font(.caption)
        case .unavailable:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.red)
                .font(.caption)
        }
    }
}
