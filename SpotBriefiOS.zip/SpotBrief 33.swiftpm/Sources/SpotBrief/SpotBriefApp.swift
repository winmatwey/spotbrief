import SwiftUI

@main
struct SpotBriefApp: App {
    @StateObject private var service = NewsAggregatorService()
    @StateObject private var settings = SettingsStore()
    @StateObject private var bookmarks = BookmarksStore()
    @StateObject private var readStore = ReadStore()
    @StateObject private var customSources = CustomSourcesStore()

    // Отслеживаем переход приложения в фон, чтобы поставить в очередь
    // фоновое обновление ленты (см. BackgroundRefreshScheduler).
    @Environment(\.scenePhase) private var scenePhase

    init() {
        // Регистрировать обработчик фоновой задачи нужно один раз и
        // обязательно ДО того, как приложение закончит запуск — SwiftUI
        // вызывает init() ещё на этом этапе. Если зарегистрировать позже
        // (например, из .onAppear, который срабатывает уже после показа
        // первого экрана), система может отказаться выполнять задачу.
        BackgroundRefreshScheduler.registerBackgroundTask()
    }

    var body: some Scene {
        WindowGroup {
            RootTabView()
                .environmentObject(service)
                .environmentObject(settings)
                .environmentObject(bookmarks)
                .environmentObject(readStore)
                .environmentObject(customSources)
                .onAppear {
                    service.attach(settings: settings, customSources: customSources)
                }
        }
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .background {
                // BGAppRefreshTaskRequest одноразовый — планируем заново
                // при каждом уходе в фон (см. также повторную постановку
                // внутри самого обработчика задачи, на случай если
                // приложение никогда не сворачивают вручную).
                BackgroundRefreshScheduler.scheduleAppRefresh()
            }
        }
    }
}
