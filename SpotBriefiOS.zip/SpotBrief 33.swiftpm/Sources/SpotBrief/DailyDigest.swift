import Foundation

/// Сводка "по одной главной новости из каждой группы" — используется на
/// главном экране (см. ContentView) и как текст утреннего уведомления
/// (см. MorningNotificationScheduler). Одно место, где решается, что
/// считать "главным событием" темы, чтобы оба места не расходились.
struct DailyDigest {
    struct Entry: Identifiable {
        var id: String { item.stableID }
        let category: NewsCategory
        let item: NewsItem
    }

    let entries: [Entry]

    /// Берёт самую свежую новость из каждой непустой категории, в порядке
    /// NewsCategory.allCases. Категории без новостей просто отсутствуют
    /// в сводке — придумывать для них "главное событие" не из чего.
    static func build(from items: [NewsItem]) -> DailyDigest {
        var latestByCategory: [NewsCategory: NewsItem] = [:]
        for item in items {
            guard let existing = latestByCategory[item.category] else {
                latestByCategory[item.category] = item
                continue
            }
            if (item.pubDate ?? .distantPast) > (existing.pubDate ?? .distantPast) {
                latestByCategory[item.category] = item
            }
        }
        let entries = NewsCategory.allCases.compactMap { category in
            latestByCategory[category].map { Entry(category: category, item: $0) }
        }
        return DailyDigest(entries: entries)
    }

    var isEmpty: Bool { entries.isEmpty }

    /// Компактный текст для тела уведомления — "Группа: заголовок", по
    /// одной строке на категорию, не длиннее maxEntries строк, чтобы не
    /// превращать уведомление в стену текста.
    func notificationBody(language: AppLanguage, maxEntries: Int = 6) -> String {
        entries.prefix(maxEntries)
            .map { "\($0.category.localizedName(language)): \($0.item.title)" }
            .joined(separator: "\n")
    }
}
